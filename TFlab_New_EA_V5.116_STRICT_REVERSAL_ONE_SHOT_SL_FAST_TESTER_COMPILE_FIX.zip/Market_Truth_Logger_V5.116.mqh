#ifndef __TFLAB_MARKET_TRUTH_LOGGER_V5_93_MQH__
#define __TFLAB_MARKET_TRUTH_LOGGER_V5_93_MQH__

//+------------------------------------------------------------------+
//|             Market_Truth_Logger_V5.116.mqh                       |
//| گزارش مستقل و همزمان جزئیات خام بازار برای Strategy Tester      |
//| این فایل هیچ تصمیم معاملاتی تولید نمی‌کند و به EA اعتماد ندارد.  |
//+------------------------------------------------------------------+
#property strict

#define TFLAB_MTL_TF_COUNT 6

enum MarketTruthLoggerIndex
  {
   MTL_M1 = 0,
   MTL_M5 = 1,
   MTL_M15 = 2,
   MTL_M30 = 3,
   MTL_H1 = 4,
   MTL_H4 = 5
  };

struct MarketTruthLoggerState
  {
   bool initialized;
   ulong row_count;
   string file_name;
   string last_run_file;
   ENUM_TIMEFRAMES tfs[TFLAB_MTL_TF_COUNT];
   datetime last_bar[TFLAB_MTL_TF_COUNT];
   datetime current_m5_bar;
   datetime current_m1_bar;
   string current_m1_first_move;
   string current_m5_first_extreme;
   string closed_m5_first_extreme;
  };

void MarketTruthLogger_InitState(MarketTruthLoggerState &s)
  {
   ZeroMemory(s);
   s.initialized=false;
   s.row_count=0;
   s.file_name="TFlab_BACKTEST_Market_Truth_EA.csv";
   s.last_run_file="TFlab_BACKTEST_Market_Truth_EA_LAST_RUN.txt";
   s.tfs[MTL_M1]=PERIOD_M1;
   s.tfs[MTL_M5]=PERIOD_M5;
   s.tfs[MTL_M15]=PERIOD_M15;
   s.tfs[MTL_M30]=PERIOD_M30;
   s.tfs[MTL_H1]=PERIOD_H1;
   s.tfs[MTL_H4]=PERIOD_H4;
   for(int i=0;i<TFLAB_MTL_TF_COUNT;i++) s.last_bar[i]=0;
   s.current_m5_bar=0; s.current_m1_bar=0; s.current_m1_first_move=""; s.current_m5_first_extreme=""; s.closed_m5_first_extreme="";
  }

string MarketTruthLogger_Csv(const string v)
  {
   string s=v;
   StringReplace(s,"\"","\"\"");
   return "\""+s+"\"";
  }

string MarketTruthLogger_Header()
  {
   return "LoggerVersion;RunLabel;Symbol;ChartTimeframe;Timeframe;BarIndex;BarStart;BarEnd;Open;High;Low;Close;RangePrice;RangeATR;BodyPrice;BodyATR;BodyPct;UpperWickPrice;LowerWickPrice;CloseLocationPct;Direction;TickVolume;RealVolume;SpreadPointsAtLog;ATR14;EMA20;EMA50;RSI14;ADX14;PlusDI14;MinusDI14;PrevClose;DeltaPrice;DeltaATR;FirstM1Extreme;M1Count;M1DirectionalRatio;TesterTime;ServerTime";
  }

bool MarketTruthLogger_Open(MarketTruthLoggerState &s,int &h)
  {
   h=FileOpen(s.file_name,FILE_READ|FILE_WRITE|FILE_CSV|FILE_UNICODE|FILE_SHARE_READ|FILE_SHARE_WRITE,';');
   if(h==INVALID_HANDLE) return false;
   if(FileSize(h)==0)
      FileWriteString(h,MarketTruthLogger_Header()+"\r\n");
   FileSeek(h,0,SEEK_END);
   return true;
  }

double MarketTruthLogger_IndicatorValue(const int handle,const int buffer,const int shift)
  {
   if(handle==INVALID_HANDLE) return 0.0;
   double a[];
   ArraySetAsSeries(a,true);
   if(CopyBuffer(handle,buffer,shift,1,a)!=1) return 0.0;
   return a[0];
  }

double MarketTruthLogger_ATR(const ENUM_TIMEFRAMES tf,const int shift)
  {
   int h=iATR(_Symbol,tf,14);
   if(h==INVALID_HANDLE) return 0.0;
   double v=MarketTruthLogger_IndicatorValue(h,0,shift);
   IndicatorRelease(h);
   return v;
  }

double MarketTruthLogger_EMA(const ENUM_TIMEFRAMES tf,const int period,const int shift)
  {
   int h=iMA(_Symbol,tf,period,0,MODE_EMA,PRICE_CLOSE);
   if(h==INVALID_HANDLE) return 0.0;
   double v=MarketTruthLogger_IndicatorValue(h,0,shift);
   IndicatorRelease(h);
   return v;
  }

double MarketTruthLogger_RSI(const ENUM_TIMEFRAMES tf,const int shift)
  {
   int h=iRSI(_Symbol,tf,14,PRICE_CLOSE);
   if(h==INVALID_HANDLE) return 0.0;
   double v=MarketTruthLogger_IndicatorValue(h,0,shift);
   IndicatorRelease(h);
   return v;
  }

void MarketTruthLogger_ADX(const ENUM_TIMEFRAMES tf,const int shift,double &adx,double &plus_di,double &minus_di)
  {
   adx=0.0; plus_di=0.0; minus_di=0.0;
   int h=iADX(_Symbol,tf,14);
   if(h==INVALID_HANDLE) return;
   adx=MarketTruthLogger_IndicatorValue(h,0,shift);
   plus_di=MarketTruthLogger_IndicatorValue(h,1,shift);
   minus_di=MarketTruthLogger_IndicatorValue(h,2,shift);
   IndicatorRelease(h);
  }

void MarketTruthLogger_M1Stats(const datetime bar_start,const datetime bar_end,
                               string &first_extreme,int &count,double &directional_ratio)
  {
   first_extreme=""; count=0; directional_ratio=0.0;
   if(bar_start<=0 || bar_end<=bar_start) return;
   MqlRates r[];
   int copied=CopyRates(_Symbol,PERIOD_M1,bar_start,bar_end-1,r);
   if(copied<=0) return;
   double net=0.0, abs_moves=0.0;
   bool first=true;
   for(int i=0;i<copied;i++)
     {
      if(r[i].time<bar_start || r[i].time>=bar_end) continue;
      count++;
      double move=r[i].close-r[i].open;
      net+=move;
      abs_moves+=MathAbs(move);
      if(first)
        {
         if(r[i].high>r[i].open && r[i].low<r[i].open)
            first_extreme=(MathAbs(r[i].high-r[i].open) >= MathAbs(r[i].open-r[i].low) ? "HIGH_FIRST" : "LOW_FIRST");
         else if(r[i].high>r[i].open)
            first_extreme="HIGH_FIRST";
         else if(r[i].low<r[i].open)
            first_extreme="LOW_FIRST";
         else
            first_extreme="NONE";
         first=false;
        }
     }
   if(abs_moves>0.0)
      directional_ratio=MathAbs(net)/abs_moves;
  }

void MarketTruthLogger_WriteRow(MarketTruthLoggerState &s,const ENUM_TIMEFRAMES tf,const int idx)
  {
   int shift=1;
   MqlRates r[];
   ArraySetAsSeries(r,true);
   if(CopyRates(_Symbol,tf,shift,2,r)!=2) return;

   datetime bar_start=r[0].time;
   datetime bar_end=bar_start+PeriodSeconds(tf);
   double o=r[0].open, h=r[0].high, l=r[0].low, c=r[0].close;
   double range=MathMax(0.0,h-l);
   double body=MathAbs(c-o);
   double atr=MarketTruthLogger_ATR(tf,shift);
   double ema20=MarketTruthLogger_EMA(tf,20,shift);
   double ema50=MarketTruthLogger_EMA(tf,50,shift);
   double rsi=MarketTruthLogger_RSI(tf,shift);
   double adx=0.0, plus_di=0.0, minus_di=0.0;
   MarketTruthLogger_ADX(tf,shift,adx,plus_di,minus_di);
   double prev_close=r[1].close;
   double delta=c-prev_close;
   double upper=MathMax(0.0,h-MathMax(o,c));
   double lower=MathMax(0.0,MathMin(o,c)-l);
   double close_loc=(range>0.0 ? (c-l)/range*100.0 : 50.0);
   string direction=(c>o ? "BUY" : (c<o ? "SELL" : "FLAT"));
   long ticks=r[0].tick_volume;
   long realv=r[0].real_volume;
   long spread=(long)SymbolInfoInteger(_Symbol,SYMBOL_SPREAD);
   string first_extreme=""; int m1count=0; double m1ratio=0.0;
   if(tf==PERIOD_M5)
     {
      if(s.closed_m5_first_extreme!="") first_extreme=s.closed_m5_first_extreme;
      else MarketTruthLogger_M1Stats(bar_start,bar_end,first_extreme,m1count,m1ratio);
     }

   int bar_index=iBarShift(_Symbol,tf,bar_start,false);
   int fh=INVALID_HANDLE;
   if(!MarketTruthLogger_Open(s,fh)) return;
   FileWrite(fh,
      "TFlab Market Truth Logger V1.2","EA-V5.116",_Symbol,"M5",EnumToString(tf),bar_index,
      TimeToString(bar_start,TIME_DATE|TIME_SECONDS),TimeToString(bar_end,TIME_DATE|TIME_SECONDS),
      DoubleToString(o,_Digits),DoubleToString(h,_Digits),DoubleToString(l,_Digits),DoubleToString(c,_Digits),
      DoubleToString(range,_Digits),DoubleToString(atr>0.0?range/atr:0.0,4),
      DoubleToString(body,_Digits),DoubleToString(atr>0.0?body/atr:0.0,4),
      DoubleToString(range>0.0?body/range*100.0:0.0,2),DoubleToString(upper,_Digits),DoubleToString(lower,_Digits),
      DoubleToString(close_loc,2),direction,(string)ticks,(string)realv,(string)spread,
      DoubleToString(atr,_Digits),DoubleToString(ema20,_Digits),DoubleToString(ema50,_Digits),DoubleToString(rsi,2),
      DoubleToString(adx,2),DoubleToString(plus_di,2),DoubleToString(minus_di,2),DoubleToString(prev_close,_Digits),
      DoubleToString(delta,_Digits),DoubleToString(atr>0.0?delta/atr:0.0,4),first_extreme,
      (string)m1count,DoubleToString(m1ratio,4),TimeToString(TimeCurrent(),TIME_DATE|TIME_SECONDS),
      TimeToString(TimeTradeServer(),TIME_DATE|TIME_SECONDS));
   FileClose(fh);
   s.row_count++;
  }


void MarketTruthLogger_UpdateTick(MarketTruthLoggerState &s)
  {
   if(!s.initialized) return;
   datetime m5=iTime(_Symbol,PERIOD_M5,0);
   datetime m1=iTime(_Symbol,PERIOD_M1,0);
   if(m5>0 && m5!=s.current_m5_bar)
     {
      if(s.current_m5_bar>0) s.closed_m5_first_extreme=s.current_m5_first_extreme;
      s.current_m5_bar=m5;
      s.current_m1_bar=0;
      s.current_m1_first_move="";
      s.current_m5_first_extreme="";
     }
   if(m1>0 && m1!=s.current_m1_bar)
     {
      s.current_m1_bar=m1;
      s.current_m1_first_move="";
     }
   if(m1<=0) return;
   double o=iOpen(_Symbol,PERIOD_M1,0);
   if(o<=0.0) return;
   MqlTick tick;
   if(!SymbolInfoTick(_Symbol,tick)) return;
   double mid=(tick.bid>0.0 && tick.ask>0.0 ? (tick.bid+tick.ask)*0.5 : tick.bid);
   if(s.current_m1_first_move=="" && mid>o) s.current_m1_first_move="HIGH_FIRST";
   else if(s.current_m1_first_move=="" && mid<o) s.current_m1_first_move="LOW_FIRST";

   if(s.current_m5_first_extreme=="" && s.current_m1_first_move!="")
      s.current_m5_first_extreme=s.current_m1_first_move;
  }

void MarketTruthLogger_LogNewBars(MarketTruthLoggerState &s)
  {
   if(!MQLInfoInteger(MQL_TESTER)) return;
   if(!s.initialized) return;
   for(int i=0;i<TFLAB_MTL_TF_COUNT;i++)
     {
      datetime b=iTime(_Symbol,s.tfs[i],1);
      if(b<=0 || b==s.last_bar[i]) continue;
      s.last_bar[i]=b;
      MarketTruthLogger_WriteRow(s,s.tfs[i],i);
     }
  }

void MarketTruthLogger_Init(MarketTruthLoggerState &s,const string symbol)
  {
   s.file_name=(MQLInfoInteger(MQL_TESTER) ? "TFlab_BACKTEST_Market_Truth_EA.csv" : "TFlab_Market_Truth_EA.csv");
   s.last_run_file=(MQLInfoInteger(MQL_TESTER) ? "TFlab_BACKTEST_Market_Truth_EA_LAST_RUN.txt" : "TFlab_Market_Truth_EA_LAST_RUN.txt");
   FileDelete(s.file_name);
   int h=INVALID_HANDLE;
   if(MarketTruthLogger_Open(s,h)) FileClose(h);
   s.initialized=true;
   s.row_count=0;
   for(int i=0;i<TFLAB_MTL_TF_COUNT;i++) s.last_bar[i]=0;
   s.current_m5_bar=0; s.current_m1_bar=0; s.current_m1_first_move=""; s.current_m5_first_extreme=""; s.closed_m5_first_extreme="";
  }

void MarketTruthLogger_Finalize(MarketTruthLoggerState &s)
  {
   if(!s.initialized) return;
   int h=FileOpen(s.last_run_file,FILE_WRITE|FILE_TXT|FILE_UNICODE|FILE_SHARE_READ|FILE_SHARE_WRITE);
   if(h==INVALID_HANDLE) return;
   FileWriteString(h,"TFlab Market Truth Logger V1.2\r\n");
   FileWriteString(h,"CSV="+s.file_name+"\r\n");
   FileWriteString(h,"تعداد رکورد="+(string)s.row_count+"\r\n");
   FileWriteString(h,"زمان پایان="+TimeToString(TimeCurrent(),TIME_DATE|TIME_SECONDS)+"\r\n");
   FileWriteString(h,"دلیل پایان=1\r\n");
   FileClose(h);
  }

#endif

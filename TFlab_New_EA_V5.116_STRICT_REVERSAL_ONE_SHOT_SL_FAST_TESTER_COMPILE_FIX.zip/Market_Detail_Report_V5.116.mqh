#ifndef __TFLAB_MARKET_DETAIL_REPORT_MQH__
#define __TFLAB_MARKET_DETAIL_REPORT_MQH__

//+------------------------------------------------------------------+
//|               Market_Detail_Report_V5.116.mqh                    |
//|                                                                  |
//| مسئولیت: گزارش مستقل و جزئی ریزبازار برای هر چرخه تحلیل         |
//| این گزارش مستقل از گزارش معامله و گزارش AI نگهداری می‌شود.      |
//+------------------------------------------------------------------+
#property strict

#define TFLAB_MARKET_DETAIL_REPORT_FILE "TFlab_BACKTEST_Market_Detail_Report.csv"

struct MarketDetailReportState
  {
   bool      initialized;
   ulong     row_count;
   datetime  last_row_time;
   string    file_name;
   string    symbol;
  };

void MarketDetailReport_InitState(MarketDetailReportState &state)
  {
   ZeroMemory(state);
   state.initialized = false;
   state.row_count   = 0;
   state.last_row_time = 0;
   state.file_name   = TFLAB_MARKET_DETAIL_REPORT_FILE;
   state.symbol      = "";
  }

string MarketDetailReport_Escape(const string value)
  {
   string result = value;
   StringReplace(result,"\"","\"\"");
   return "\"" + result + "\"";
  }

string MarketDetailReport_Header()
  {
   return "شماره;زمان;نماد;تایم‌فریم;Bid;Ask;Spread_Point;H4;H1;M30_Regime;M30_Context;M15_Structure;M5_State;M5_Direction;Impulse_ATRx;CorrectionRatio;BUY_Zone_Distance_Point;SELL_Zone_Distance_Point;Zone_Position;Scenario_State;Scenario_Direction;Scenario_Quality;Scenario_Entry;Scenario_Invalidation;Execution_SL;TP1;TP2;Setup_State;Setup_Direction;Setup_Reason;نوع برنامه ورود;وضعیت برنامه ورود;قابل اجرا;قابل دسترسی;دلیل برنامه ورود;فرصت اولویت‌دار;کیفیت فرصت;دلیل فرصت;وضعیت Pending;تیکت Pending;چرخه";
  }

bool MarketDetailReport_EnsureFile(MarketDetailReportState &state)
  {
   ResetLastError();
   int handle = FileOpen(
      state.file_name,
      FILE_READ|FILE_WRITE|FILE_CSV|FILE_SHARE_READ|FILE_SHARE_WRITE,
      ';');

   if(handle == INVALID_HANDLE)
     {
      Print("[Market Detail Report] خطا | FileOpen ناموفق | Error=",GetLastError());
      return false;
     }

   if(FileSize(handle) == 0)
      FileWriteString(handle,MarketDetailReport_Header()+"\r\n");

   FileClose(handle);
   return true;
  }

bool MarketDetailReport_Init(
   MarketDetailReportState &state,
   const string symbol)
  {
   MarketDetailReport_InitState(state);
   state.symbol = symbol;

   if(!MarketDetailReport_EnsureFile(state))
      return false;

   state.initialized = true;

   Print(
      "[Market Detail Report] فعال شد | فایل=",
      state.file_name,
      " | MQL5\\Files");

   return true;
  }

bool MarketDetailReport_Write(
   MarketDetailReportState &state,
   const datetime row_time,
   const string symbol,
   const ENUM_TIMEFRAMES timeframe,
   const double bid,
   const double ask,
   const double spread_points,
   const string h4,
   const string h1,
   const string m30_regime,
   const string m30_context,
   const string m15_structure,
   const string m5_state,
   const string m5_direction,
   const double impulse_atr_x,
   const double correction_ratio,
   const double buy_zone_distance,
   const double sell_zone_distance,
   const string zone_position,
   const string scenario_state,
   const string scenario_direction,
   const double scenario_quality,
   const double scenario_entry,
   const double scenario_invalidation,
   const double execution_sl,
   const double tp1,
   const double tp2,
   const string setup_state,
   const string setup_direction,
   const string setup_reason,
   const string entry_plan_type,
   const string entry_plan_status,
   const bool entry_plan_executable,
   const bool entry_plan_reachable,
   const string entry_plan_reason,
   const bool opportunity_priority,
   const double opportunity_quality,
   const string opportunity_reason,
   const string pending_state,
   const ulong pending_ticket,
   const string cycle_result)
  {
   if(!state.initialized)
      return false;

   ResetLastError();
   int handle = FileOpen(
      state.file_name,
      FILE_READ|FILE_WRITE|FILE_CSV|FILE_SHARE_READ|FILE_SHARE_WRITE,
      ';');

   if(handle == INVALID_HANDLE)
     {
      Print("[Market Detail Report] خطا | باز کردن فایل ناموفق | Error=",GetLastError());
      return false;
     }

   FileSeek(handle,0,SEEK_END);

   state.row_count++;
   state.last_row_time = row_time;

   string row = "";
   row += (string)state.row_count + ";";
   row += TimeToString(row_time,TIME_DATE|TIME_SECONDS) + ";";
   row += MarketDetailReport_Escape(symbol) + ";";
   row += MarketDetailReport_Escape(EnumToString(timeframe)) + ";";
   row += DoubleToString(bid,_Digits) + ";";
   row += DoubleToString(ask,_Digits) + ";";
   row += DoubleToString(spread_points,1) + ";";
   row += MarketDetailReport_Escape(h4) + ";";
   row += MarketDetailReport_Escape(h1) + ";";
   row += MarketDetailReport_Escape(m30_regime) + ";";
   row += MarketDetailReport_Escape(m30_context) + ";";
   row += MarketDetailReport_Escape(m15_structure) + ";";
   row += MarketDetailReport_Escape(m5_state) + ";";
   row += MarketDetailReport_Escape(m5_direction) + ";";
   row += DoubleToString(impulse_atr_x,2) + ";";
   row += DoubleToString(correction_ratio*100.0,2) + ";";
   row += DoubleToString(buy_zone_distance,1) + ";";
   row += DoubleToString(sell_zone_distance,1) + ";";
   row += MarketDetailReport_Escape(zone_position) + ";";
   row += MarketDetailReport_Escape(scenario_state) + ";";
   row += MarketDetailReport_Escape(scenario_direction) + ";";
   row += DoubleToString(scenario_quality,2) + ";";
   row += DoubleToString(scenario_entry,_Digits) + ";";
   row += DoubleToString(scenario_invalidation,_Digits) + ";";
   row += DoubleToString(execution_sl,_Digits) + ";";
   row += DoubleToString(tp1,_Digits) + ";";
   row += DoubleToString(tp2,_Digits) + ";";
   row += MarketDetailReport_Escape(setup_state) + ";";
   row += MarketDetailReport_Escape(setup_direction) + ";";
   row += MarketDetailReport_Escape(setup_reason) + ";";
   row += MarketDetailReport_Escape(entry_plan_type) + ";";
   row += MarketDetailReport_Escape(entry_plan_status) + ";";
   row += (entry_plan_executable ? "YES" : "NO") + ";";
   row += (entry_plan_reachable ? "YES" : "NO") + ";";
   row += MarketDetailReport_Escape(entry_plan_reason) + ";";
   row += (opportunity_priority ? "YES" : "NO") + ";";
   row += DoubleToString(opportunity_quality,1) + ";";
   row += MarketDetailReport_Escape(opportunity_reason) + ";";
   row += MarketDetailReport_Escape(pending_state) + ";";
   row += (string)pending_ticket + ";";
   row += MarketDetailReport_Escape(cycle_result);

   bool ok = (FileWriteString(handle,row+"\r\n") > 0);
   FileFlush(handle);
   FileClose(handle);

   if(!ok)
     {
      Print("[Market Detail Report] خطا | نوشتن ردیف ناموفق | Error=",GetLastError());
      return false;
     }

   return true;
  }

void MarketDetailReport_Finalize(MarketDetailReportState &state)
  {
   if(!state.initialized)
      return;

   Print(
      "[Market Detail Report] پایان | ردیف=",
      state.row_count,
      " | فایل=",
      state.file_name);
  }

#endif // __TFLAB_MARKET_DETAIL_REPORT_MQH__

//+------------------------------------------------------------------+
//|                         EA_Main.mq5                               |
//|                    TFlab New EA V5.116- Orchestrator                |
//+------------------------------------------------------------------+
#property strict
#property version   "5.116"
#property description "TFlab New EA V.5.116 | موتور برگشت تأییدشده، قفل یک‌باره حد ضرر و بهینه‌سازی تستر"

#include "EA_Inputs_V5.116.mqh"
#include "Market_HigherTimeframe_V5.116.mqh"
#include "Market_Context_V5.116.mqh"
#include "Market_Regime_V5.116.mqh"
#include "Market_Structure_V5.116.mqh"
#include "Divergence_Detector_V5.116.mqh"
#include "Candle_Confirmation_V5.116.mqh"
#include "News_Filter_V5.116.mqh"
#include "Confluence_Engine_V5.116.mqh"
#include "Impulse_Correction_V5.116.mqh"
#include "Market_Truth_Engine_V5.116.mqh"
#include "Market_Reading_Engine_V5.116.mqh"
#include "Filter_Audit_V5.116.mqh"
#include "Report_Word_Engine_V5.116.mqh"
#include "AI_Journal_V5.116.mqh"
#include "AI_Suggestion_Engine_V5.116.mqh"
#include "AI_Independent_Analysis_V5.116.mqh"
#include "M5_Movement_Metrics_V5.116.mqh"
#include "M5_Zone_Quality_Analyzer_V5.116.mqh"
#include "Zone_Engine_V5.116.mqh"
#include "Strategy_Engine_V5.116.mqh"
#include "Scenario_Engine_V5.116.mqh"
#include "Invalidation_Engine_V5.116.mqh"
#include "Setup_Detector_V5.116.mqh"
#include "Entry_Planner_V5.116.mqh"
#include "Target_Engine_V5.116.mqh"
#include "SL_Engine_V5.116.mqh"
#include "TP_Engine_V5.116.mqh"
#include "Risk_Engine_V5.116.mqh"
#include "Execution_Engine_V5.116.mqh"
#include "Trade_Signal_Label_V5.116.mqh"
#include "Pending_Order_Manager_V5.116.mqh"
#include "Trade_Manager_V5.116.mqh"
#include "Trade_Logger_V5.116.mqh"
#include "Detailed_Logger_V5.116.mqh"
#include "Performance_Report_V5.116.mqh"
#include "AI_Data_V5.116.mqh"
#include "AI_Learning_V5.116.mqh"
#include "AI_Analyzer_V5.116.mqh"
#include "AI_VirtualTrader_V5.116.mqh"
#include "AI_Advisor_V5.116.mqh"
#include "Chart_Panel_V5.116.mqh"
#include "Test_Report_Logger_V5.116.mqh"
#include "Market_Truth_Logger_V5.116.mqh"
#include "Market_Detail_Report_V5.116.mqh"
#include "Scenario_VirtualTester_V5.116.mqh"
#include "Opportunity_Capture_Engine_V5.116.mqh"
#include "Backtest_Report_Engine_V5.116.mqh"
#include "Signal_Audit_Engine_V5.116.mqh"



//====================================================================
// متغیرهای سراسری AI
//====================================================================
AIVirtualEngineState   g_ai_virtual_engine;
AIVirtualTrade         g_virtual_trades[];
ulong                  g_virtual_scenario_id = 0;
AIAdvisorMessage       g_ai_advice;
AIPatternKnowledge     g_ai_pattern_knowledge;
AILearningSummary      g_ai_learning_summary;
ENUM_STRATEGY_TYPE      g_last_strategy_type = STRATEGY_NONE;
double                   g_last_strategy_confidence = 0.0;

//====================================================================
// وضعیت اصلی EA
//====================================================================
struct EAMainState
{
   bool      initialized;
   bool      trading_enabled;
   datetime  start_time;
   datetime  last_tick_time;
   datetime  last_monitor_time;
   datetime  last_analysis_time;
   datetime  last_analysis_bar;
   string    last_error;
};

//====================================================================
// متغیرهای سراسری
//====================================================================
EAMainState                g_main_state;
MarketContextSnapshot      g_context;
MarketRegimeState          g_regime;
MarketStructureSnapshot    g_structure;
ImpulseCorrectionSnapshot  g_move;
MarketTruthSnapshot        g_market_truth;
MarketReadingSnapshot      g_market_reading;
OpportunityCaptureSnapshot  g_opportunity_capture;
FilterAuditState           g_filter_audit;
ZoneInfo                   g_buy_zone;
ZoneInfo                   g_sell_zone;
M5MovementMetrics          g_m5_metrics;
M5ZoneQualitySnapshot      g_m5_zone_quality;
TradingScenario            g_scenario;
SetupState                 g_setup;
EntryPlan                  g_entry_plan;
SLPlan                     g_sl_plan;
TP_Result                  g_tp_result;
TargetInfo                 g_target;
RiskLimits                 g_risk_limits;
RiskAccountState           g_risk_account;
RiskResult                 g_risk_result;
PendingOrderRecord         g_pending;

//====================================================================
// سهمیه Pending برای هر Scenario
//====================================================================
#define TFLAB_PENDING_TRACK_LIMIT 20
PendingOrderRecord         g_pending_pool[];
ChartPanelState            g_panel;
PerformanceReportState     g_performance;
DetailedLoggerConfig       g_detailed_config;
DetailedLoggerState        g_detailed_state;
TestReportLoggerState      g_test_logger;
MarketTruthLoggerState     g_market_truth_logger;
MarketDetailReportState     g_market_detail_report;
BacktestReportState        g_backtest_report;
SignalAuditState            g_signal_audit;

//====================================================================
// رصد دقیقه‌ای بازار برای مدیریت TP و برگشت قطعی
//====================================================================
struct MinuteMarketMonitorState
{
   bool                valid;
   datetime            analysis_time;
   MarketRegimeState   m1_regime;
   MarketTruthSnapshot m5_truth;
   double              buy_continuation;
   double              sell_continuation;
   double              buy_reversal;
   double              sell_reversal;
};

MinuteMarketMonitorState g_minute_monitor;

struct DynamicTPTrackerState
{
   ulong    position_id;
   ulong    ticket;
   double   entry_price;
   double   initial_tp;
   double   initial_sl;
   double   initial_risk_distance;
   double   max_favorable_price;
   bool     profit_lock_armed;
   datetime first_seen;
   datetime last_seen;
};

DynamicTPTrackerState g_dynamic_tp_tracker[];

//====================================================================
// شناسه‌ها و حالت‌های ویژه
//====================================================================
datetime  g_last_m5_closed_bar        = 0;
datetime  g_last_fast_reversal_check = 0;
datetime  g_last_fast_reversal_score_refresh = 0;
string    g_last_scenario_diagnostic  = "";
ulong     g_last_executed_scenario_id = 0;
ulong     g_last_executed_opportunity_id = 0;
datetime  g_last_direct_opportunity_bar = 0;
double    g_last_direct_opportunity_anchor = 0.0;
ENUM_SCENARIO_DIRECTION g_last_direct_opportunity_direction = SCENARIO_DIRECTION_NONE;
bool      g_is_transition_mode        = false;
string    g_risk_block_reason         = "";
ulong     g_live_sell_block_scenario_id = 0;

//====================================================================
// دریافت قیمت جاری
//====================================================================
bool GetCurrentPrices(double &bid, double &ask, double &mid)
{
   bid = 0.0;
   ask = 0.0;
   mid = 0.0;

   MqlTick tick;
   if(!SymbolInfoTick(_Symbol, tick))
      return false;

   bid = tick.bid;
   ask = tick.ask;
   mid = (tick.bid + tick.ask) * 0.5;

   return (bid > 0.0 && ask > 0.0);
}

bool CalculateManualTPPrice(
   const ENUM_SCENARIO_DIRECTION direction,
   const double entry_price,
   const double volume,
   double &tp_price)
{
   tp_price = 0.0;

   if(!Inp_Use_Manual_TP)
      return false;

   if(entry_price <= 0.0 ||
      volume <= 0.0 ||
      Inp_Manual_TP_Profit_Money <= 0.0)
      return false;

   double tick_size =
      SymbolInfoDouble(
         _Symbol,
         SYMBOL_TRADE_TICK_SIZE);

   double tick_value =
      SymbolInfoDouble(
         _Symbol,
         SYMBOL_TRADE_TICK_VALUE_PROFIT);

   if(tick_value <= 0.0)
      tick_value =
         SymbolInfoDouble(
            _Symbol,
            SYMBOL_TRADE_TICK_VALUE);

   if(tick_size <= 0.0 ||
      tick_value <= 0.0)
      return false;

   const double price_distance =
      (Inp_Manual_TP_Profit_Money /
       (tick_value * volume)) *
      tick_size;

   if(price_distance <= 0.0)
      return false;

   if(direction == SCENARIO_DIRECTION_BUY)
      tp_price = entry_price + price_distance;
   else
   if(direction == SCENARIO_DIRECTION_SELL)
      tp_price = entry_price - price_distance;
   else
      return false;

   const int digits =
      (int)SymbolInfoInteger(
         _Symbol,
         SYMBOL_DIGITS);

   tp_price =
      NormalizeDouble(
         tp_price,
         digits);

   long stops_level_points =
      SymbolInfoInteger(
         _Symbol,
         SYMBOL_TRADE_STOPS_LEVEL);

   const double min_distance =
      (double)stops_level_points * _Point;

   if(min_distance > 0.0 &&
      direction == SCENARIO_DIRECTION_BUY &&
      (tp_price - entry_price) < min_distance)
      return false;

   if(min_distance > 0.0 &&
      direction == SCENARIO_DIRECTION_SELL &&
      (entry_price - tp_price) < min_distance)
      return false;

   return true;
}

bool ResolveRealTakeProfit(
   const ENUM_SCENARIO_DIRECTION direction,
   const double entry_price,
   const double volume,
   const double system_tp,
   double &real_tp)
{
   real_tp = system_tp;

   if(!Inp_Use_Manual_TP)
      return (real_tp > 0.0);

   if(!CalculateManualTPPrice(
      direction,
      entry_price,
      volume,
      real_tp))
   {
      Print(
         "[MANUAL TP] FAILED | مبلغ=",
         DoubleToString(
            Inp_Manual_TP_Profit_Money,
            2),
         " | Entry=",
         DoubleToString(
            entry_price,
            _Digits),
         " | Volume=",
         DoubleToString(
            volume,
            4));

      return false;
   }

   Print(
      "[MANUAL TP] ACTIVE | مبلغ هدف=",
      DoubleToString(
         Inp_Manual_TP_Profit_Money,
         2),
      " | Entry=",
      DoubleToString(
         entry_price,
         _Digits),
      " | TP=",
      DoubleToString(
         real_tp,
         _Digits),
      " | Volume=",
      DoubleToString(
         volume,
         4));

   return true;
}

bool IsRealTradingAllowed()
{
   if(!Inp_EnableTrading)
      return false;

   if(!TerminalInfoInteger(
      TERMINAL_CONNECTED))
      return false;

   if(!MQLInfoInteger(
      MQL_TRADE_ALLOWED))
      return false;

   if(!AccountInfoInteger(
      ACCOUNT_TRADE_ALLOWED))
      return false;

   if(!AccountInfoInteger(
      ACCOUNT_TRADE_EXPERT))
      return false;

   return true;
}

bool IsSpreadAcceptable(string &reason)
{
   reason = "";

   if(!Inp_Reject_If_Spread_High)
      return true;

   double bid =
      SymbolInfoDouble(
         _Symbol,
         SYMBOL_BID);

   double ask =
      SymbolInfoDouble(
         _Symbol,
         SYMBOL_ASK);

   if(bid <= 0.0 || ask <= 0.0)
      return true;

   double spread_points =
      (ask - bid) / _Point;

   if(Inp_Max_Spread_Points > 0.0 &&
      spread_points >
      Inp_Max_Spread_Points)
   {
      reason =
         "اسپرد لحظه‌ای=" +
         DoubleToString(
            spread_points, 1) +
         "pts > حداکثر مجاز=" +
         DoubleToString(
            Inp_Max_Spread_Points, 1) +
         "pts";

      return false;
   }

   return true;
}

bool IsMarketOpenForSymbol(string &reason)
{
   reason = "";

   if(!Inp_Reject_If_Market_Closed)
      return true;

   ENUM_SYMBOL_TRADE_MODE trade_mode =
      (ENUM_SYMBOL_TRADE_MODE)
      SymbolInfoInteger(
         _Symbol,
         SYMBOL_TRADE_MODE);

   if(trade_mode ==
      SYMBOL_TRADE_MODE_DISABLED)
   {
      reason =
         "معامله روی این نماد کاملاً غیرفعال است";
      return false;
   }

   MqlDateTime dt;
   TimeToStruct(TimeCurrent(), dt);

   datetime today_start =
      TimeCurrent() -
      (dt.hour * 3600 +
       dt.min * 60 +
       dt.sec);

   datetime now_seconds_from_midnight =
      TimeCurrent() - today_start;

   bool in_any_session = false;

   for(int s = 0; s < 5; s++)
   {
      datetime from1, to1;

      if(!SymbolInfoSessionTrade(
         _Symbol,
         (ENUM_DAY_OF_WEEK)dt.day_of_week,
         s,
         from1,
         to1))
         break;

      if(now_seconds_from_midnight >= from1 &&
         now_seconds_from_midnight <= to1)
      {
         in_any_session = true;
         break;
      }
   }

   if(!in_any_session)
   {
      reason =
         "بازار برای این نماد در حال حاضر بسته است (خارج از Session معاملاتی)";
      return false;
   }

   return true;
}

void CalculateDirectionalScores(
   const ENUM_HTF_DIRECTION htf,
   const bool has_buy,
   const bool has_sell,
   const bool htf_allows_buy,
   const bool htf_allows_sell,
   const bool regime_allows_buy,
   const bool regime_allows_sell,
   const bool streak_allows_buy,
   const bool streak_allows_sell,
   const bool divergence_blocks_buy,
   const bool divergence_blocks_sell,
   double &buy_score,
   double &sell_score)
{
   buy_score = 0.0;
   sell_score = 0.0;

   if(g_structure.state ==
      STRUCTURE_STATE_BULLISH)
      buy_score += 25.0;

   if(g_structure.state ==
      STRUCTURE_STATE_BEARISH)
      sell_score += 25.0;

   if(g_structure.bullish_sequence)
      buy_score += 20.0;

   if(g_structure.bearish_sequence)
      sell_score += 20.0;

   if(g_regime.valid &&
      g_regime.regime ==
      MARKET_REGIME_UPTREND)
      buy_score += 20.0;

   if(g_regime.valid &&
      g_regime.regime ==
      MARKET_REGIME_DOWNTREND)
      sell_score += 20.0;

   if(htf ==
      HTF_DIRECTION_BULLISH)
      buy_score += 15.0;

   if(htf ==
      HTF_DIRECTION_BEARISH)
      sell_score += 15.0;

   if(g_move.impulse_valid &&
      g_move.impulse_direction > 0)
      buy_score += 10.0;

   if(g_move.impulse_valid &&
      g_move.impulse_direction < 0)
      sell_score += 10.0;

   if(has_buy &&
      Zone_IsValid(g_buy_zone))
      buy_score += 10.0;

   if(has_sell &&
      Zone_IsValid(g_sell_zone))
      sell_score += 10.0;

   if(!htf_allows_buy)
      buy_score *= 0.70;

   if(!htf_allows_sell)
      sell_score *= 0.70;

   if(!regime_allows_buy)
      buy_score *= 0.80;

   if(!regime_allows_sell)
      sell_score *= 0.80;

   if(!streak_allows_buy)
      buy_score *= 0.90;

   if(!streak_allows_sell)
      sell_score *= 0.90;

   if(divergence_blocks_buy)
      buy_score *= 0.50;

   if(divergence_blocks_sell)
      sell_score *= 0.50;

   buy_score =
      MathMin(100.0,
      MathMax(0.0, buy_score));

   sell_score =
      MathMin(100.0,
      MathMax(0.0, sell_score));
}

bool StrongDirectionalLockAllows(
   const ENUM_SCENARIO_DIRECTION direction,
   const ENUM_HTF_DIRECTION htf)
{
   const bool strong_bearish =
      g_regime.valid &&
      g_regime.regime ==
      MARKET_REGIME_DOWNTREND &&
      (g_structure.state ==
         STRUCTURE_STATE_BEARISH ||
       htf ==
         HTF_DIRECTION_BEARISH);

   const bool strong_bullish =
      g_regime.valid &&
      g_regime.regime ==
      MARKET_REGIME_UPTREND &&
      (g_structure.state ==
         STRUCTURE_STATE_BULLISH ||
       htf ==
         HTF_DIRECTION_BULLISH);

   if(strong_bearish &&
      direction ==
      SCENARIO_DIRECTION_BUY)
      return false;

   if(strong_bullish &&
      direction ==
      SCENARIO_DIRECTION_SELL)
      return false;

   return true;
}

//====================================================================
// ساخت SL اجرایی سازگار با رفتار V5.70
//====================================================================
bool BuildExecutionSLFromScenario(
   const ENUM_SCENARIO_DIRECTION direction,
   const TradingScenario &scenario,
   const double atr_price,
   SLPlan &plan)
{
   const ENUM_SL_DIRECTION sl_dir =
      (direction == SCENARIO_DIRECTION_BUY
       ? SL_DIRECTION_BUY
       : SL_DIRECTION_SELL);

   if(direction != SCENARIO_DIRECTION_BUY &&
      direction != SCENARIO_DIRECTION_SELL)
      return false;

   return SL_FromMarketReferences(
      _Symbol,
      sl_dir,
      scenario.entry_price,
      g_structure,
      atr_price,
      _Point,
      plan);
}

//====================================================================
// تعداد معاملات باز
//====================================================================
int CountOpenPositions()
{
   int count = 0;

   for(int i = 0; i < PositionsTotal(); i++)
   {
      ulong ticket = PositionGetTicket(i);
      if(ticket == 0)
         continue;

      if(!PositionSelectByTicket(ticket))
         continue;

      if(PositionGetString(POSITION_SYMBOL) != _Symbol)
         continue;

      if((ulong)PositionGetInteger(POSITION_MAGIC) != Inp_MagicNumber)
         continue;

      count++;
   }

   return count;
}

//====================================================================
// تعداد سفارش‌های Pending فعال این ربات
//====================================================================
int CountPendingOrders()
{
   int count = 0;

   for(int i = 0; i < OrdersTotal(); i++)
   {
      ulong ticket = OrderGetTicket(i);
      if(ticket == 0)
         continue;

      if(OrderGetString(ORDER_SYMBOL) != _Symbol)
         continue;

      if((ulong)OrderGetInteger(ORDER_MAGIC) != Inp_MagicNumber)
         continue;

      count++;
   }

   return count;
}

//====================================================================
// تعداد کل موقعیت‌ها
//====================================================================
int CountTotalExposure()
{
   return CountOpenPositions() + CountPendingOrders();
}

//====================================================================
// سود معاملات باز
//====================================================================
double OpenProfit()
{
   double value = 0.0;

   for(int i = 0; i < PositionsTotal(); i++)
   {
      ulong ticket = PositionGetTicket(i);

      if(ticket == 0 || !PositionSelectByTicket(ticket))
         continue;

      if(PositionGetString(POSITION_SYMBOL) != _Symbol)
         continue;

      if(!Inp_Show_All_Trades_In_Panel)
      {
         if((ulong)PositionGetInteger(POSITION_MAGIC) != Inp_MagicNumber)
            continue;
      }

      value += PositionGetDouble(POSITION_PROFIT);
      value += PositionGetDouble(POSITION_SWAP);
   }

   return value;
}

//====================================================================
// بررسی سریع تعلق Deal به همین EA
//====================================================================
bool IsEAHistoryDealTicket(const ulong deal_ticket)
{
   if(deal_ticket == 0)
      return false;

   if(HistoryDealGetString(deal_ticket, DEAL_SYMBOL) != _Symbol)
      return false;

   if((ulong)HistoryDealGetInteger(deal_ticket, DEAL_MAGIC) ==
      (ulong)Inp_MagicNumber)
      return true;

   ulong order_ticket =
      (ulong)HistoryDealGetInteger(deal_ticket, DEAL_ORDER);

   if(order_ticket > 0 && HistoryOrderSelect(order_ticket))
   {
      if((ulong)HistoryOrderGetInteger(order_ticket, ORDER_MAGIC) ==
         (ulong)Inp_MagicNumber)
         return true;
   }

   return false;
}

//====================================================================
// بررسی کامل تعلق Deal به همین EA
//====================================================================
bool DealBelongsToEA(const ulong deal_ticket)
{
   if(deal_ticket == 0)
      return false;

   if(HistoryDealGetString(deal_ticket, DEAL_SYMBOL) != _Symbol)
      return false;

   if((ulong)HistoryDealGetInteger(deal_ticket, DEAL_MAGIC) ==
      (ulong)Inp_MagicNumber)
      return true;

   ulong order_ticket =
      (ulong)HistoryDealGetInteger(deal_ticket, DEAL_ORDER);

   if(order_ticket > 0 && HistoryOrderSelect(order_ticket))
   {
      if((ulong)HistoryOrderGetInteger(order_ticket, ORDER_MAGIC) ==
         (ulong)Inp_MagicNumber)
         return true;
   }

   ulong position_id =
      (ulong)HistoryDealGetInteger(deal_ticket, DEAL_POSITION_ID);

   if(position_id == 0)
      return false;

   uint total = (uint)HistoryDealsTotal();

   for(uint i = 0; i < total; i++)
   {
      ulong related = HistoryDealGetTicket(i);

      if(related == 0)
         continue;

      if((ulong)HistoryDealGetInteger(
            related, DEAL_POSITION_ID) != position_id)
         continue;

      if((ulong)HistoryDealGetInteger(
            related, DEAL_MAGIC) == (ulong)Inp_MagicNumber)
         return true;

      ulong related_order =
         (ulong)HistoryDealGetInteger(related, DEAL_ORDER);

      if(related_order > 0 && HistoryOrderSelect(related_order))
      {
         if((ulong)HistoryOrderGetInteger(
               related_order, ORDER_MAGIC) ==
            (ulong)Inp_MagicNumber)
            return true;
      }
   }

   return false;
}

//====================================================================
// نرمال‌سازی حجم
//====================================================================
double NormalizeVolume(const double volume)
{
   double step = SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_STEP);
   double minv = SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_MIN);
   double maxv = SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_MAX);

   if(step <= 0.0)
      return volume;

   double v = MathRound(volume / step) * step;

   if(v < minv)
      v = minv;

   if(v > maxv)
      v = maxv;

   return NormalizeDouble(v, 8);
}

//====================================================================
// ساخت کامنت استاندارد سناریو
//====================================================================
string MakeScenarioComment(
   const ulong scenario_id,
   const double tp1,
   const double tp2,
   const double sl_price = 0.0)
{
   string comment =
      "TFlab S#" + (string)scenario_id +
      " | TP1=" + DoubleToString(tp1, _Digits) +
      " | TP2=" + DoubleToString(tp2, _Digits);

   if(sl_price > 0.0)
      comment += " | SL=" + DoubleToString(sl_price, _Digits);

   return comment;
}

//====================================================================
// استخراج ScenarioID از کامنت
//====================================================================
ulong FindScenarioIdByPositionId(const ulong position_id)
{
   if(position_id == 0)
      return 0;

   if(!HistorySelect(0, TimeCurrent()))
      return 0;

   int total = HistoryDealsTotal();

   for(int i = 0; i < total; i++)
   {
      ulong ticket = HistoryDealGetTicket(i);

      if(ticket == 0)
         continue;

      if((ulong)HistoryDealGetInteger(
            ticket, DEAL_POSITION_ID) != position_id)
         continue;

      if((ENUM_DEAL_ENTRY)HistoryDealGetInteger(
            ticket, DEAL_ENTRY) != DEAL_ENTRY_IN)
         continue;

      string comment =
         HistoryDealGetString(ticket, DEAL_COMMENT);

      int p1 = StringFind(comment, "S#");

      if(p1 < 0)
         continue;

      p1 += 2;

      int p2 = StringFind(comment, " ", p1);

      string id_str =
         (p2 > p1
          ? StringSubstr(comment, p1, p2 - p1)
          : StringSubstr(comment, p1));

      return (ulong)StringToInteger(id_str);
   }

   return 0;
}

//====================================================================
// سود/ضرر بسته‌شده امروز
//====================================================================
double TodayClosedProfit()
{
   datetime day_start =
      StringToTime(TimeToString(TimeCurrent(), TIME_DATE));

   if(!HistorySelect(day_start, TimeCurrent()))
      return 0.0;

   double value = 0.0;
   int counted_ea = 0;
   int counted_manual = 0;

   uint total = (uint)HistoryDealsTotal();

   for(uint i = 0; i < total; i++)
   {
      ulong ticket = HistoryDealGetTicket(i);

      if(ticket == 0)
         continue;

      if(HistoryDealGetString(ticket, DEAL_SYMBOL) != _Symbol)
         continue;

      ENUM_DEAL_ENTRY entry =
         (ENUM_DEAL_ENTRY)HistoryDealGetInteger(ticket, DEAL_ENTRY);

      if(entry != DEAL_ENTRY_OUT &&
         entry != DEAL_ENTRY_OUT_BY &&
         entry != DEAL_ENTRY_INOUT)
         continue;

      if(!Inp_Show_All_Trades_In_Panel)
      {
         if((ulong)HistoryDealGetInteger(ticket, DEAL_MAGIC) !=
            (ulong)Inp_MagicNumber)
            continue;
      }
      else
      {
         if((ulong)HistoryDealGetInteger(ticket, DEAL_MAGIC) ==
            (ulong)Inp_MagicNumber)
            counted_ea++;
         else
            counted_manual++;
      }

      value += HistoryDealGetDouble(ticket, DEAL_PROFIT);
      value += HistoryDealGetDouble(ticket, DEAL_SWAP);
      value += HistoryDealGetDouble(ticket, DEAL_COMMISSION);
      value += HistoryDealGetDouble(ticket, DEAL_FEE);
   }

   if(Inp_Show_All_Trades_In_Panel)
   {
      static datetime last_log = 0;

      if(TimeCurrent() - last_log > 60)
      {
         Print("[PROFIT CALC] Mode=ALL | EA Trades=", counted_ea,
               " | Manual Trades=", counted_manual,
               " | Total=", DoubleToString(value, 2), "$");

         last_log = TimeCurrent();
      }
   }

   return value;
}

//====================================================================
// سود/ضرر امروز
//====================================================================
double TodayTotalProfit()
{
   return TodayClosedProfit() + OpenProfit();
}

//====================================================================
// ریست Metrics گزارش
//====================================================================
void ResetReportMetrics()
{
   M5MovementMetrics_Reset(g_m5_metrics);
   M5ZoneQuality_Reset(g_m5_zone_quality);
}

//====================================================================
// به‌روزرسانی Metrics گزارش
//====================================================================
void UpdateReportMetrics(const double current_price)
{
   ResetReportMetrics();

   bool metrics_ok =
      M5MovementMetrics_Analyze(
         _Symbol,
         PERIOD_M5,
         20,
         0.0,
         Inp_ATR_Period,
         g_m5_metrics);

   if(!metrics_ok ||
      !M5MovementMetrics_IsValid(g_m5_metrics))
   {
      Print("[M5 Metrics] گزارش | FAILED | ",
            g_m5_metrics.reason);
      return;
   }

   bool zone_quality_ok =
      M5ZoneQuality_Analyze(
         g_m5_metrics,
         g_buy_zone,
         g_sell_zone,
         current_price,
         g_m5_zone_quality);

   if(!zone_quality_ok ||
      !M5ZoneQuality_IsValid(g_m5_zone_quality))
   {
      Print("[M5 Zone Quality] گزارش | FAILED | ",
            g_m5_zone_quality.reason);
      return;
   }

   Print("[M5 Zone Quality] Snapshot",
      " | MovementQuality=",
      DoubleToString(
         g_m5_zone_quality.movement_quality_score, 2),
      " | ZoneQuality=",
      DoubleToString(
         g_m5_zone_quality.zone_quality_score, 2),
      " | Proximity=",
      DoubleToString(
         g_m5_zone_quality.proximity_score, 2),
      " | Alignment=",
      DoubleToString(
         g_m5_zone_quality.movement_alignment_score, 2),
      " | Combined=",
      DoubleToString(
         g_m5_zone_quality.combined_quality_score, 2),
      " | NearestDistance=",
      DoubleToString(
         g_m5_zone_quality.nearest_zone_distance_points, 1),
      " | NearestStrength=",
      DoubleToString(
         g_m5_zone_quality.nearest_zone_strength, 2),
      " | Position=",
      M5ZoneQuality_PositionToPersian(
         g_m5_zone_quality.zone_position));
}

//====================================================================
// اعتبارسنجی Inputs
//====================================================================
bool ValidateInputs()
{
   if(Inp_MaxOpenTrades < 1)
      return false;

   if(Inp_Simultaneous_Trades < 1)
      return false;

   if(Inp_Max_Active_Zones < 1)
      return false;

   if(Inp_Max_Active_Scenarios < 1)
      return false;

   if(Inp_Monitor_Update_Seconds < 1)
      return false;

   if(Inp_Monitor_Confirm_Minutes < 1)
      return false;

   if(Inp_Risk_Per_Trade_Percent <= 0.0 ||
      Inp_Risk_Per_Trade_Percent >
      Inp_Max_Risk_Per_Trade_Percent)
      return false;

   if(Inp_Max_Portfolio_Risk_Percent <= 0.0 ||
      Inp_Max_Directional_Risk_Percent <= 0.0)
      return false;

   if(Inp_Min_RR <= 0.0 ||
      Inp_Max_RR < Inp_Min_RR)
      return false;

   if(Inp_Partial_Close_Mode == PARTIAL_CLOSE_PERCENT &&
      (Inp_Partial_Close_Percent <= 0.0 ||
       Inp_Partial_Close_Percent > 100.0))
      return false;

   if(Inp_Breakeven_Offset_Points < 0.0)
      return false;

   if(Inp_AI_Minimum_Samples < 1)
      return false;
   if(Inp_Buy_TruthConflict_StrongMove_ATR < 0.0)
      return false;
   if(Inp_Buy_TruthConflict_Min_Support < 3.0 || Inp_Buy_TruthConflict_Min_Support > 5.0)
      return false;
   if(Inp_Buy_Direct_Exhaustion_Truth_ATR < 0.0 ||
      Inp_Buy_Direct_Exhaustion_Impulse_ATR < 0.0)
      return false;
   if(Inp_Buy_ProtectiveReversal_Min_Scenario_Quality < 0.0 ||
      Inp_Buy_ProtectiveReversal_Min_Scenario_Quality > 100.0)
      return false;

   if(Inp_Use_Manual_TP &&
      Inp_Manual_TP_Profit_Money <= 0.0)
      return false;

   return true;
}

//====================================================================
// ساخت BUY Zone
//====================================================================
bool BuildBuyZone(
   const MarketStructureSnapshot &structure,
   const double atr_price,
   ZoneInfo &zone)
{
   Zone_Init(zone);

   if(!structure.last_low.valid ||
      structure.last_low.price <= 0.0 ||
      atr_price <= 0.0)
      return false;

   double width =
      MathMax(atr_price * 0.35, _Point * 10.0);

   double lower = structure.last_low.price;
   double upper = lower + width;

   double invalidation =
      lower - MathMax(
         atr_price * 0.15,
         _Point * 2.0);

   return Zone_Create(
      1,
      ZONE_TYPE_STRUCTURE,
      ZONE_DIRECTION_BUY,
      lower,
      upper,
      invalidation,
      TimeCurrent(),
      0,
      Inp_TF_Structure_M15,
      MathMax(
         1.0,
         structure.structure_range_points),
      "MarketStructure",
      "ساخت Zone خرید از آخرین Swing Low",
      zone);
}

//====================================================================
// ساخت SELL Zone
//====================================================================
bool BuildSellZone(
   const MarketStructureSnapshot &structure,
   const double atr_price,
   ZoneInfo &zone)
{
   Zone_Init(zone);

   if(!structure.last_high.valid ||
      structure.last_high.price <= 0.0 ||
      atr_price <= 0.0)
      return false;

   double width =
      MathMax(atr_price * 0.35, _Point * 10.0);

   double upper = structure.last_high.price;
   double lower = upper - width;

   double invalidation =
      upper + MathMax(
         atr_price * 0.15,
         _Point * 2.0);

   return Zone_Create(
      2,
      ZONE_TYPE_STRUCTURE,
      ZONE_DIRECTION_SELL,
      lower,
      upper,
      invalidation,
      TimeCurrent(),
      0,
      Inp_TF_Structure_M15,
      MathMax(
         1.0,
         structure.structure_range_points),
      "MarketStructure",
      "ساخت Zone فروش از آخرین Swing High",
      zone);
}

//====================================================================
// لاگ چرخه
//====================================================================
void LogCycle(
   const string stage,
   const string message,
   const double v1 = 0.0,
   const double v2 = 0.0)
{
   if(!Inp_Enable_Detailed_Log ||
      !g_detailed_state.initialized)
      return;

   DetailedLogger_Log(
      DLOG_LEVEL_INFO,
      DLOG_CATEGORY_SYSTEM,
      "CYCLE",
      stage,
      g_panel.direction,
      g_panel.scenario,
      message,
      _Symbol,
      (ENUM_TIMEFRAMES)_Period,
      v1,
      v2,
      0.0,
      0.0,
      0.0,
      0.0,
      g_sl_plan.stop_price,
      g_scenario.target_1,
      g_scenario.id,
      g_pending.ticket,
      0,
      g_detailed_config,
      g_detailed_state);
}

//====================================================================
// ثبت Diagnostic سناریو
//====================================================================
void SetScenarioDiagnostic(const string reason)
{
   g_last_scenario_diagnostic = reason;

   Print("[SCENARIO DIAGNOSTIC] ", reason);

   if(Inp_Enable_Detailed_Log &&
      g_detailed_state.initialized)
      LogCycle("SCENARIO_DIAGNOSTIC", reason);
}

//====================================================================
// لغو Pending فعال
//====================================================================
void CancelActivePending(const string reason)
{
   if(g_pending.ticket == 0 ||
      !g_pending.active)
      return;

   if(Inp_Cancel_Pending_On_Invalid)
      PendingOrder_Cancel(
         g_pending,
         reason,
         TimeCurrent());
}

//====================================================================
// ریست کامل State سناریوی فعال
//====================================================================
//====================================================================
// حفظ Pending معتبر هم‌جهت هنگام تغییر سناریو
// Pending فقط وقتی کنار گذاشته می‌شود که جهت سناریوی جدید مخالف
// باشد یا خود سفارش به سطح حد ضرر رسیده باشد.
//====================================================================
bool PreservePendingOnSameDirectionScenarioChange(
   const PendingOrderRecord &pending)
{
   if(!Inp_Opportunity_Preserve_Same_Direction_Pending)
      return false;

   if(!pending.active ||
      pending.ticket == 0)
      return false;

   if(g_scenario.id <= 0 ||
      g_scenario.direction == SCENARIO_DIRECTION_NONE)
      return false;

   if(pending.direction != g_scenario.direction)
      return false;

   double bid = SymbolInfoDouble(_Symbol,SYMBOL_BID);
   double ask = SymbolInfoDouble(_Symbol,SYMBOL_ASK);

   if(bid <= 0.0 || ask <= 0.0)
      return false;

   if(pending.stop_loss > 0.0)
   {
      if(pending.direction == SCENARIO_DIRECTION_BUY &&
         ask <= pending.stop_loss)
         return false;

      if(pending.direction == SCENARIO_DIRECTION_SELL &&
         bid >= pending.stop_loss)
         return false;
   }

   return true;
}

//====================================================================
// ریست State تحلیل بدون حذف Pending واقعی
//====================================================================
void ResetScenarioAnalysisStateKeepPending(const string reason)
{
   Scenario_Init(g_scenario);
   ZeroMemory(g_sl_plan);
   TP_Init(g_tp_result);
   Target_Init(g_target);
   EntryPlan_Init(g_entry_plan);

   g_is_transition_mode = false;
   g_live_sell_block_scenario_id = 0;
   g_risk_block_reason = "";

   g_entry_plan.type = ENTRY_PLAN_WAIT;
   g_entry_plan.status = ENTRY_PLAN_STATUS_PLANNED;
   g_entry_plan.executable = false;
   g_entry_plan.entry_currently_available = false;
   g_entry_plan.entry_reachable = false;
   g_entry_plan.reason = reason;

   Print("[SCENARIO RESET KEEP PENDING] تحلیل جدید شکست خورد؛ Pending معتبر حفظ شد | Reason=",reason);
}

void ResetActiveScenarioState(const string reason)
{
   if(g_scenario.id > 0)
      CancelPendingOrdersForScenario(g_scenario.id, reason);

   if(g_pending.ticket > 0 &&
      g_pending.active)
   {
      CancelActivePending(reason);
   }

   PendingOrder_Init(g_pending);

   Scenario_Init(g_scenario);

   ZeroMemory(g_sl_plan);

   TP_Init(g_tp_result);

   Target_Init(g_target);

   EntryPlan_Init(g_entry_plan);

   g_last_executed_scenario_id = 0;
   // قفل Opportunity عمداً در Reset سناریو پاک نمی‌شود؛ یک Opportunity نباید
   // پس از پاک‌شدن Scenario دوباره به‌صورت تکراری معامله شود.
   g_virtual_scenario_id        = 0;
   g_is_transition_mode         = false;
   g_risk_block_reason          = "";

   Print("[SCENARIO RESET] کامل انجام شد | Reason=", reason);
}

//====================================================================
// اتصال سناریوی معتبر به Virtual Tester
//====================================================================
//====================================================================
// V5.116: تازگی Scenario بر اساس چند کندل بسته‌شده M5
// سناریوی معتبر می‌تواند برای تعداد محدودی کندل زنده بماند؛
// بازاعتبارسنجی زنده همچنان قبل از اجرای واقعی انجام می‌شود.
//====================================================================
bool EnforceActiveScenarioFreshness()
{
   if(g_scenario.id <= 0 ||
      !Scenario_IsValid(g_scenario))
      return true;

   if(g_scenario.status == SCENARIO_STATUS_TRIGGERED ||
      g_scenario.status == SCENARIO_STATUS_EXECUTED)
      return true;

   const datetime live_m5_bar =
      iTime(_Symbol,Inp_TF_Setup_M5,1);

   if(live_m5_bar <= 0 ||
      g_scenario.created_m5_bar_time <= 0 ||
      live_m5_bar == g_scenario.created_m5_bar_time)
      return true;

   const int created_shift =
      iBarShift(_Symbol,Inp_TF_Setup_M5,g_scenario.created_m5_bar_time,false);

   int allowed_m5_bars = Inp_Entry_Revalidation_Max_M5_Bars;
   if(g_opportunity_capture.valid &&
      g_opportunity_capture.priority &&
      g_opportunity_capture.direction == g_scenario.direction)
      allowed_m5_bars = MathMax(
         allowed_m5_bars,
         Inp_Opportunity_Pending_Max_M5_Bars);

   if(created_shift >= 0 &&
      allowed_m5_bars > 0 &&
      (created_shift - 1) <= allowed_m5_bars)
      return true;

   const ulong stale_id = g_scenario.id;
   Print("[SCENARIO FRESHNESS] Scenario از سقف عمر M5 عبور کرد | ID=",stale_id,
         " | MaxBars=",allowed_m5_bars);

   CancelPendingOrdersForScenario(stale_id,"عمر M5 سناریو به سقف مجاز رسید");
   ResetActiveScenarioState("عمر M5 سناریو به سقف مجاز رسید و نیاز به تحلیل تازه است");
   SetScenarioDiagnostic("SCENARIO_STALE | عمر مجاز چند کندلی سناریو به پایان رسید");
   return false;
}

//====================================================================
// بازاعتبارسنجی شرایط درست پیش از اجرای Market
//====================================================================
bool EntryGate_RevalidateBeforeExecution(
   const ENUM_SCENARIO_DIRECTION direction,
   const double live_price,
   string &reason)
{
   reason = "";

   if(!Inp_Enable_Entry_Revalidation ||
      !Inp_Enable_Entry_Decision_Gate)
      return true;

   if(live_price <= 0.0)
   {
      reason = "قیمت لحظه اجرای ورود معتبر نیست";
      return false;
   }

   // V5.116: برنامه‌ای که مستقیماً از Opportunity ساخته شده، پیشاپیش
   // Truth + Structure + Pressure + جهت زنده + حرکت M5 را همان لحظه تأیید کرده است.
   // بنابراین بازاعتبارسنجی عمومی Scenario نباید دوباره آن را به سناریوی قدیمی
   // یا محدودیت‌های مخصوص Continuation وابسته کند. کنترل‌های Market/Risk/Broker
   // همچنان در مسیر اصلی اجرا اجباری هستند.
   if(StringFind(g_entry_plan.reason,"فرصت مستقیم ورود لحظه‌ای") >= 0)
   {
      reason = "Opportunity مستقیم قبلاً در لحظه جاری بازاعتبارسنجی کامل شده است";
      return true;
   }

   // V5.116: سناریوی معتبر می‌تواند چند کندل M5 زنده بماند.
   const datetime live_m5_bar =
      iTime(_Symbol,Inp_TF_Setup_M5,1);

   if(g_scenario.created_m5_bar_time > 0 &&
      live_m5_bar > 0 &&
      live_m5_bar != g_scenario.created_m5_bar_time)
   {
      const int created_shift =
         iBarShift(_Symbol,Inp_TF_Setup_M5,g_scenario.created_m5_bar_time,false);

      if(created_shift < 0 ||
         Inp_Entry_Revalidation_Max_M5_Bars <= 0 ||
         (created_shift - 1) > Inp_Entry_Revalidation_Max_M5_Bars)
      {
         reason = "عمر Scenario از سقف مجاز M5 عبور کرده است";
         return false;
      }
   }

   // ابتدا Invalidaton خود Scenario را در قیمت واقعی بررسی می‌کنیم.
   if(g_scenario.invalidation_price > 0.0)
   {
      if(direction == SCENARIO_DIRECTION_BUY &&
         live_price <= g_scenario.invalidation_price)
      {
         reason = "قیمت لحظه اجرا به محدوده ابطال BUY رسیده است";
         return false;
      }

      if(direction == SCENARIO_DIRECTION_SELL &&
         live_price >= g_scenario.invalidation_price)
      {
         reason = "قیمت لحظه اجرا به محدوده ابطال SELL رسیده است";
         return false;
      }
   }

   ZoneInfo live_zone;
   Zone_Init(live_zone);

   if(direction == SCENARIO_DIRECTION_BUY)
      live_zone = g_buy_zone;
   else
   if(direction == SCENARIO_DIRECTION_SELL)
      live_zone = g_sell_zone;

   if(Zone_IsValid(live_zone) &&
      Zone_CheckInvalidation(live_zone, live_price))
   {
      reason =
         (direction == SCENARIO_DIRECTION_BUY
          ? "Zone خرید در لحظه اجرا دیگر معتبر نیست"
          : "Zone فروش در لحظه اجرا دیگر معتبر نیست");
      return false;
   }

   const bool is_continuation =
      EntryGate_IsContinuationStrategy(
         g_last_strategy_type);

   // Truth باید در تمام طول بازاعتبارسنجی در دسترس باشد.
   MarketTruthSnapshot live_truth;
   MarketTruth_Reset(live_truth);

   // Truth باید در همان لحظه اجرا دوباره خوانده شود.
   if(Inp_Use_Market_Truth)
   {
      const bool truth_ok =
         MarketTruth_Analyze(
            _Symbol,
            Inp_TF_Setup_M5,
            Inp_Market_Truth_Lookback,
            live_truth);

      if(!truth_ok || !live_truth.valid)
      {
         reason = "بازاعتبارسنجی Truth پیش از اجرا ناموفق بود";
         return false;
      }

      {
         const bool live_truth_conflict =
            (direction == SCENARIO_DIRECTION_BUY &&
             live_truth.direction == MARKET_TRUTH_SELL) ||
            (direction == SCENARIO_DIRECTION_SELL &&
             live_truth.direction == MARKET_TRUTH_BUY);

         if(live_truth_conflict &&
            live_truth.strong_market_move &&
            live_truth.phase == MARKET_TRUTH_PHASE_REVERSAL &&
            live_truth.move_atr_multiple >= 2.50)
         {
            reason =
               "در لحظه اجرا Truth وارد REVERSAL قویِ خلاف جهت شده است؛ ورود تا تأیید ساختار مخالف متوقف شد" +
               " | Truth=" +
               MarketTruth_DirectionToString(live_truth.direction) +
               " | MoveATR=" +
               DoubleToString(live_truth.move_atr_multiple,2);

            Print(
               "[LIVE TRUTH REVERSAL WAIT] ورود متوقف شد | Direction=",
               direction == SCENARIO_DIRECTION_BUY ? "خرید" : "فروش",
               " | Truth=",
               MarketTruth_DirectionToString(live_truth.direction),
               " | MoveATR=",
               DoubleToString(live_truth.move_atr_multiple,2));
            return false;
         }

         const bool live_truth_conflict_recheck =
            (direction == SCENARIO_DIRECTION_BUY &&
             live_truth.direction == MARKET_TRUTH_SELL) ||
            (direction == SCENARIO_DIRECTION_SELL &&
             live_truth.direction == MARKET_TRUTH_BUY);

         if(live_truth_conflict_recheck &&
            live_truth.strong_market_move &&
            live_truth.continuation_ready)
         {
            reason =
               (direction == SCENARIO_DIRECTION_BUY
                ? "BUY در لحظه اجرا با جهت قوی Market Truth مخالف است"
                : "SELL در لحظه اجرا با جهت قوی Market Truth مخالف است") +
               " | Truth=" +
               MarketTruth_DirectionToString(live_truth.direction) +
               " | MoveATR=" +
               DoubleToString(live_truth.move_atr_multiple,2);

            Print(
               "[LIVE TRUTH HARD BLOCK] ورود متوقف شد | Direction=",
               direction == SCENARIO_DIRECTION_BUY ? "خرید" : "فروش",
               " | Truth=",
               MarketTruth_DirectionToString(live_truth.direction),
               " | MoveATR=",
               DoubleToString(live_truth.move_atr_multiple,2));
            return false;
         }
      }
   }

   if(!is_continuation)
      return true;

   // Regime در لحظه Fill دوباره بررسی می‌شود؛ Range/Transition
   // صرفاً به خاطر نامشان مسدود نمی‌شوند، فقط تضاد صریح با جهت مهم است.
   MarketRegimeState live_regime;
   MarketRegime_Reset(live_regime);

   const bool regime_ok =
      MarketRegime_Analyze(
         _Symbol,
         Inp_TF_Context_M30,
         Inp_ADX_Period,
         Inp_RSI_Period,
         Inp_EMA_Trend_Period,
         Inp_ATR_Period,
         Inp_ADX_Min_Trend,
         Inp_ADX_Exhaustion_Level,
         Inp_RSI_Overbought,
         Inp_RSI_Oversold,
         Inp_Max_Price_EMA_ATR_Distance,
         live_regime);

   if(!regime_ok || !live_regime.valid)
   {
      reason = "بازاعتبارسنجی Regime پیش از اجرا ناموفق بود";
      return false;
   }

   if(live_regime.confidence >= Inp_Min_Regime_Confidence)
   {
      if(direction == SCENARIO_DIRECTION_BUY &&
         live_regime.regime == MARKET_REGIME_DOWNTREND)
      {
         reason =
            "Regime در لحظه اجرا نزولی شده و BUY Continuation متوقف شد";
         return false;
      }

      if(direction == SCENARIO_DIRECTION_SELL &&
         live_regime.regime == MARKET_REGIME_UPTREND)
      {
         reason =
            "Regime در لحظه اجرا صعودی شده و SELL Continuation متوقف شد";
         return false;
      }
   }

   MarketStructureSnapshot live_structure;
   MarketStructure_Reset(live_structure);

   const bool structure_ok =
      MarketStructure_Analyze(
         _Symbol,
         Inp_TF_Structure_M15,
         120,
         2,
         2,
         20.0,
         live_structure);

   if(!structure_ok || !live_structure.valid)
   {
      reason = "بازاعتبارسنجی Structure پیش از اجرا ناموفق بود";
      return false;
   }

   if(direction == SCENARIO_DIRECTION_BUY &&
      live_structure.state == STRUCTURE_STATE_BEARISH)
   {
      reason =
         "Structure در لحظه اجرا نزولی شده و BUY Continuation متوقف شد";
      return false;
   }

   if(direction == SCENARIO_DIRECTION_SELL &&
      live_structure.state == STRUCTURE_STATE_BULLISH)
   {
      reason =
         "Structure در لحظه اجرا صعودی شده و SELL Continuation متوقف شد";
      return false;
   }

   ImpulseCorrectionSnapshot live_move;
   ImpulseCorrection_Reset(live_move);

   const bool move_ok =
      ImpulseCorrection_Analyze(
         _Symbol,
         Inp_TF_Setup_M5,
         120,
         2,
         2,
         20.0,
         live_move);

   if(!move_ok || !live_move.valid)
   {
      reason = "بازاعتبارسنجی حرکت پیش از اجرا ناموفق بود";
      return false;
   }

   if(live_move.impulse_valid &&
      live_move.impulse_direction ==
         (direction == SCENARIO_DIRECTION_BUY ? -1 : 1) &&
      !live_move.correction_valid)
   {
      reason =
         "جهت حرکت M5 در لحظه اجرا مخالف Continuation است و اصلاح معتبر هم وجود ندارد";
      return false;
   }

   // Truth مخالف در لحظه Fill فقط وقتی قابل‌تحمل است که Structure و Regime
   // هنوز هر دو Scenario را پشتیبانی کنند. این بخش ریسک را همچنان محدود نگه می‌دارد.
   if(live_truth.direction ==
      (direction == SCENARIO_DIRECTION_BUY
       ? MARKET_TRUTH_SELL
       : MARKET_TRUTH_BUY) &&
      live_truth.strong_market_move &&
      live_truth.continuation_ready)
   {
      reason =
         (direction == SCENARIO_DIRECTION_BUY
          ? "BUY با Market Truth قوی مخالف است"
          : "SELL با Market Truth قوی مخالف است") +
         " | Truth=" +
         MarketTruth_DirectionToString(live_truth.direction) +
         " | MoveATR=" +
         DoubleToString(live_truth.move_atr_multiple,2);
      Print("[LIVE TRUTH HARD BLOCK] تضاد نهایی قبل از Fill مسدود شد");
      return false;
   }

   return true;
}

//====================================================================
// ساخت سناریوی ادامه روند قوی
//====================================================================
bool BuildStrongTrendContinuationScenario(
   const ENUM_SCENARIO_DIRECTION direction,
   const ZoneInfo &zone,
   const double current_price,
   TradingScenario &scenario,
   StrategyResult &strategy_result)
{
   Scenario_Init(scenario);
   Strategy_Reset(strategy_result);

   if(!Zone_IsValid(zone) ||
      current_price <= 0.0)
      return false;

   if(direction ==
      SCENARIO_DIRECTION_SELL)
   {
      if(g_structure.state !=
            STRUCTURE_STATE_BEARISH ||
         !g_structure.bearish_sequence ||
         !g_regime.valid ||
         g_regime.regime !=
            MARKET_REGIME_DOWNTREND ||
         !g_move.impulse_valid ||
         g_move.impulse_direction >= 0 ||
         zone.direction !=
            ZONE_DIRECTION_SELL)
         return false;
   }
   else
   if(direction ==
      SCENARIO_DIRECTION_BUY)
   {
      if(g_structure.state !=
            STRUCTURE_STATE_BULLISH ||
         !g_structure.bullish_sequence ||
         !g_regime.valid ||
         g_regime.regime !=
            MARKET_REGIME_UPTREND ||
         !g_move.impulse_valid ||
         g_move.impulse_direction <= 0 ||
         zone.direction !=
            ZONE_DIRECTION_BUY)
         return false;
   }
   else
      return false;

   if(!Scenario_CreateFromEvidence(
      _Symbol,
      direction,
      g_regime,
      g_context,
      g_structure,
      g_move,
      zone,
      scenario))
      return false;

   scenario.quality_value = 100.0;

   scenario.general_reason =
      (direction ==
         SCENARIO_DIRECTION_SELL
       ?
         "Continuation نزولی قوی | Structure + Regime + Impulse + SELL Zone"
       :
         "Continuation صعودی قوی | Structure + Regime + Impulse + BUY Zone");

   strategy_result.valid = true;

   strategy_result.type =
      (direction ==
         SCENARIO_DIRECTION_SELL
       ?
         STRATEGY_SELL_CONTINUATION
       :
         STRATEGY_BUY_CONTINUATION);

   strategy_result.direction =
      direction;

   strategy_result.quality =
      scenario.quality_value;

   strategy_result.confidence =
      scenario.quality_value;

   strategy_result.zone_id =
      zone.id;

   strategy_result.reason =
      scenario.general_reason;

   return Scenario_IsValid(
      scenario);
}

//====================================================================
// ساخت سناریوی Transition
//====================================================================
bool BuildTransitionScenario(
   const ENUM_SCENARIO_DIRECTION direction,
   const ZoneInfo &zone,
   const double current_price,
   TradingScenario &scenario,
   StrategyResult &strategy_result)
{
   Scenario_Init(scenario);
   Strategy_Reset(strategy_result);

   if(!Zone_IsValid(zone) ||
      current_price <= 0.0)
      return false;

   if(direction ==
      SCENARIO_DIRECTION_SELL)
   {
      if(g_structure.state !=
            STRUCTURE_STATE_BEARISH ||
         !g_structure.bearish_sequence ||
         !g_move.impulse_valid ||
         g_move.impulse_direction >= 0 ||
         zone.direction !=
            ZONE_DIRECTION_SELL)
      {
         strategy_result.failure_reason =
            "شرایط Transition SELL برقرار نیست";
         return false;
      }
   }
   else
   if(direction ==
      SCENARIO_DIRECTION_BUY)
   {
      if(g_structure.state !=
            STRUCTURE_STATE_BULLISH ||
         !g_structure.bullish_sequence ||
         !g_move.impulse_valid ||
         g_move.impulse_direction <= 0 ||
         zone.direction !=
            ZONE_DIRECTION_BUY)
      {
         strategy_result.failure_reason =
            "شرایط Transition BUY برقرار نیست";
         return false;
      }
   }
   else
      return false;

   if(!Scenario_CreateFromEvidence(
      _Symbol,
      direction,
      g_regime,
      g_context,
      g_structure,
      g_move,
      zone,
      scenario))
   {
      strategy_result.failure_reason =
         "ساخت سناریوی Transition ناموفق بود";
      return false;
   }

   scenario.quality_value = 80.0;

   scenario.general_reason =
      (direction ==
         SCENARIO_DIRECTION_SELL
       ?
         "Transition SELL | Truth+HTF+Impulse+Structure هم‌جهت | ریسک کاهش‌یافته 50%"
       :
         "Transition BUY | Truth+HTF+Impulse+Structure هم‌جهت | ریسک کاهش‌یافته 50%");

   strategy_result.valid = true;
   strategy_result.type =
      (direction ==
         SCENARIO_DIRECTION_SELL
       ?
         STRATEGY_SELL_CONTINUATION
       :
         STRATEGY_BUY_CONTINUATION);

   strategy_result.direction = direction;
   strategy_result.quality =
      scenario.quality_value;
   strategy_result.confidence =
      scenario.quality_value;
   strategy_result.zone_id = zone.id;
   strategy_result.reason =
      scenario.general_reason;

   return Scenario_IsValid(
      scenario);
}

//====================================================================
// ساخت EOC SELL
//====================================================================
bool CreateEndOfCorrectionSellScenario(
   const double current_price,
   const double quality,
   const string reason,
   TradingScenario &scenario,
   StrategyResult &strategy_result)
{
   Scenario_Init(scenario);
   Strategy_Reset(strategy_result);

   if(current_price <= 0.0 ||
      !Zone_IsValid(g_sell_zone))
      return false;

   const ulong scenario_id =
      Scenario_NextID();

   const datetime now =
      TimeCurrent();

   datetime expiry = 0;

   if(Inp_Scenario_Max_Age_Minutes > 0)
      expiry =
         datetime(
            (long)now +
            (long)Inp_Scenario_Max_Age_Minutes *
            60);

   const double invalidation =
      g_sell_zone.invalidation_price;

   if(invalidation <= 0.0)
      return false;

   if(!Scenario_Create(
      scenario_id,
      _Symbol,
      SCENARIO_DIRECTION_SELL,
      g_regime.regime,
      g_sell_zone,
      true,
      true,
      true,
      SCENARIO_ACTIVATION_CONFIRMATION,
      invalidation,
      now,
      expiry,
      (int)Inp_TF_Structure_M15,
      (int)Inp_TF_Setup_M5,
      g_structure.reason,
      "Impulse صعودی M5 به‌عنوان Correction ساختار نزولی شناسایی شد",
      "Correction نزولی/پایان اصلاح برای ادامه روند SELL تأیید شد",
      g_sell_zone.reason,
      "End-of-Correction SELL | ساختار نزولی + اصلاح M5 + تأیید شکست + SELL Zone",
      scenario))
      return false;

   const double entry =
      Zone_Midpoint(g_sell_zone);

   if(entry <= 0.0)
      return false;

   if(!Scenario_SetEntryPrice(
      scenario,
      entry,
      now,
      "Entry پیشنهادی در میانه SELL Zone برای End-of-Correction"))
      return false;

   scenario.activation_type =
      SCENARIO_ACTIVATION_CONFIRMATION;

   scenario.quality_value =
      MathMin(
         100.0,
         MathMax(0.0, quality));

   scenario.general_reason = reason;
   scenario.activation_ready = true;

   scenario.activation_reason =
      "Candle + Break Confirmation برای EOC تأیید شد";

   strategy_result.valid = true;
   strategy_result.type =
      STRATEGY_SELL_CONTINUATION;

   strategy_result.direction =
      SCENARIO_DIRECTION_SELL;

   strategy_result.zone_id =
      g_sell_zone.id;

   strategy_result.quality =
      scenario.quality_value;

   strategy_result.confidence =
      scenario.quality_value;

   strategy_result.reason =
      reason;

   return Scenario_IsValid(
      scenario);
}

//====================================================================
// تشخیص EOC SELL
//====================================================================
bool DetectEndOfCorrectionSell(
   const double current_price,
   const bool htf_allows_sell,
   const bool regime_allows_sell,
   const bool streak_allows_sell,
   const bool divergence_blocks_sell,
   const ENUM_DIVERGENCE_TYPE divergence,
   ConfluenceResult &confluence,
   double &quality,
   string &reason)
{
   Confluence_Init(confluence);
   quality = 0.0;
   reason = "";

   if(g_structure.state !=
         STRUCTURE_STATE_BEARISH ||
      !g_structure.bearish_sequence)
   {
      reason =
         "Structure برای End-of-Correction SELL مناسب نیست";
      return false;
   }

   if(!g_move.impulse_valid ||
      g_move.impulse_direction <= 0)
   {
      reason =
         "حرکت اصلاحی صعودی معتبر در M5 شناسایی نشد";
      return false;
   }

   if(!g_move.correction_valid ||
      g_move.correction_direction >= 0)
   {
      reason =
         "پایان Correction برای ادامه SELL تأیید نشده است";
      return false;
   }

   if(Inp_Max_Correction_Ratio > 0.0 &&
      g_move.correction_ratio >
      Inp_Max_Correction_Ratio)
   {
      reason =
         "Correction بیش از حد مجاز است | Ratio=" +
         DoubleToString(
            g_move.correction_ratio, 3) +
         " | Max=" +
         DoubleToString(
            Inp_Max_Correction_Ratio, 3);

      return false;
   }

   if(!Zone_IsValid(g_sell_zone))
   {
      reason =
         "SELL Zone معتبر نیست";
      return false;
   }

   if(!Zone_ContainsPrice(
      g_sell_zone,
      current_price))
   {
      reason =
         "قیمت هنوز داخل SELL Zone نیست";
      return false;
   }

   string candle_reason = "";

   if(!CandleConfirmation_ConfirmsDirection(
      _Symbol,
      Inp_TF_Setup_M5,
      Inp_PinBar_Min_Wick_Ratio,
      false,
      candle_reason))
   {
      reason =
         "کندل تأییدی نزولی وجود ندارد | " +
         candle_reason;
      return false;
   }

   const double close_1 =
      iClose(_Symbol, PERIOD_M5, 1);

   const double open_1 =
      iOpen(_Symbol, PERIOD_M5, 1);

   const double low_2 =
      iLow(_Symbol, PERIOD_M5, 2);

   if(close_1 <= 0.0 ||
      open_1 <= 0.0 ||
      low_2 <= 0.0)
   {
      reason =
         "داده کندل برای Break Confirmation معتبر نیست";
      return false;
   }

   const bool bearish_close =
      (close_1 < open_1);

   const bool bearish_break =
      (close_1 < low_2);

   if(!bearish_close ||
      !bearish_break)
   {
      reason =
         "پایان اصلاح هنوز با Break نزولی تأیید نشده است" +
         " | BearishClose=" +
         (bearish_close ? "YES" : "NO") +
         " | BreakPreviousLow=" +
         (bearish_break ? "YES" : "NO");

      return false;
   }

   Confluence_CalculateContinuation(
      htf_allows_sell,
      regime_allows_sell,
      g_regime.confidence,
      streak_allows_sell,
      true,
      g_move.correction_ratio,
      Inp_Max_Correction_Ratio,
      divergence_blocks_sell,
      Divergence_SupportsDirection(
         divergence,
         false),
      confluence);

   quality = confluence.score;

   if(quality <
      Inp_Min_Confluence_Score)
   {
      reason =
         "Confluence End-of-Correction کافی نیست | Score=" +
         DoubleToString(
            quality, 1) +
         " | Minimum=" +
         DoubleToString(
            Inp_Min_Confluence_Score, 1);

      return false;
   }

   reason =
      "End-of-Correction SELL تأیید شد | CorrectionRatio=" +
      DoubleToString(
         g_move.correction_ratio, 3) +
      " | Confluence=" +
      DoubleToString(
         quality, 1) +
      " | Candle=" +
      candle_reason +
      " | BreakPreviousLow=YES";

   return true;
}

//====================================================================
// ساخت EOC BUY
//====================================================================
bool CreateEndOfCorrectionBuyScenario(
   const double current_price,
   const double quality,
   const string reason,
   TradingScenario &scenario,
   StrategyResult &strategy_result)
{
   Scenario_Init(scenario);
   Strategy_Reset(strategy_result);

   if(current_price <= 0.0 ||
      !Zone_IsValid(g_buy_zone))
      return false;

   const ulong scenario_id =
      Scenario_NextID();

   const datetime now =
      TimeCurrent();

   datetime expiry = 0;

   if(Inp_Scenario_Max_Age_Minutes > 0)
      expiry =
         datetime(
            (long)now +
            (long)Inp_Scenario_Max_Age_Minutes *
            60);

   const double invalidation =
      g_buy_zone.invalidation_price;

   if(invalidation <= 0.0)
      return false;

   if(!Scenario_Create(
      scenario_id,
      _Symbol,
      SCENARIO_DIRECTION_BUY,
      g_regime.regime,
      g_buy_zone,
      true,
      true,
      true,
      SCENARIO_ACTIVATION_CONFIRMATION,
      invalidation,
      now,
      expiry,
      (int)Inp_TF_Structure_M15,
      (int)Inp_TF_Setup_M5,
      g_structure.reason,
      "Impulse نزولی M5 به‌عنوان Correction ساختار صعودی شناسایی شد",
      "Correction صعودی/پایان اصلاح برای ادامه روند BUY تأیید شد",
      g_buy_zone.reason,
      "End-of-Correction BUY | ساختار صعودی + اصلاح M5 + تأیید شکست + BUY Zone",
      scenario))
      return false;

   const double entry =
      Zone_Midpoint(g_buy_zone);

   if(entry <= 0.0)
      return false;

   if(!Scenario_SetEntryPrice(
      scenario,
      entry,
      now,
      "Entry پیشنهادی در میانه BUY Zone برای End-of-Correction"))
      return false;

   scenario.activation_type =
      SCENARIO_ACTIVATION_CONFIRMATION;

   scenario.quality_value =
      MathMin(
         100.0,
         MathMax(0.0, quality));

   scenario.general_reason = reason;
   scenario.activation_ready = true;

   scenario.activation_reason =
      "Candle + Break Confirmation برای EOC تأیید شد";

   strategy_result.valid = true;
   strategy_result.type =
      STRATEGY_BUY_CONTINUATION;

   strategy_result.direction =
      SCENARIO_DIRECTION_BUY;

   strategy_result.zone_id =
      g_buy_zone.id;

   strategy_result.quality =
      scenario.quality_value;

   strategy_result.confidence =
      scenario.quality_value;

   strategy_result.reason =
      reason;

   return Scenario_IsValid(
      scenario);
}

//====================================================================
// تشخیص EOC BUY
//====================================================================
bool DetectEndOfCorrectionBuy(
   const double current_price,
   const bool htf_allows_buy,
   const bool regime_allows_buy,
   const bool streak_allows_buy,
   const bool divergence_blocks_buy,
   const ENUM_DIVERGENCE_TYPE divergence,
   ConfluenceResult &confluence,
   double &quality,
   string &reason)
{
   Confluence_Init(confluence);
   quality = 0.0;
   reason = "";

   if(g_structure.state !=
         STRUCTURE_STATE_BULLISH ||
      !g_structure.bullish_sequence)
   {
      reason =
         "Structure برای End-of-Correction BUY مناسب نیست";
      return false;
   }

   if(!g_move.impulse_valid ||
      g_move.impulse_direction >= 0)
   {
      reason =
         "حرکت اصلاحی نزولی معتبر در M5 شناسایی نشد";
      return false;
   }

   if(!g_move.correction_valid ||
      g_move.correction_direction <= 0)
   {
      reason =
         "پایان Correction برای ادامه BUY تأیید نشده است";
      return false;
   }

   if(Inp_Max_Correction_Ratio > 0.0 &&
      g_move.correction_ratio >
      Inp_Max_Correction_Ratio)
   {
      reason =
         "Correction بیش از حد مجاز است | Ratio=" +
         DoubleToString(
            g_move.correction_ratio, 3) +
         " | Max=" +
         DoubleToString(
            Inp_Max_Correction_Ratio, 3);

      return false;
   }

   if(!Zone_IsValid(g_buy_zone))
   {
      reason =
         "BUY Zone معتبر نیست";
      return false;
   }

   if(!Zone_ContainsPrice(
      g_buy_zone,
      current_price))
   {
      reason =
         "قیمت هنوز داخل BUY Zone نیست";
      return false;
   }

   string candle_reason = "";

   if(!CandleConfirmation_ConfirmsDirection(
      _Symbol,
      Inp_TF_Setup_M5,
      Inp_PinBar_Min_Wick_Ratio,
      true,
      candle_reason))
   {
      reason =
         "کندل تأییدی صعودی وجود ندارد | " +
         candle_reason;
      return false;
   }

   const double close_1 =
      iClose(_Symbol, PERIOD_M5, 1);

   const double open_1 =
      iOpen(_Symbol, PERIOD_M5, 1);

   const double high_2 =
      iHigh(_Symbol, PERIOD_M5, 2);

   if(close_1 <= 0.0 ||
      open_1 <= 0.0 ||
      high_2 <= 0.0)
   {
      reason =
         "داده کندل برای Break Confirmation معتبر نیست";
      return false;
   }

   const bool bullish_close =
      (close_1 > open_1);

   const bool bullish_break =
      (close_1 > high_2);

   if(!bullish_close ||
      !bullish_break)
   {
      reason =
         "پایان اصلاح هنوز با Break صعودی تأیید نشده است" +
         " | BullishClose=" +
         (bullish_close ? "YES" : "NO") +
         " | BreakPreviousHigh=" +
         (bullish_break ? "YES" : "NO");

      return false;
   }

   Confluence_CalculateContinuation(
      htf_allows_buy,
      regime_allows_buy,
      g_regime.confidence,
      streak_allows_buy,
      true,
      g_move.correction_ratio,
      Inp_Max_Correction_Ratio,
      divergence_blocks_buy,
      Divergence_SupportsDirection(
         divergence,
         true),
      confluence);

   quality = confluence.score;

   if(quality <
      Inp_Min_Confluence_Score)
   {
      reason =
         "Confluence End-of-Correction کافی نیست | Score=" +
         DoubleToString(
            quality, 1) +
         " | Minimum=" +
         DoubleToString(
            Inp_Min_Confluence_Score, 1);

      return false;
   }

   reason =
      "End-of-Correction BUY تأیید شد | CorrectionRatio=" +
      DoubleToString(
         g_move.correction_ratio, 3) +
      " | Confluence=" +
      DoubleToString(
         quality, 1) +
      " | Candle=" +
      candle_reason +
      " | BreakPreviousHigh=YES";

   return true;
}

//====================================================================
// ممیزی فیلترها
//====================================================================
void RunFilterAudit(
   const bool context_ok,
   const bool regime_ok,
   const bool structure_ok,
   const bool move_ok,
   const bool market_truth_ok,
   const bool has_buy_zone,
   const bool has_sell_zone,
   const bool correction_ok,
   const bool divergence_blocks_buy,
   const bool divergence_blocks_sell)
{
   FilterAudit_Reset(g_filter_audit);
   FilterAudit_ResetTotals();
   g_filter_audit.time = TimeCurrent();

   FilterAudit_Add(
      g_filter_audit,
      "محیط بازار",
      context_ok ? AUDIT_PASS : AUDIT_BLOCK,
      context_ok
      ? "داده محیط بازار معتبر است"
      : "محیط بازار کامل نیست");

   bool regime_pass = (!g_regime.valid || g_regime.regime == MARKET_REGIME_UPTREND ||
g_regime.regime == MARKET_REGIME_DOWNTREND || g_regime.regime == MARKET_REGIME_TRANSITION);

bool regime_uncertain = (g_regime.valid && g_regime.regime == MARKET_REGIME_UNCERTAIN);

if(regime_uncertain)
{
   FilterAudit_Add(g_filter_audit, "رژیم بازار", AUDIT_INFO,
   "رژیم نامشخص است - ضریب اطمینان سناریو 30% کاهش می‌یابد");
}
else
{
   FilterAudit_Add(g_filter_audit, "رژیم بازار",
   regime_pass ? AUDIT_PASS : AUDIT_BLOCK,
   regime_pass ? "رژیم مانع Opportunity نیست" : "رژیم نامشخص است");
}
   FilterAudit_Add(
      g_filter_audit,
      "ساختار",
      structure_ok
      ? AUDIT_PASS
      : AUDIT_BLOCK,
      structure_ok
      ? MarketStructure_StateToPersian(
           g_structure.state)
      : "ساختار کافی نیست");

   bool movement_pass =
      move_ok ||
      (g_market_truth.valid &&
       g_market_truth.strong_market_move);

   FilterAudit_Add(
      g_filter_audit,
      "حرکت قیمت",
      movement_pass
      ? AUDIT_PASS
      : AUDIT_BLOCK,
      movement_pass
      ? "حرکت قابل استفاده شناسایی شد"
      : "حرکت معنی‌دار کافی نیست");

   bool truth_pass =
      market_truth_ok &&
      g_market_truth.direction !=
         MARKET_TRUTH_NONE;

   FilterAudit_Add(
      g_filter_audit,
      "حقیقت قیمت",
      truth_pass
      ? AUDIT_PASS
      : AUDIT_BLOCK,
      truth_pass
      ? g_market_truth.reason
      : "خوانش مستقل قیمت معتبر نیست");

   bool zone_pass =
      has_buy_zone ||
      has_sell_zone;

   FilterAudit_Add(
      g_filter_audit,
      "Zone",
      zone_pass
      ? AUDIT_PASS
      : AUDIT_BLOCK,
      zone_pass
      ? "حداقل یک ناحیه شناخته شد"
      : "Zone ساختاری فعال در دسترس نیست");

   FilterAudit_Add(
      g_filter_audit,
      "Correction",
      correction_ok
      ? AUDIT_PASS
      : AUDIT_INFO,
      correction_ok
      ? "اصلاح معتبر وجود دارد"
      : "اصلاح کامل نیست");

   bool div_block =
      (g_market_truth.direction ==
         MARKET_TRUTH_BUY
       ? divergence_blocks_buy
       :
       (g_market_truth.direction ==
          MARKET_TRUTH_SELL
        ? divergence_blocks_sell
        : false));

   FilterAudit_Add(
      g_filter_audit,
      "واگرایی",
      div_block
      ? AUDIT_BLOCK
      : AUDIT_PASS,
      div_block
      ? "واگرایی مخالف جهت شناسایی شد"
      : "مانع واگرایی فعال نیست");

   FilterAudit_Add(
      g_filter_audit,
      "تأیید کندل",
      AUDIT_INFO,
      "تأیید کندل فقط برای مرحله اجرای واقعی است و ممیزی را متوقف نمی‌کند");

   FilterAudit_Add(
      g_filter_audit,
      "فاصله Entry",
      AUDIT_PASS,
      "گیت ثابت 300 Point حذف شده است؛ فاصله توسط منطق Entry سنجیده می‌شود");

   FilterAudit_Print(g_filter_audit);
}

//====================================================================
// گیت سبک ورود Continuation در مرحله تشکیل Scenario
// فقط تضاد صریح و قوی جهت بازار را متوقف می‌کند تا فرصت‌های معتبر
// به خاطر شروط تکراری و بیش‌ازحد سخت در همین مرحله حذف نشوند.
//====================================================================
bool EntryGate_IsContinuationStrategy(
   const ENUM_STRATEGY_TYPE strategy_type)
{
   return (strategy_type == STRATEGY_BUY_CONTINUATION ||
           strategy_type == STRATEGY_SELL_CONTINUATION);
}

bool EntryGate_AllowsContinuationAtSignal(
   const ENUM_SCENARIO_DIRECTION direction,
   const ENUM_STRATEGY_TYPE strategy_type,
   string &reason)
{
   reason = "";

   if(!Inp_Enable_Entry_Decision_Gate ||
      !EntryGate_IsContinuationStrategy(strategy_type))
      return true;

   if(direction == SCENARIO_DIRECTION_NONE)
   {
      reason = "جهت Scenario مشخص نیست";
      return false;
   }

   if(Inp_Use_Market_Truth &&
      g_market_truth.valid)
   {
      const bool conflict =
         (direction == SCENARIO_DIRECTION_BUY &&
          g_market_truth.direction == MARKET_TRUTH_SELL) ||
         (direction == SCENARIO_DIRECTION_SELL &&
          g_market_truth.direction == MARKET_TRUTH_BUY);

      if(conflict &&
         g_market_truth.strong_market_move &&
         (g_market_truth.continuation_ready ||
          g_market_truth.move_atr_multiple >= 2.50))
      {
         reason =
            (direction == SCENARIO_DIRECTION_BUY
             ? "BUY با Market Truth قوی مخالف است"
             : "SELL با Market Truth قوی مخالف است") +
            " | Truth=" +
            MarketTruth_DirectionToString(g_market_truth.direction) +
            " | MoveATR=" +
            DoubleToString(g_market_truth.move_atr_multiple,2);
         return false;
      }
   }

   if(MarketStructure_IsValid(g_structure))
   {
      if(direction == SCENARIO_DIRECTION_BUY &&
         g_structure.state == STRUCTURE_STATE_BEARISH)
      {
         reason = "ساختار جاری نزولی است و BUY Continuation را پشتیبانی نمی‌کند";
         return false;
      }

      if(direction == SCENARIO_DIRECTION_SELL &&
         g_structure.state == STRUCTURE_STATE_BULLISH)
      {
         reason = "ساختار جاری صعودی است و SELL Continuation را پشتیبانی نمی‌کند";
         return false;
      }
   }

   return true;
}

//====================================================================
// حداقل نسبت سود به ریسک برای Target سناریو
//====================================================================
bool EnsureTargetMeetsMinimumRR(
   const ENUM_SCENARIO_DIRECTION direction,
   const double entry_price,
   const double stop_price,
   double &target_price,
   const double atr_value)
{
   if(direction == SCENARIO_DIRECTION_NONE ||
      entry_price <= 0.0 ||
      stop_price <= 0.0 ||
      target_price <= 0.0)
      return false;

   const double risk = MathAbs(entry_price - stop_price);
   if(risk <= 0.0)
      return false;

   double min_rr = Inp_Min_RR;
   if(min_rr < 0.0)
      min_rr = 0.0;

   const double minimum_reward = risk * min_rr;
   const double existing_reward =
      (direction == SCENARIO_DIRECTION_BUY
       ? target_price - entry_price
       : entry_price - target_price);

   if(existing_reward > 0.0 &&
      existing_reward >= minimum_reward)
      return true;

   if(direction == SCENARIO_DIRECTION_BUY)
      target_price = entry_price + minimum_reward;
   else
      target_price = entry_price - minimum_reward;

   if(atr_value > 0.0 &&
      target_price <= 0.0)
      return false;

   const double corrected_reward =
      (direction == SCENARIO_DIRECTION_BUY
       ? target_price - entry_price
       : entry_price - target_price);

   return (corrected_reward > 0.0);
}

//====================================================================
// سقف مؤثر معاملات باز در سطح حساب/نماد
//====================================================================
int GetEffectiveMaxOpenTrades()
{
   return MathMax(1,Inp_MaxOpenTrades);
}

//====================================================================
// ثبت Scenario فعلی برای Virtual Tester
//====================================================================
bool RegisterCurrentScenarioForVirtualTester()
{
   if(g_scenario.id <= 0 ||
      !Scenario_IsValid(g_scenario))
      return false;

   double bid=0.0, ask=0.0, mid=0.0;
   if(!GetCurrentPrices(bid,ask,mid))
      return false;

   const bool ok =
      ScenarioVirtualTester_AutoRegister(
         g_scenario,
         bid,
         ask);

   if(ok)
      g_virtual_scenario_id = g_scenario.id;

   return ok;
}

//====================================================================
// به‌روزرسانی Virtual Tester
//====================================================================
void UpdateScenarioVirtualTester()
{
   double bid=0.0, ask=0.0, mid=0.0;
   if(!GetCurrentPrices(bid,ask,mid))
      return;

   ScenarioVirtualTester_Update(
      bid,
      ask,
      TimeCurrent());
}

//====================================================================
// تحلیل بازار و ساخت سناریو
//====================================================================
bool AnalyzeMarket(
   TradingScenario &new_scenario,
   SLPlan &new_sl_plan,
   TP_Result &new_tp_result,
   TargetInfo &new_target)
{
   Scenario_Init(new_scenario);
   Target_Init(new_target);
   TP_Init(new_tp_result);
   ZeroMemory(new_sl_plan);

   g_is_transition_mode = false;
   g_last_strategy_type = STRATEGY_NONE;
   g_last_strategy_confidence = 0.0;

   double bid, ask, current_price;

   if(!GetCurrentPrices(
      bid,
      ask,
      current_price))
   {
      SetScenarioDiagnostic(
         "PRICE_FAIL | دریافت Bid/Ask ناموفق بود");
      return false;
   }

   if(!RefreshHigherTimeframeContext())
   {
      SetScenarioDiagnostic(
         "HTF_FAIL | به‌روزرسانی زمینه H4/H1 ناموفق بود");
      return false;
   }

   bool context_ok =
      MarketContext_Analyze(
         _Symbol,
         Inp_TF_Context_M30,
         Inp_ATR_Period,
         20,
         g_context);

   bool regime_ok =
      MarketRegime_Analyze(
         _Symbol,
         Inp_TF_Context_M30,
         Inp_ADX_Period,
         Inp_RSI_Period,
         Inp_EMA_Trend_Period,
         Inp_ATR_Period,
         Inp_ADX_Min_Trend,
         Inp_ADX_Exhaustion_Level,
         Inp_RSI_Overbought,
         Inp_RSI_Oversold,
         Inp_Max_Price_EMA_ATR_Distance,
         g_regime);

   bool structure_ok =
      MarketStructure_Analyze(
         _Symbol,
         Inp_TF_Structure_M15,
         120,
         2,
         2,
         20.0,
         g_structure);

   bool move_ok =
      ImpulseCorrection_Analyze(
         _Symbol,
         Inp_TF_Setup_M5,
         120,
         2,
         2,
         20.0,
         g_move);

   bool market_truth_ok =
      Inp_Use_Market_Truth &&
      MarketTruth_Analyze(
         _Symbol,
         Inp_TF_Setup_M5,
         Inp_Market_Truth_Lookback,
         g_market_truth);

   Print(
      "[MARKET_TRUTH] ",
      market_truth_ok ? "VALID" : "FAIL",
      " | ",
      g_market_truth.reason,
      " | Direction=",
      MarketTruth_DirectionToString(
         g_market_truth.direction),
      " | Phase=",
      MarketTruth_PhaseToString(
         g_market_truth.phase),
      " | Continuation=",
      g_market_truth.continuation_ready
      ? "YES"
      : "NO");

   bool market_reading_ok =
      MarketReading_Analyze(
         _Symbol,
         Inp_TF_Setup_M5,
         g_market_truth,
         g_structure,
         g_market_reading);

   if(market_reading_ok)
   {
      Print(
         "[خوانش بازار] گذشته | ",
         g_market_reading.past_state);

      Print(
         "[خوانش بازار] حال | ",
         g_market_reading.now_state);

      Print(
         "[خوانش بازار] آینده مشروط | ",
         g_market_reading.future_state);
   }

   if(!context_ok ||
      !regime_ok ||
      !structure_ok ||
      !move_ok)
   {
      SetScenarioDiagnostic(
         "ANALYSIS_FAIL | Context=" +
         (context_ok ? "PASS" : "FAIL") +
         " | Regime=" +
         (regime_ok ? "PASS" : "FAIL") +
         " | Structure=" +
         (structure_ok ? "PASS" : "FAIL") +
         " | Move=" +
         (move_ok ? "PASS" : "FAIL"));

      return false;
   }

   double atr_price =
      g_context.atr_points *
      _Point;

   if(atr_price <= 0.0)
   {
      atr_price =
         MathMax(
            _Point * 20.0,
            g_structure.structure_range_points *
            _Point *
            0.10);
   }

   if(atr_price <= 0.0)
   {
      SetScenarioDiagnostic(
         "ATR_FAIL | مقدار ATR معتبر نیست");
      return false;
   }

   ZoneInfo buy_zone;
   ZoneInfo sell_zone;

   Zone_Init(buy_zone);
   Zone_Init(sell_zone);

   bool has_buy =
      BuildBuyZone(
         g_structure,
         atr_price,
         buy_zone);

   bool has_sell =
      BuildSellZone(
         g_structure,
         atr_price,
         sell_zone);

   if(has_buy)
      g_buy_zone = buy_zone;

   if(has_sell)
      g_sell_zone = sell_zone;

   if(Inp_Use_Market_Truth &&
      market_truth_ok)
   {
      int truth_dir =
         (g_market_truth.direction ==
            MARKET_TRUTH_BUY
          ? 1
          :
          (g_market_truth.direction ==
             MARKET_TRUTH_SELL
           ? -1
           : 0));

      int structure_dir =
         (g_structure.state ==
            STRUCTURE_STATE_BULLISH
          ? 1
          :
          (g_structure.state ==
             STRUCTURE_STATE_BEARISH
           ? -1
           : 0));

      if(truth_dir != 0 &&
         structure_dir == truth_dir)
      {
         Print(
            "[MARKET_TRUTH_OVERLAP] Price/Structure هم‌جهت");
      }
      else
      if(truth_dir != 0 &&
         structure_dir != 0 &&
         truth_dir != structure_dir)
      {
         Print(
            "[MARKET_TRUTH_DIVERGENCE] Price با Structure ربات اختلاف دارد | Truth=",
            MarketTruth_DirectionToString(
               g_market_truth.direction),
            " | Structure=",
            (structure_dir > 0
             ? "BUY"
             : "SELL"));
      }

      if(g_market_truth.continuation_ready &&
         ((truth_dir < 0 && !has_sell) ||
          (truth_dir > 0 && !has_buy)))
      {
         Print(
            "[FIRST_MISS] Opportunity بالقوه وجود دارد ولی Zone هم‌جهت نیست");
      }
   }

   if(!has_buy && !has_sell)
      SetScenarioDiagnostic(
         "ZONE_INFO | Zone ساختاری فعال نیست");

   ENUM_HTF_DIRECTION htf =
      GetHigherTimeframeDirection();

   bool htf_allows_buy =
      Inp_Allow_Contrary_Background ||
      (htf != HTF_DIRECTION_BEARISH);

   bool htf_allows_sell =
      Inp_Allow_Contrary_Background ||
      (htf != HTF_DIRECTION_BULLISH);

   bool regime_allows_buy =
      MarketRegime_SupportsDirection(
         g_regime,
         true,
         Inp_Min_Regime_Confidence);

   bool regime_allows_sell =
      MarketRegime_SupportsDirection(
         g_regime,
         false,
         Inp_Min_Regime_Confidence);

   if(!g_regime.valid)
   {
      regime_allows_buy = true;
      regime_allows_sell = true;
   }

   bool streak_allows_buy =
      (g_structure.bullish_swing_streak <=
       Inp_Max_Consecutive_Swings);

   bool streak_allows_sell =
      (g_structure.bearish_swing_streak <=
       Inp_Max_Consecutive_Swings);

   ENUM_DIVERGENCE_TYPE divergence =
      DIVERGENCE_NONE;

   string divergence_reason = "";

   if(Inp_Enable_Divergence_Filter)
   {
      divergence =
         Divergence_Detect(
            _Symbol,
            Inp_TF_Structure_M15,
            Inp_RSI_Period,
            g_structure,
            divergence_reason);
   }

   bool divergence_blocks_buy =
      Inp_Reject_On_Against_Divergence &&
      Divergence_IsAgainstDirection(
         divergence,
         true);

   bool divergence_blocks_sell =
      Inp_Reject_On_Against_Divergence &&
      Divergence_IsAgainstDirection(
         divergence,
         false);

   RunFilterAudit(
      context_ok,
      regime_ok,
      structure_ok,
      move_ok,
      market_truth_ok,
      has_buy,
      has_sell,
      g_move.correction_valid,
      divergence_blocks_buy,
      divergence_blocks_sell);

   bool truth_buy_setup =
      market_truth_ok &&
      MarketTruth_SupportsDirection(
         g_market_truth,
         true);

   bool truth_sell_setup =
      market_truth_ok &&
      MarketTruth_SupportsDirection(
         g_market_truth,
         false);

   bool base_buy_setup =
      has_buy &&
      g_structure.state ==
         STRUCTURE_STATE_BULLISH &&
      ((g_move.impulse_valid &&
        g_move.impulse_direction > 0) ||
       truth_buy_setup);

   bool base_sell_setup =
      has_sell &&
      g_structure.state ==
         STRUCTURE_STATE_BEARISH &&
      ((g_move.impulse_valid &&
        g_move.impulse_direction < 0) ||
       truth_sell_setup);

   if(!base_buy_setup &&
      !base_sell_setup)
   {
      base_buy_setup =
         has_buy &&
         (htf ==
            HTF_DIRECTION_BULLISH) &&
         g_move.impulse_valid &&
         g_move.impulse_direction > 0;

      base_sell_setup =
         has_sell &&
         (htf ==
            HTF_DIRECTION_BEARISH) &&
         g_move.impulse_valid &&
         g_move.impulse_direction < 0;
   }

   ConfluenceResult buy_confluence;
   ConfluenceResult sell_confluence;

   Confluence_Init(buy_confluence);
   Confluence_Init(sell_confluence);

   bool buy_candidate = false;
   bool sell_candidate = false;

   //===============================================================
   // OPPORTUNITY FIRST — قبل از امتیازدهی سناریو
   // فرصت بزرگ نباید فقط به‌دلیل نبود Zone قدیمی از دست برود.
   //===============================================================
   OpportunityCapture_Reset(g_opportunity_capture);
   if(market_truth_ok && market_reading_ok)
   {
      if(OpportunityCapture_Evaluate(
         g_market_truth,
         g_market_reading,
         g_structure,
         g_move,
         buy_zone,
         sell_zone,
         current_price,
         g_opportunity_capture))
      {
         ZoneInfo opportunity_zone;
         Zone_Init(opportunity_zone);

         if(g_opportunity_capture.synthetic_zone_created)
         {
            OpportunityCapture_CreateSyntheticZone(
               g_opportunity_capture,
               g_move,
               atr_price,
               opportunity_zone);
         }
         else
         {
            opportunity_zone =
               (g_opportunity_capture.direction == SCENARIO_DIRECTION_BUY
                ? buy_zone
                : sell_zone);
         }

         if(g_opportunity_capture.direction == SCENARIO_DIRECTION_BUY &&
            Zone_IsValid(opportunity_zone))
         {
            buy_zone = opportunity_zone;
            g_buy_zone = opportunity_zone;
            has_buy = true;
            buy_candidate = true;
            Print(
               "[OPPORTUNITY FIRST] BUY Candidate=YES | Zone=",
               g_opportunity_capture.synthetic_zone_created
               ? "SYNTHETIC_REACTION"
               : "NATIVE");
         }
         else
         if(g_opportunity_capture.direction == SCENARIO_DIRECTION_SELL &&
            Zone_IsValid(opportunity_zone))
         {
            sell_zone = opportunity_zone;
            g_sell_zone = opportunity_zone;
            has_sell = true;
            sell_candidate = true;
            Print(
               "[OPPORTUNITY FIRST] SELL Candidate=YES | Zone=",
               g_opportunity_capture.synthetic_zone_created
               ? "SYNTHETIC_REACTION"
               : "NATIVE");
         }
      }
   }

   const bool opportunity_buy_override =
      g_opportunity_capture.valid &&
      g_opportunity_capture.priority &&
      g_opportunity_capture.direction == SCENARIO_DIRECTION_BUY &&
      Inp_Market_Truth_Override_Confluence;
   const bool opportunity_sell_override =
      g_opportunity_capture.valid &&
      g_opportunity_capture.priority &&
      g_opportunity_capture.direction == SCENARIO_DIRECTION_SELL &&
      Inp_Market_Truth_Override_Confluence;

   if(opportunity_buy_override || opportunity_sell_override)
   {
      Print(
         "[OPPORTUNITY OVERRIDE] فرصت اولویت‌دار اجازه رد شدن از Confluence را گرفت | Direction=",
         opportunity_buy_override ? "BUY" : "SELL",
         " | کیفیت=",DoubleToString(g_opportunity_capture.quality,1),
         " | TruthMoveATR=",DoubleToString(g_opportunity_capture.truth_move_atr,2),
         " | RoomATR=",DoubleToString(g_opportunity_capture.estimated_room_atr,2));
      SetScenarioDiagnostic(
         "OPPORTUNITY_OVERRIDE | Direction=" +
         (opportunity_buy_override ? "BUY" : "SELL") +
         " | Quality=" + DoubleToString(g_opportunity_capture.quality,1) +
         " | RoomATR=" + DoubleToString(g_opportunity_capture.estimated_room_atr,2));
   }

   if(Inp_Use_Confluence_Scoring)
   {
      if(base_buy_setup &&
         !divergence_blocks_buy)
      {
         Confluence_Calculate(
            htf_allows_buy,
            regime_allows_buy,
            g_regime.confidence,
            streak_allows_buy,
            divergence_blocks_buy,
            Divergence_SupportsDirection(
               divergence,
               true),
            buy_confluence);

         buy_candidate =
            opportunity_buy_override
            ? true
            : (buy_confluence.score >=
               Inp_Min_Confluence_Score);
      }

      if(base_sell_setup &&
         !divergence_blocks_sell)
      {
         Confluence_Calculate(
            htf_allows_sell,
            regime_allows_sell,
            g_regime.confidence,
            streak_allows_sell,
            divergence_blocks_sell,
            Divergence_SupportsDirection(
               divergence,
               false),
            sell_confluence);

         sell_candidate =
            opportunity_sell_override
            ? true
            : (sell_confluence.score >=
               Inp_Min_Confluence_Score);
      }
   }
   else
   {
      buy_candidate =
         opportunity_buy_override
         ? true
         : (base_buy_setup &&
            htf_allows_buy &&
            regime_allows_buy &&
            streak_allows_buy &&
            !divergence_blocks_buy);

      sell_candidate =
         opportunity_sell_override
         ? true
         : (base_sell_setup &&
            htf_allows_sell &&
            regime_allows_sell &&
            streak_allows_sell &&
            !divergence_blocks_sell);
   }

   bool impulse_is_correction = false;

   if(g_move.impulse_valid)
   {
      if(g_structure.state ==
            STRUCTURE_STATE_BULLISH &&
         g_move.impulse_direction < 0)
      {
         impulse_is_correction =
            g_move.correction_valid;
      }
      else
      if(g_structure.state ==
            STRUCTURE_STATE_BEARISH &&
         g_move.impulse_direction > 0)
      {
         impulse_is_correction =
            g_move.correction_valid;
      }
   }

   if(g_move.impulse_valid &&
      !impulse_is_correction)
   {
      if(g_structure.state ==
            STRUCTURE_STATE_BULLISH &&
         g_move.impulse_direction > 0)
      {
         if(!(g_opportunity_capture.valid &&
              g_opportunity_capture.priority &&
              g_opportunity_capture.direction == SCENARIO_DIRECTION_SELL))
            sell_candidate = false;
      }
      else
      if(g_structure.state ==
            STRUCTURE_STATE_BEARISH &&
         g_move.impulse_direction < 0)
      {
         if(!(g_opportunity_capture.valid &&
              g_opportunity_capture.priority &&
              g_opportunity_capture.direction == SCENARIO_DIRECTION_BUY))
            buy_candidate = false;
      }
   }

   double buy_direction_score = 0.0;
   double sell_direction_score = 0.0;

   CalculateDirectionalScores(
      htf,
      has_buy,
      has_sell,
      htf_allows_buy,
      htf_allows_sell,
      regime_allows_buy,
      regime_allows_sell,
      streak_allows_buy,
      streak_allows_sell,
      divergence_blocks_buy,
      divergence_blocks_sell,
      buy_direction_score,
      sell_direction_score);

   if(Inp_Use_Confluence_Scoring)
   {
      buy_direction_score +=
         MathMin(
            10.0,
            buy_confluence.score *
            0.10);

      sell_direction_score +=
         MathMin(
            10.0,
            sell_confluence.score *
            0.10);
   }

   const bool strong_sell_candidate =
      has_sell &&
      g_structure.state ==
         STRUCTURE_STATE_BEARISH &&
      g_structure.bearish_sequence &&
      g_regime.valid &&
      g_regime.regime ==
         MARKET_REGIME_DOWNTREND &&
      g_move.impulse_valid &&
      g_move.impulse_direction < 0 &&
      Zone_IsValid(sell_zone) &&
      sell_direction_score >= 60.0 &&
      !divergence_blocks_sell;

   const bool strong_buy_candidate =
      has_buy &&
      g_structure.state ==
         STRUCTURE_STATE_BULLISH &&
      g_structure.bullish_sequence &&
      g_regime.valid &&
      g_regime.regime ==
         MARKET_REGIME_UPTREND &&
      g_move.impulse_valid &&
      g_move.impulse_direction > 0 &&
      Zone_IsValid(buy_zone) &&
      buy_direction_score >= 60.0 &&
      !divergence_blocks_buy;

   if(strong_sell_candidate)
      sell_candidate = true;

   if(strong_buy_candidate)
      buy_candidate = true;

   if(truth_sell_setup &&
      has_sell &&
      g_structure.state ==
         STRUCTURE_STATE_BEARISH &&
      !divergence_blocks_sell)
   {
      sell_candidate = true;
   }

   if(truth_buy_setup &&
      has_buy &&
      g_structure.state ==
         STRUCTURE_STATE_BULLISH &&
      !divergence_blocks_buy)
   {
      buy_candidate = true;
   }

   if(!StrongDirectionalLockAllows(
      SCENARIO_DIRECTION_BUY,
      htf))
      buy_candidate = false;

   if(!StrongDirectionalLockAllows(
      SCENARIO_DIRECTION_SELL,
      htf))
      sell_candidate = false;

   //===============================================================
   // Transition + Pullback Continuation
   //===============================================================
   bool transition_sell = false;
   bool transition_buy  = false;

   /*
      Pullback Continuation:
      اگر ساختار و HTF نزولی باشند و قیمت در حال اصلاح صعودی باشد،
      حرکت UP الزاماً BUY Setup نیست.

      در این حالت:
      Structure = BEARISH
      HTF       = BEARISH
      CorrectionValid = YES
      ImpulseDir = UP

      می‌تواند یک Pullback برای SELL Continuation باشد.
   */
   bool pullback_sell_candidate = false;
   bool pullback_buy_candidate  = false;

   if(Inp_Use_Market_Truth &&
      market_truth_ok &&
      g_move.impulse_valid)
   {
      const double MIN_TRANSITION_ATR = 2.0;
      const double MIN_PULLBACK_ATR   = 2.0;

      //============================================================
      // SELL TRANSITION
      // حالت قدیمی: فقط وقتی خود Truth هم SELL باشد.
      //============================================================
      if(truth_sell_setup &&
         htf == HTF_DIRECTION_BEARISH &&
         g_move.impulse_direction < 0 &&
         g_move.impulse_atr_multiple >=
            MIN_TRANSITION_ATR)
      {
         bool regime_against =
            (g_regime.valid &&
             g_regime.regime ==
                MARKET_REGIME_UPTREND);

         bool structure_against =
            (g_structure.state ==
             STRUCTURE_STATE_BULLISH);

         if(regime_against != structure_against)
         {
            transition_sell = true;

            Print(
               "[TRANSITION MODE] SELL | Truth=SELL | HTF=BEARISH | Impulse=DOWN (ATRx=",
               DoubleToString(
                  g_move.impulse_atr_multiple,
                  2),
               ") | OpposingLayer=",
               regime_against
               ? "Regime"
               : "Structure",
               " | کاهش ریسک به 50%");
         }
      }

      //============================================================
      // BUY TRANSITION
      //============================================================
      if(truth_buy_setup &&
         htf == HTF_DIRECTION_BULLISH &&
         g_move.impulse_direction > 0 &&
         g_move.impulse_atr_multiple >=
            MIN_TRANSITION_ATR)
      {
         bool regime_against =
            (g_regime.valid &&
             g_regime.regime ==
                MARKET_REGIME_DOWNTREND);

         bool structure_against =
            (g_structure.state ==
             STRUCTURE_STATE_BEARISH);

         if(regime_against != structure_against)
         {
            transition_buy = true;

            Print(
               "[TRANSITION MODE] BUY | Truth=BUY | HTF=BULLISH | Impulse=UP (ATRx=",
               DoubleToString(
                  g_move.impulse_atr_multiple,
                  2),
               ") | OpposingLayer=",
               regime_against
               ? "Regime"
               : "Structure",
               " | کاهش ریسک به 50%");
         }
      }

      //============================================================
      // NEW: SELL PULLBACK CONTINUATION
      //============================================================
      if(htf == HTF_DIRECTION_BEARISH &&
         g_move.impulse_direction > 0 &&
         g_move.impulse_atr_multiple >=
            MIN_PULLBACK_ATR &&
         g_move.correction_valid &&
         g_structure.bearish_sequence &&
         g_structure.state ==
            STRUCTURE_STATE_BEARISH)
      {
         pullback_sell_candidate = true;

         Print(
            "[PULLBACK CONTINUATION] SELL | "
            "HTF=BEARISH"
            " | Structure=BEARISH"
            " | Impulse=UP"
            " | Correction=YES"
            " | ATRx=",
            DoubleToString(
               g_move.impulse_atr_multiple,
               2),
            " | TruthDir=",
            MarketTruth_DirectionToString(
               g_market_truth.direction),
            " | TruthPhase=",
            MarketTruth_PhaseToString(
               g_market_truth.phase),
            " | SELL Continuation Candidate=YES");
      }

      //============================================================
      // NEW: BUY PULLBACK CONTINUATION
      //============================================================
      if(htf == HTF_DIRECTION_BULLISH &&
         g_move.impulse_direction < 0 &&
         g_move.impulse_atr_multiple >=
            MIN_PULLBACK_ATR &&
         g_move.correction_valid &&
         g_structure.bullish_sequence &&
         g_structure.state ==
            STRUCTURE_STATE_BULLISH)
      {
         pullback_buy_candidate = true;

         Print(
            "[PULLBACK CONTINUATION] BUY | "
            "HTF=BULLISH"
            " | Structure=BULLISH"
            " | Impulse=DOWN"
            " | Correction=YES"
            " | ATRx=",
            DoubleToString(
               g_move.impulse_atr_multiple,
               2),
            " | TruthDir=",
            MarketTruth_DirectionToString(
               g_market_truth.direction),
            " | TruthPhase=",
            MarketTruth_PhaseToString(
               g_market_truth.phase),
            " | BUY Continuation Candidate=YES");
      }
   }

   //===============================================================
   // APPLY TRANSITION CANDIDATES
   //===============================================================
   if(transition_sell &&
      !sell_candidate)
   {
      sell_candidate = true;
      g_is_transition_mode = true;
   }

   if(transition_buy &&
      !buy_candidate)
   {
      buy_candidate = true;
      g_is_transition_mode = true;
   }

   //===============================================================
   // APPLY PULLBACK CONTINUATION CANDIDATES
   //
   // مهم:
   // این بخش Transition نیست؛ بنابراین g_is_transition_mode
   // به صورت مصنوعی فعال نمی‌شود و کاهش ریسک 50٪ اعمال نمی‌گردد.
   //===============================================================
   if(pullback_sell_candidate &&
      !sell_candidate)
   {
      sell_candidate = true;

      Print(
         "[SCENARIO CANDIDATE] SELL=PASS | "
         "Reason=Bearish Structure + Bearish HTF + Valid Bullish Pullback");
   }

   if(pullback_buy_candidate &&
      !buy_candidate)
   {
      buy_candidate = true;

      Print(
         "[SCENARIO CANDIDATE] BUY=PASS | "
         "Reason=Bullish Structure + Bullish HTF + Valid Bearish Pullback");
   }

   //===============================================================
   // END OF CORRECTION
   //
   // EOC فقط زمانی بررسی شود که هیچ Candidate پایه‌ای وجود ندارد.
   //===============================================================
   bool end_of_correction_sell_candidate = false;
   double end_of_correction_sell_quality = 0.0;
   string end_of_correction_sell_reason = "";

   ConfluenceResult end_of_correction_sell_confluence;
   Confluence_Init(
      end_of_correction_sell_confluence);

   bool end_of_correction_buy_candidate = false;
   double end_of_correction_buy_quality = 0.0;
   string end_of_correction_buy_reason = "";

   ConfluenceResult end_of_correction_buy_confluence;
   Confluence_Init(
      end_of_correction_buy_confluence);

   if(!buy_candidate &&
      !sell_candidate &&
      impulse_is_correction)
   {
      end_of_correction_sell_candidate =
         DetectEndOfCorrectionSell(
            current_price,
            htf_allows_sell,
            regime_allows_sell,
            streak_allows_sell,
            divergence_blocks_sell,
            divergence,
            end_of_correction_sell_confluence,
            end_of_correction_sell_quality,
            end_of_correction_sell_reason);

      Print(
         "[EOC SELL DIAGNOSTIC] | Candidate=",
         end_of_correction_sell_candidate
         ? "YES"
         : "NO",
         " | Score=",
         DoubleToString(
            end_of_correction_sell_quality,
            1),
         " | Reason=",
         end_of_correction_sell_reason);

      if(end_of_correction_sell_candidate)
         sell_candidate = true;

      if(!end_of_correction_sell_candidate)
      {
         end_of_correction_buy_candidate =
            DetectEndOfCorrectionBuy(
               current_price,
               htf_allows_buy,
               regime_allows_buy,
               streak_allows_buy,
               divergence_blocks_buy,
               divergence,
               end_of_correction_buy_confluence,
               end_of_correction_buy_quality,
               end_of_correction_buy_reason);

         Print(
            "[EOC BUY DIAGNOSTIC] | Candidate=",
            end_of_correction_buy_candidate
            ? "YES"
            : "NO",
            " | Score=",
            DoubleToString(
               end_of_correction_buy_quality,
               1),
            " | Reason=",
            end_of_correction_buy_reason);

         if(end_of_correction_buy_candidate)
            buy_candidate = true;
      }
   }

   //===============================================================
   // EXTRA CANDIDATE DIAGNOSTIC
   //===============================================================
   Print(
      "[SCENARIO CANDIDATE DIAGNOSTIC]"
      " | BaseBUY=",
      base_buy_setup
      ? "PASS"
      : "FAIL",
      " | BaseSELL=",
      base_sell_setup
      ? "PASS"
      : "FAIL",
      " | PullbackBUY=",
      pullback_buy_candidate
      ? "PASS"
      : "NO",
      " | PullbackSELL=",
      pullback_sell_candidate
      ? "PASS"
      : "NO",
      " | TransitionBUY=",
      transition_buy
      ? "YES"
      : "NO",
      " | TransitionSELL=",
      transition_sell
      ? "YES"
      : "NO",
      " | FinalBUY=",
      buy_candidate
      ? "PASS"
      : "FAIL",
      " | FinalSELL=",
      sell_candidate
      ? "PASS"
      : "FAIL");

   //===============================================================
   // DIRECTION SCORE DIAGNOSTIC
   //===============================================================
   SetScenarioDiagnostic(
      "DIRECTION_SCORE | BUY=" +
      DoubleToString(
         buy_direction_score, 1) +
      " | SELL=" +
      DoubleToString(
         sell_direction_score, 1) +
      " | StrongBUY=" +
      (strong_buy_candidate
       ? "YES"
       : "NO") +
      " | StrongSELL=" +
      (strong_sell_candidate
       ? "YES"
       : "NO") +
      " | Structure=" +
      MarketStructure_StateToCode(
         g_structure.state) +
      " | Regime=" +
      MarketRegime_ToCode(
         g_regime.regime) +
      " | HTF=" +
      EnumToString(htf));

   //===============================================================
   // FINAL CANDIDATE FAIL
   //===============================================================
   if(!buy_candidate &&
      !sell_candidate &&
      !end_of_correction_sell_candidate &&
      !end_of_correction_buy_candidate)
   {
      SetScenarioDiagnostic(
         "CANDIDATE_FAIL | Structure=" +
         MarketStructure_StateToCode(
            g_structure.state) +
         " | BullSeq=" +
         (g_structure.bullish_sequence
          ? "YES"
          : "NO") +
         " | BearSeq=" +
         (g_structure.bearish_sequence
          ? "YES"
          : "NO") +
         " | BaseBUY=" +
         (base_buy_setup
          ? "PASS"
          : "FAIL") +
         " | BaseSELL=" +
         (base_sell_setup
          ? "PASS"
          : "FAIL") +
         " | PullbackBUY=" +
         (pullback_buy_candidate
          ? "PASS"
          : "NO") +
         " | PullbackSELL=" +
         (pullback_sell_candidate
          ? "PASS"
          : "NO") +
         " | BUY=" +
         (buy_candidate
          ? "PASS"
          : "FAIL") +
         " | SELL=" +
         (sell_candidate
          ? "PASS"
          : "FAIL") +
         " | BuyConf=" +
         DoubleToString(
            buy_confluence.score, 1) +
         " | SellConf=" +
         DoubleToString(
            sell_confluence.score, 1) +
         " | Regime=" +
         MarketRegime_ToCode(
            g_regime.regime) +
         " | HTF=" +
         EnumToString(htf) +
         " | ImpulseDir=" +
         (g_move.impulse_direction > 0
          ? "UP"
          :
          (g_move.impulse_direction < 0
           ? "DOWN"
           : "NONE")) +
         " | CorrectionValid=" +
         (g_move.correction_valid
          ? "YES"
          : "NO") +
         " | TruthDir=" +
         MarketTruth_DirectionToString(
            g_market_truth.direction) +
         " | TruthPhase=" +
         MarketTruth_PhaseToString(
            g_market_truth.phase) +
         " | TruthMoveATR=" +
         DoubleToString(
            g_market_truth.move_atr_multiple,
            2));

      AIJournal_LogDecision(
         0,
         "NONE",
         current_price,
         g_regime.regime,
         g_regime.confidence,
         false,
         g_structure.state,
         MathMax(
            g_structure.bullish_swing_streak,
            g_structure.bearish_swing_streak),
         false,
         divergence,
         MathMax(
            buy_confluence.score,
            sell_confluence.score),
         0.0,
         AI_JOURNAL_REJECTED_CANDIDATE,
         "نامزد اولیه (Candidate) شکل نگرفت - نه ساختار نه Pullback/EOC تأیید نشد");

      return false;
   }

   SetScenarioDiagnostic(
      "DIRECTION_SCORE | BUY=" +
      DoubleToString(
         buy_direction_score, 1) +
      " | SELL=" +
      DoubleToString(
         sell_direction_score, 1) +
      " | StrongBUY=" +
      (strong_buy_candidate
       ? "YES"
       : "NO") +
      " | StrongSELL=" +
      (strong_sell_candidate
       ? "YES"
       : "NO") +
      " | Structure=" +
      MarketStructure_StateToCode(
         g_structure.state) +
      " | Regime=" +
      MarketRegime_ToCode(
         g_regime.regime) +
      " | HTF=" +
      EnumToString(htf));

   if(!buy_candidate &&
      !sell_candidate &&
      !end_of_correction_sell_candidate &&
      !end_of_correction_buy_candidate)
   {
      SetScenarioDiagnostic(
         "CANDIDATE_FAIL | Structure=" +
         MarketStructure_StateToCode(
            g_structure.state) +
         " | BullSeq=" +
         (g_structure.bullish_sequence
          ? "YES"
          : "NO") +
         " | BearSeq=" +
         (g_structure.bearish_sequence
          ? "YES"
          : "NO") +
         " | BaseBUY=" +
         (base_buy_setup
          ? "PASS"
          : "FAIL") +
         " | BaseSELL=" +
         (base_sell_setup
          ? "PASS"
          : "FAIL") +
         " | BUY=" +
         (buy_candidate
          ? "PASS"
          : "FAIL") +
         " | SELL=" +
         (sell_candidate
          ? "PASS"
          : "FAIL") +
         " | BuyConf=" +
         DoubleToString(
            buy_confluence.score, 1) +
         " | SellConf=" +
         DoubleToString(
            sell_confluence.score, 1) +
         " | Regime=" +
         MarketRegime_ToCode(
            g_regime.regime) +
         " | HTF=" +
         EnumToString(htf) +
         " | ImpulseDir=" +
         (g_move.impulse_direction > 0
          ? "UP"
          :
          (g_move.impulse_direction < 0
           ? "DOWN"
           : "NONE")) +
         " | CorrectionValid=" +
         (g_move.correction_valid
          ? "YES"
          : "NO") +
         " | TruthDir=" +
         MarketTruth_DirectionToString(
            g_market_truth.direction) +
         " | TruthPhase=" +
         MarketTruth_PhaseToString(
            g_market_truth.phase) +
         " | TruthMoveATR=" +
         DoubleToString(
            g_market_truth.move_atr_multiple,
            2));

      AIJournal_LogDecision(
         0,
         "NONE",
         current_price,
         g_regime.regime,
         g_regime.confidence,
         false,
         g_structure.state,
         MathMax(
            g_structure.bullish_swing_streak,
            g_structure.bearish_swing_streak),
         false,
         divergence,
         MathMax(
            buy_confluence.score,
            sell_confluence.score),
         0.0,
         AI_JOURNAL_REJECTED_CANDIDATE,
         "نامزد اولیه (Candidate) شکل نگرفت - نه ساختار نه EOC تأیید نشد");

      return false;
   }

   if(Inp_Enable_News_Filter)
   {
      string news_reason = "";

      if(NewsFilter_IsHighImpactNear(
         _Symbol,
         Inp_News_Minutes_Before,
         Inp_News_Minutes_After,
         news_reason))
      {
         SetScenarioDiagnostic(
            "NEWS_BLOCK | " +
            news_reason);

         return false;
      }
   }

   ENUM_SCENARIO_DIRECTION direction =
      SCENARIO_DIRECTION_NONE;

   // فرصت اولویت‌دار Market Truth در تعیین جهت نهایی بر شاخه‌های عمومی اولویت دارد.
   if(g_opportunity_capture.valid &&
      g_opportunity_capture.priority &&
      (g_opportunity_capture.direction == SCENARIO_DIRECTION_BUY ||
       g_opportunity_capture.direction == SCENARIO_DIRECTION_SELL))
   {
      direction = g_opportunity_capture.direction;
   }
   else
   if(end_of_correction_sell_candidate)
      direction =
         SCENARIO_DIRECTION_SELL;
   else
   if(end_of_correction_buy_candidate)
      direction =
         SCENARIO_DIRECTION_BUY;
   else
   if(buy_candidate &&
      g_structure.state ==
         STRUCTURE_STATE_BULLISH &&
      impulse_is_correction)
      direction =
         SCENARIO_DIRECTION_BUY;
   else
   if(sell_candidate &&
      g_structure.state ==
         STRUCTURE_STATE_BEARISH &&
      impulse_is_correction)
      direction =
         SCENARIO_DIRECTION_SELL;
   else
   if(g_move.impulse_valid &&
      g_move.impulse_direction > 0 &&
      buy_candidate)
      direction =
         SCENARIO_DIRECTION_BUY;
   else
   if(g_move.impulse_valid &&
      g_move.impulse_direction < 0 &&
      sell_candidate)
      direction =
         SCENARIO_DIRECTION_SELL;
   else
   if(buy_candidate &&
      sell_candidate)
   {
      double buy_score = 50.0;
      double sell_score = 50.0;

      if(g_structure.bullish_sequence)
         buy_score += 20.0;

      if(g_structure.bearish_sequence)
         sell_score += 20.0;

      if(htf ==
         HTF_DIRECTION_BULLISH)
         buy_score += 10.0;

      if(htf ==
         HTF_DIRECTION_BEARISH)
         sell_score += 10.0;

      if(Inp_Use_Confluence_Scoring)
      {
         buy_score +=
            buy_confluence.score * 0.3;

         sell_score +=
            sell_confluence.score * 0.3;
      }

      direction =
         (buy_score >= sell_score
          ? SCENARIO_DIRECTION_BUY
          : SCENARIO_DIRECTION_SELL);
   }
   else
   if(buy_candidate)
      direction =
         SCENARIO_DIRECTION_BUY;
   else
   if(sell_candidate)
      direction =
         SCENARIO_DIRECTION_SELL;

   if(direction ==
      SCENARIO_DIRECTION_NONE)
   {
      SetScenarioDiagnostic(
         "DIRECTION_FAIL | جهت نهایی تعیین نشد");
      return false;
   }

   //--- جلوگیری از ساخت Scenario مخالف قفل شدید
   if(!StrongDirectionalLockAllows(
      direction,
      htf))
   {
      SetScenarioDiagnostic(
         "DIRECTION_BLOCKED | جهت توسط قفل روند شدید مسدود شد | Direction=" +
         ScenarioDirectionToPersian(direction));

      return false;
   }

   ZoneInfo selected_zone;
   Zone_Init(selected_zone);

   if(direction ==
      SCENARIO_DIRECTION_BUY)
      selected_zone = buy_zone;
   else
      selected_zone = sell_zone;

   if(!Zone_IsValid(selected_zone))
   {
      double half =
         MathMax(
            atr_price * 0.35,
            _Point * 20.0);

      Zone_Create(
         900000 +
         (ulong)TimeCurrent(),
         ZONE_TYPE_STRUCTURE,
         direction ==
            SCENARIO_DIRECTION_BUY
         ? ZONE_DIRECTION_BUY
         : ZONE_DIRECTION_SELL,
         current_price - half,
         current_price + half,
         direction ==
            SCENARIO_DIRECTION_BUY
         ? current_price - atr_price
         : current_price + atr_price,
         TimeCurrent(),
         0,
         Inp_TF_Setup_M5,
         45.0,
         "MarketReading",
         "ناحیه مرجع موقت برای Opportunity بازار",
         selected_zone);
   }

   //===============================================================
   // Strategy Engine
   //===============================================================
   StrategyResult strategy_result;
   Strategy_Reset(strategy_result);

   bool strategy_created = false;

   if(direction ==
         SCENARIO_DIRECTION_SELL &&
      end_of_correction_sell_candidate)
   {
      strategy_created =
         CreateEndOfCorrectionSellScenario(
            current_price,
            end_of_correction_sell_quality,
            end_of_correction_sell_reason,
            new_scenario,
            strategy_result);

      if(!strategy_created)
         strategy_result.failure_reason =
            "ساخت Scenario برای EOC SELL ناموفق بود";
   }
   else
   if(direction ==
         SCENARIO_DIRECTION_BUY &&
      end_of_correction_buy_candidate)
   {
      strategy_created =
         CreateEndOfCorrectionBuyScenario(
            current_price,
            end_of_correction_buy_quality,
            end_of_correction_buy_reason,
            new_scenario,
            strategy_result);

      if(!strategy_created)
         strategy_result.failure_reason =
            "ساخت Scenario برای EOC BUY ناموفق بود";
   }
   else
   if(direction ==
         SCENARIO_DIRECTION_BUY)
   {
      strategy_created =
         StrategyEngine_AnalyzeBuyContinuation(
            _Symbol,
            g_regime,
            g_context,
            g_structure,
            g_move,
            buy_zone,
            current_price,
            new_scenario,
            strategy_result);
   }
   else
   if(direction ==
         SCENARIO_DIRECTION_SELL)
   {
      strategy_created =
         StrategyEngine_AnalyzeSellContinuation(
            _Symbol,
            g_regime,
            g_context,
            g_structure,
            g_move,
            sell_zone,
            current_price,
            new_scenario,
            strategy_result);
   }

   //===============================================================
   // Fallback
   //===============================================================
   if(!strategy_created)
   {
      bool fallback_created = false;

      if(!end_of_correction_sell_candidate &&
         direction ==
            SCENARIO_DIRECTION_SELL &&
         strong_sell_candidate)
      {
         fallback_created =
            BuildStrongTrendContinuationScenario(
               direction,
               sell_zone,
               current_price,
               new_scenario,
               strategy_result);
      }
      else
      if(!end_of_correction_buy_candidate &&
         direction ==
            SCENARIO_DIRECTION_BUY &&
         strong_buy_candidate)
      {
         fallback_created =
            BuildStrongTrendContinuationScenario(
               direction,
               buy_zone,
               current_price,
               new_scenario,
               strategy_result);
      }

      if(!fallback_created &&
         g_is_transition_mode)
      {
         fallback_created =
            BuildTransitionScenario(
               direction,
               selected_zone,
               current_price,
               new_scenario,
               strategy_result);

         if(fallback_created)
         {
            Print(
               "[TRANSITION SCENARIO] CREATED | Direction=",
               ScenarioDirectionToPersian(
                  direction),
               " | Quality=",
               DoubleToString(
                  strategy_result.quality,
                  1),
               " | Risk=50%");
         }
      }

      //=============================================================
      // Reversal fallback عمداً غیرفعال است
      //=============================================================
      if(!fallback_created)
      {
         SetScenarioDiagnostic(
            "STRATEGY_FAIL | " +
            (end_of_correction_sell_candidate
             ? "EOC SELL"
             :
             (end_of_correction_buy_candidate
              ? "EOC BUY"
              :
              (direction ==
                  SCENARIO_DIRECTION_BUY
               ? "BUY Continuation"
               : "SELL Continuation"))) +
            " | " +
            (strategy_result.failure_reason != ""
             ? strategy_result.failure_reason
             : "Strategy معتبر ساخته نشد"));

         AIJournal_LogDecision(
            0,
            ScenarioDirectionToPersian(
               direction),
            current_price,
            g_regime.regime,
            g_regime.confidence,
            false,
            g_structure.state,
            MathMax(
               g_structure.bullish_swing_streak,
               g_structure.bearish_swing_streak),
            (direction ==
               SCENARIO_DIRECTION_BUY
             ? htf_allows_buy
             : htf_allows_sell),
            divergence,
            (direction ==
               SCENARIO_DIRECTION_BUY
             ? buy_confluence.score
             : sell_confluence.score),
            0.0,
            AI_JOURNAL_REJECTED_STRATEGY,
            (strategy_result.failure_reason != ""
             ? strategy_result.failure_reason
             : "Strategy معتبر ساخته نشد"));

         return false;
      }

      SetScenarioDiagnostic(
         "STRATEGY_FALLBACK | " +
         StrategyTypeToPersian(
            strategy_result.type) +
         " | جهت=" +
         ScenarioDirectionToPersian(
            direction));
   }

   if(new_scenario.id <= 0 ||
      !Scenario_IsValid(
         new_scenario))
   {
      SetScenarioDiagnostic(
         "STRATEGY_SCENARIO_INVALID | " +
         StrategyTypeToPersian(
            strategy_result.type));

      return false;
   }

   if(strategy_result.quality <
      Inp_Min_Scenario_Quality)
   {
      SetScenarioDiagnostic(
         "STRATEGY_QUALITY_FAIL | Quality=" +
         DoubleToString(
            strategy_result.quality,
            1) +
         " | Min=" +
         DoubleToString(
            Inp_Min_Scenario_Quality,
            1));

      AIJournal_LogDecision(
         new_scenario.id,
         ScenarioDirectionToPersian(
            direction),
         current_price,
         g_regime.regime,
         g_regime.confidence,
         false,
         g_structure.state,
         MathMax(
            g_structure.bullish_swing_streak,
            g_structure.bearish_swing_streak),
         (direction ==
            SCENARIO_DIRECTION_BUY
          ? htf_allows_buy
          : htf_allows_sell),
         divergence,
         (direction ==
            SCENARIO_DIRECTION_BUY
          ? buy_confluence.score
          : sell_confluence.score),
         strategy_result.quality,
         AI_JOURNAL_REJECTED_QUALITY,
         "کیفیت Scenario کمتر از حداقل مجاز است");

      return false;
   }

   if(new_scenario.direction !=
      direction)
   {
      SetScenarioDiagnostic(
         "DIRECTION_MISMATCH | جهت Scenario با جهت نهایی یکی نیست");

      return false;
   }

   if(new_scenario.entry_price <= 0.0)
   {
      SetScenarioDiagnostic(
         "ENTRY_FAIL | Entry سناریو نامعتبر است");

      return false;
   }

   string entry_gate_reason = "";

   if(!EntryGate_AllowsContinuationAtSignal(
      direction,
      strategy_result.type,
      entry_gate_reason))
   {
      SetScenarioDiagnostic(
         "ENTRY_GATE_BLOCKED | " +
         entry_gate_reason +
         " | Strategy=" +
         StrategyTypeToPersian(strategy_result.type) +
         " | Direction=" +
         ScenarioDirectionToPersian(direction));

      Print(
         "[ENTRY GATE] سیگنال پیش از ایجاد معامله متوقف شد | ",
         entry_gate_reason,
         " | Strategy=",
         StrategyTypeToPersian(strategy_result.type),
         " | Direction=",
         ScenarioDirectionToPersian(direction));

      return false;
   }

   g_last_strategy_type = strategy_result.type;
   g_last_strategy_confidence = strategy_result.confidence;

   SetScenarioDiagnostic(
      "STRATEGY_SUCCESS | " +
      StrategyTypeToPersian(
         strategy_result.type) +
      " | ID=" +
      (string)new_scenario.id +
      " | Direction=" +
      ScenarioDirectionToPersian(
         new_scenario.direction) +
      " | Quality=" +
      DoubleToString(
         strategy_result.quality,
         1) +
      " | Entry=" +
      DoubleToString(
         new_scenario.entry_price,
         _Digits));

   AIJournal_LogDecision(
      new_scenario.id,
      ScenarioDirectionToPersian(
         direction),
      new_scenario.entry_price,
      g_regime.regime,
      g_regime.confidence,
      false,
      g_structure.state,
      MathMax(
         g_structure.bullish_swing_streak,
         g_structure.bearish_swing_streak),
      (direction ==
         SCENARIO_DIRECTION_BUY
       ? htf_allows_buy
       : htf_allows_sell),
      divergence,
      (direction ==
         SCENARIO_DIRECTION_BUY
       ? buy_confluence.score
       : sell_confluence.score),
      strategy_result.quality,
      AI_JOURNAL_FORMED,
      "سناریو با موفقیت ساخته شد");

   ENUM_ORDER_TYPE ord_dir =
      (direction ==
         SCENARIO_DIRECTION_BUY
       ? ORDER_TYPE_BUY
       : ORDER_TYPE_SELL);

   double target = 0.0;

   if(direction ==
      SCENARIO_DIRECTION_BUY &&
      g_structure.structural_high >
      new_scenario.entry_price)
   {
      target =
         g_structure.structural_high;
   }

   if(direction ==
      SCENARIO_DIRECTION_SELL &&
      g_structure.structural_low > 0.0 &&
      g_structure.structural_low <
      new_scenario.entry_price)
   {
      target =
         g_structure.structural_low;
   }

   if(target <= 0.0)
   {
      target =
         (direction ==
            SCENARIO_DIRECTION_BUY
          ?
            new_scenario.entry_price +
            atr_price * 2.0
          :
            new_scenario.entry_price -
            atr_price * 2.0);
   }

   if(!Scenario_SetTargets(
      new_scenario,
      target,
      0.0,
      0.0,
      TimeCurrent()))
   {
      SetScenarioDiagnostic(
         "SCENARIO_TARGET_SET_FAIL");
      return false;
   }

   if(!Target_Create(
      100000 + new_scenario.id,
      TARGET_TYPE_STRUCTURE,
      TARGET_PRIORITY_PRIMARY,
      target,
      0.0,
      0.0,
      TimeCurrent(),
      new_scenario.expiry_time,
      new_scenario.quality_value,
      "MarketStructure",
      "هدف ساختاری سناریو",
      new_target))
   {
      SetScenarioDiagnostic(
         "TARGET_ENGINE_CREATE_FAIL");
      return false;
   }

   if(!Target_SetEntryDistance(
      new_target,
      ord_dir,
      new_scenario.entry_price))
   {
      SetScenarioDiagnostic(
         "TARGET_ENTRY_DISTANCE_FAIL");
      return false;
   }

   if(!Target_UpdateStatus(
      new_target,
      TimeCurrent()))
   {
      SetScenarioDiagnostic(
         "TARGET_STATUS_FAIL");
      return false;
   }

   ENUM_SL_DIRECTION sl_dir =
      (direction ==
         SCENARIO_DIRECTION_BUY
       ? SL_DIRECTION_BUY
       : SL_DIRECTION_SELL);
   bool scenario_sl_ok =
      BuildExecutionSLFromScenario(
         direction,
         new_scenario,
         atr_price,
         new_sl_plan);

   if(!scenario_sl_ok)
   {
      if(!SL_FromMarketReferences(
         _Symbol,
         sl_dir,
         new_scenario.entry_price,
         g_structure,
         atr_price,
         _Point,
         new_sl_plan))
      {
         SetScenarioDiagnostic(
            "SL_FAIL | " +
            (new_sl_plan.reason != ""
             ? new_sl_plan.reason
             : "SL Engine نتوانست Reference مناسب ایجاد کند"));
         return false;
      }

      Print(
         "[SL FALLBACK] نقطه ابطال سناریو برای SL واقعی قابل استفاده نبود | Reference=",
         SLReferenceSourceToPersian(new_sl_plan.reference_source_type));
   }

   if(!SL_IsValid(new_sl_plan))
   {
      SetScenarioDiagnostic(
         "SL_VALIDATION_FAIL | SL=" +
         DoubleToString(new_sl_plan.stop_price,_Digits));
      return false;
   }

   Print(
      "[SL READY] | Reference=",
      SLReferenceToPersian(
         new_sl_plan.reference_source),
      " | Entry=",
      DoubleToString(
         new_sl_plan.entry_price,
         _Digits),
      " | SL=",
      DoubleToString(
         new_sl_plan.stop_price,
         _Digits),
      " | Distance=",
      DoubleToString(
         new_sl_plan.distance_price,
         _Digits),
      " | ATR=",
      DoubleToString(
         new_sl_plan.atr_value,
         _Digits));

   if(!EnsureTargetMeetsMinimumRR(
      direction,
      new_scenario.entry_price,
      new_sl_plan.stop_price,
      target,
      atr_price))
   {
      SetScenarioDiagnostic(
         "TARGET_RR_PROTECTION_FAIL");
      return false;
   }

   double system_target = target;
   double tp2_price = system_target;

   double min_reward =
      MathAbs(
         new_scenario.entry_price -
         new_sl_plan.stop_price);

   double tp1_price = 0.0;

   if(direction ==
      SCENARIO_DIRECTION_BUY)
      tp1_price =
         new_scenario.entry_price +
         min_reward;
   else
      tp1_price =
         new_scenario.entry_price -
         min_reward;

   double half_tp =
      new_scenario.entry_price +
      (system_target -
       new_scenario.entry_price) *
      0.50;

   if(direction ==
         SCENARIO_DIRECTION_BUY &&
      half_tp > tp1_price)
      tp1_price = half_tp;
   else
   if(direction ==
         SCENARIO_DIRECTION_SELL &&
      half_tp < tp1_price)
      tp1_price = half_tp;

   if(!Scenario_SetTargets(
      new_scenario,
      tp1_price,
      tp2_price,
      0.0,
      TimeCurrent()))
   {
      SetScenarioDiagnostic(
         "SCENARIO_TARGET_SPLIT_FAIL");
      return false;
   }

   if(direction ==
         SCENARIO_DIRECTION_BUY &&
      target <=
      new_scenario.entry_price)
   {
      SetScenarioDiagnostic(
         "TP1_DIRECTION_FAIL | TP1 باید بالاتر از Entry باشد");
      return false;
   }

   if(direction ==
         SCENARIO_DIRECTION_SELL &&
      target >=
      new_scenario.entry_price)
   {
      SetScenarioDiagnostic(
         "TP1_DIRECTION_FAIL | TP1 باید پایین‌تر از Entry باشد");
      return false;
   }

   TP_Target tp_target;
   TP_TargetInit(tp_target);

   if(!TP_CreateTarget(
      1,
      TP_TARGET_STRUCTURE,
      TP_STATUS_VALID,
      tp1_price,
      new_scenario.quality_value,
      "هدف ساختاری سناریو",
      "MarketStructure",
      tp_target))
   {
      SetScenarioDiagnostic(
         "TP_CREATE_FAIL");
      return false;
   }

   TP_SetTarget(
      new_tp_result,
      1,
      tp_target);

   TP_ValidateTargets(
      direction ==
         SCENARIO_DIRECTION_BUY,
      new_scenario.entry_price,
      new_tp_result);

   new_tp_result.valid =
      TP_HasValidTarget(
         new_tp_result);

   if(!new_tp_result.valid)
   {
      SetScenarioDiagnostic(
         "TP_VALIDATION_FAIL");
      return false;
   }

   if(!Scenario_SetTargets(
      new_scenario,
      tp1_price,
      tp2_price,
      0.0,
      TimeCurrent()))
   {
      SetScenarioDiagnostic(
         "FINAL_TARGET_ASSIGN_FAIL");
      return false;
   }

   Print(
      "[TARGET DIAGNOSTIC] | Entry=",
      DoubleToString(
         new_scenario.entry_price,
         _Digits),
      " | SL=",
      DoubleToString(
         new_sl_plan.stop_price,
         _Digits),
      " | TP1=",
      DoubleToString(
         new_scenario.target_1,
         _Digits),
      " | RR=",
      DoubleToString(
         MathAbs(
            new_scenario.target_1 -
            new_scenario.entry_price) /
         MathMax(
            MathAbs(
               new_scenario.entry_price -
               new_sl_plan.stop_price),
            _Point),
         2),
      " | TP2=",
      DoubleToString(
         new_scenario.target_2,
         _Digits));

   if(!Scenario_IsValid(
      new_scenario))
   {
      SetScenarioDiagnostic(
         "FINAL_SCENARIO_VALIDATION_FAIL");
      return false;
   }

//--- [جدید] کاهش ضریب اطمینان در رژیم نامشخص
if(g_regime.valid && g_regime.regime == MARKET_REGIME_UNCERTAIN)
{
   new_scenario.quality_value *= 0.70;
   Print("[REGIME UNCERTAIN] ضریب اطمینان سناریو 30% کاهش یافت | Quality=", 
         DoubleToString(new_scenario.quality_value, 1));
}

   SetScenarioDiagnostic(
      "SCENARIO_SUCCESS | ID=" +
      (string)new_scenario.id +
      (g_is_transition_mode
       ? " | TRANSITION_MODE"
       : "") +
      " | Strategy=" +
      StrategyTypeToPersian(
         strategy_result.type) +
      " | Direction=" +
      ScenarioDirectionToPersian(
         new_scenario.direction) +
      " | Quality=" +
      DoubleToString(
         new_scenario.quality_value,
         1) +
      " | Entry=" +
      DoubleToString(
         new_scenario.entry_price,
         _Digits) +
      " | Target=" +
      DoubleToString(
         new_scenario.target_1,
         _Digits) +
      " | SL=" +
      DoubleToString(
         new_sl_plan.stop_price,
         _Digits));

   return true;
}

//====================================================================
// بررسی یکسان بودن دو سناریو
//====================================================================
bool IsSameScenario(
   const TradingScenario &old_scenario,
   const TradingScenario &new_scenario)
{
   if(old_scenario.id == 0 ||
      new_scenario.id == 0)
      return false;

   if(old_scenario.direction !=
      new_scenario.direction)
      return false;

   if(MathAbs(
      old_scenario.entry_price -
      new_scenario.entry_price) > 2.0)
      return false;

   if(MathAbs(
      old_scenario.invalidation_price -
      new_scenario.invalidation_price) > 2.0)
      return false;

   if(MathAbs(
      old_scenario.target_1 -
      new_scenario.target_1) > 2.0)
      return false;

   return true;
}

//====================================================================
// یافتن معامله باز مربوط به Scenario
//====================================================================
bool HasOpenPositionForScenario(
   const ulong scenario_id)
{
   if(scenario_id == 0)
      return false;

   const string tag =
      "TFlab S#" +
      (string)scenario_id +
      " |";

   for(int i = 0;
       i < PositionsTotal();
       i++)
   {
      const ulong ticket =
         PositionGetTicket(i);

      if(ticket == 0 ||
         !PositionSelectByTicket(ticket))
         continue;

      if(PositionGetString(
            POSITION_SYMBOL) != _Symbol)
         continue;

      if((ulong)PositionGetInteger(
            POSITION_MAGIC) !=
         Inp_MagicNumber)
         continue;

      if(StringFind(
         PositionGetString(
            POSITION_COMMENT),
         tag) >= 0)
         return true;
   }

   return false;
}

//====================================================================
// استخراج ScenarioID از Comment
//====================================================================
ulong ExtractScenarioIdFromComment(const string comment)
{
   int p1 = StringFind(comment, "TFlab S#");
   if(p1 < 0)
      return 0;

   p1 += 8;

   int p2 = StringFind(comment, " ", p1);
   string id_str =
      (p2 > p1
       ? StringSubstr(comment, p1, p2 - p1)
       : StringSubstr(comment, p1));

   if(id_str == "")
      return 0;

   return (ulong)StringToInteger(id_str);
}

//====================================================================
// استخراج قیمت از برچسب داخل Comment
//====================================================================
double ExtractPriceTagFromComment(const string comment, const string tag)
{
   if(comment == "" || tag == "")
      return 0.0;

   int start = StringFind(comment, tag);
   if(start < 0)
      return 0.0;

   start += StringLen(tag);
   int end = StringFind(comment, " ", start);
   if(end < 0)
      end = StringFind(comment, "|", start);

   string value = (end > start
                   ? StringSubstr(comment, start, end - start)
                   : StringSubstr(comment, start));

   if(value == "")
      return 0.0;

   return StringToDouble(value);
}

void ExtractOriginalScenarioTargets(const string comment,
                                    double &tp1,
                                    double &tp2)
{
   tp1 = ExtractPriceTagFromComment(comment, "TP1=");
   tp2 = ExtractPriceTagFromComment(comment, "TP2=");
}

//====================================================================
// استخراج حد ضرر اولیه سناریو از Comment
//====================================================================
double ExtractOriginalScenarioSL(const string comment)
{
   return ExtractPriceTagFromComment(comment, "SL=");
}

//====================================================================
// دریافت ATR جاری بر حسب قیمت
//====================================================================
double GetCurrentATRPrice()
{
   double atr_price = g_move.impulse_atr;

   if(atr_price <= 0.0 && g_context.atr_points > 0.0)
      atr_price = g_context.atr_points * _Point;

   if(atr_price <= 0.0 && g_m5_metrics.atr_points > 0.0)
      atr_price = g_m5_metrics.atr_points * _Point;

   return atr_price;
}

//====================================================================
// تعداد معاملات باز مربوط به یک Scenario
//====================================================================
int CountOpenPositionsForScenario(const ulong scenario_id)
{
   if(scenario_id == 0)
      return 0;

   int count = 0;

   for(int i = 0; i < PositionsTotal(); i++)
   {
      ulong ticket = PositionGetTicket(i);
      if(ticket == 0 || !PositionSelectByTicket(ticket))
         continue;

      if(PositionGetString(POSITION_SYMBOL) != _Symbol)
         continue;

      if((ulong)PositionGetInteger(POSITION_MAGIC) != Inp_MagicNumber)
         continue;

      ulong sid = ExtractScenarioIdFromComment(
         PositionGetString(POSITION_COMMENT));

      if(sid == scenario_id)
         count++;
   }

   return count;
}

//====================================================================
// تعداد Pendingهای مربوط به یک Scenario در خود حساب
// این تابع به State داخلی وابسته نیست؛ بعد از ری‌استارت هم درست می‌خواند.
//====================================================================
int CountPendingOrdersForScenario(const ulong scenario_id)
{
   if(scenario_id == 0)
      return 0;

   int count = 0;

   for(int i = 0; i < OrdersTotal(); i++)
   {
      ulong ticket = OrderGetTicket(i);
      if(ticket == 0)
         continue;

      if(OrderGetString(ORDER_SYMBOL) != _Symbol)
         continue;

      if((ulong)OrderGetInteger(ORDER_MAGIC) != Inp_MagicNumber)
         continue;

      ENUM_ORDER_TYPE type =
         (ENUM_ORDER_TYPE)OrderGetInteger(ORDER_TYPE);

      if(type != ORDER_TYPE_BUY_LIMIT  &&
         type != ORDER_TYPE_SELL_LIMIT &&
         type != ORDER_TYPE_BUY_STOP   &&
         type != ORDER_TYPE_SELL_STOP)
         continue;

      ulong sid = ExtractScenarioIdFromComment(
         OrderGetString(ORDER_COMMENT));

      if(sid == scenario_id)
         count++;
   }

   return count;
}

//====================================================================
// تعداد Exposure واقعی یک Scenario
// Market + Pending
//====================================================================
int CountScenarioExposure(const ulong scenario_id)
{
   return CountOpenPositionsForScenario(scenario_id) +
          CountPendingOrdersForScenario(scenario_id);
}

//====================================================================
// آماده‌سازی Pool داخلی Pending
//====================================================================
void PendingPool_Init()
{
   ArrayResize(g_pending_pool, TFLAB_PENDING_TRACK_LIMIT);

   for(int i = 0; i < ArraySize(g_pending_pool); i++)
      PendingOrder_Init(g_pending_pool[i]);

   PendingOrder_Init(g_pending);
}

//====================================================================
// ذخیره یک Pending اضافه در Pool
//====================================================================
bool PendingPool_Store(const PendingOrderRecord &record)
{
   if(record.ticket == 0 || !record.active)
      return false;

   for(int i = 0; i < ArraySize(g_pending_pool); i++)
   {
      if(g_pending_pool[i].ticket == record.ticket)
      {
         g_pending_pool[i] = record;
         return true;
      }
   }

   for(int i = 0; i < ArraySize(g_pending_pool); i++)
   {
      if(g_pending_pool[i].ticket == 0 || !g_pending_pool[i].active)
      {
         g_pending_pool[i] = record;
         return true;
      }
   }

   Print("[PENDING POOL] ظرفیت داخلی Pool پر است | Ticket=",
         record.ticket);
   return false;
}

//====================================================================
// حذف رکورد تمام‌شده از Pool
//====================================================================
void PendingPool_Clean()
{
   for(int i = 0; i < ArraySize(g_pending_pool); i++)
   {
      if(g_pending_pool[i].ticket == 0)
         continue;

      if(g_pending_pool[i].active)
         continue;

      PendingOrder_Init(g_pending_pool[i]);
   }
}

//====================================================================
// ساخت Comment یکتا برای هر عضو سهمیه
//====================================================================
string MakeSignalTradeComment(const int index,
                              const int total,
                              const string suffix = "")
{
   string base = MakeScenarioComment(
      g_scenario.id,
      g_scenario.target_1,
      g_scenario.target_2,
      g_sl_plan.stop_price);

   // برچسب استراتژی را در ابتدای Comment می‌گذاریم تا حتی با
   // کوتاه‌شدن Comment توسط بروکر/ترمینال، تشخیص SELL Continuation
   // از بین نرود. ST=SC/BC نیز برای سازگاری با لاگ‌های قبلی حفظ می‌شود.
   string strategy_prefix = "";

   if(g_last_strategy_type == STRATEGY_SELL_CONTINUATION)
      strategy_prefix = "TFlab SC | ";
   else if(g_last_strategy_type == STRATEGY_BUY_CONTINUATION)
      strategy_prefix = "TFlab BC | ";

   string c = strategy_prefix + base + " | STrade=" +
              IntegerToString(index) + "/" +
              IntegerToString(total);

   if(g_last_strategy_type == STRATEGY_SELL_CONTINUATION)
      c += " | ST=SC";
   else if(g_last_strategy_type == STRATEGY_BUY_CONTINUATION)
      c += " | ST=BC";

   if(suffix != "")
      c += " | " + suffix;

   return c;
}

//====================================================================
// لغو مستقیم یک Pending واقعی بر اساس Ticket
// برای سفارش‌هایی که State داخلی ندارند نیز کار می‌کند.
//====================================================================
bool RemovePendingTicket(const ulong ticket,
                         const string reason)
{
   if(ticket == 0)
      return false;

   if(!OrderSelect(ticket))
      return true;

   MqlTradeRequest req;
   MqlTradeResult  res;
   ZeroMemory(req);
   ZeroMemory(res);

   req.action = TRADE_ACTION_REMOVE;
   req.order  = ticket;
   req.magic  = Inp_MagicNumber;
   req.symbol = _Symbol;

   ResetLastError();

   if(!OrderSend(req, res))
   {
      Print("[PENDING REMOVE FAIL] Ticket=", ticket,
            " | Error=", GetLastError(),
            " | Reason=", reason,
            " | Retcode=", res.retcode);
      return false;
   }

   if(res.retcode == TRADE_RETCODE_DONE ||
      res.retcode == TRADE_RETCODE_PLACED)
   {
      Print("[PENDING REMOVE] Ticket=", ticket,
            " | Reason=", reason);
      return true;
   }

   Print("[PENDING REMOVE REJECTED] Ticket=", ticket,
         " | Reason=", reason,
         " | Retcode=", res.retcode);
   return false;
}

//====================================================================
// لغو تمام Pendingهای یک Scenario
//====================================================================
void CancelPendingOrdersForScenario(const ulong scenario_id,
                                    const string reason)
{
   if(scenario_id == 0)
      return;

   for(int i = OrdersTotal() - 1; i >= 0; i--)
   {
      ulong ticket = OrderGetTicket(i);
      if(ticket == 0)
         continue;

      if(OrderGetString(ORDER_SYMBOL) != _Symbol)
         continue;

      if((ulong)OrderGetInteger(ORDER_MAGIC) != Inp_MagicNumber)
         continue;

      ENUM_ORDER_TYPE type =
         (ENUM_ORDER_TYPE)OrderGetInteger(ORDER_TYPE);

      if(type != ORDER_TYPE_BUY_LIMIT  &&
         type != ORDER_TYPE_SELL_LIMIT &&
         type != ORDER_TYPE_BUY_STOP   &&
         type != ORDER_TYPE_SELL_STOP)
         continue;

      ulong sid = ExtractScenarioIdFromComment(
         OrderGetString(ORDER_COMMENT));

      if(sid != scenario_id)
         continue;

      if(RemovePendingTicket(ticket, reason))
         SignalAudit_MarkCapture(g_signal_audit,scenario_id,"Pending لغو شد");
   }

   PendingPool_Clean();
}

//====================================================================
// انتخاب یک Pending اصلی برای Legacy State
//====================================================================
void SyncPrimaryPendingState()
{
   if(g_pending.active && g_pending.ticket > 0)
      return;

   for(int i = 0; i < ArraySize(g_pending_pool); i++)
   {
      if(g_pending_pool[i].active &&
         g_pending_pool[i].ticket > 0)
      {
         g_pending = g_pending_pool[i];
         return;
      }
   }

   //--- اگر State داخلی خالی است، از سفارش واقعی حساب یک رکورد بساز.
   for(int i = 0; i < OrdersTotal(); i++)
   {
      ulong ticket = OrderGetTicket(i);
      if(ticket == 0)
         continue;

      if(OrderGetString(ORDER_SYMBOL) != _Symbol)
         continue;

      if((ulong)OrderGetInteger(ORDER_MAGIC) != Inp_MagicNumber)
         continue;

      ENUM_ORDER_TYPE type =
         (ENUM_ORDER_TYPE)OrderGetInteger(ORDER_TYPE);

      if(type != ORDER_TYPE_BUY_LIMIT  &&
         type != ORDER_TYPE_SELL_LIMIT &&
         type != ORDER_TYPE_BUY_STOP   &&
         type != ORDER_TYPE_SELL_STOP)
         continue;

      ulong sid = ExtractScenarioIdFromComment(
         OrderGetString(ORDER_COMMENT));

      if(sid == 0)
         continue;

      PendingOrder_Init(g_pending);
      g_pending.local_id       = ticket;
      g_pending.scenario_id    = sid;
      g_pending.ticket         = ticket;
      g_pending.symbol         = OrderGetString(ORDER_SYMBOL);
      g_pending.volume         = OrderGetDouble(ORDER_VOLUME_CURRENT);
      g_pending.price          = OrderGetDouble(ORDER_PRICE_OPEN);
      g_pending.stop_loss      = OrderGetDouble(ORDER_SL);
      g_pending.take_profit    = OrderGetDouble(ORDER_TP);
      g_pending.created_time   = (datetime)OrderGetInteger(ORDER_TIME_SETUP);
      g_pending.placed_time    = g_pending.created_time;
      g_pending.expiry_time    = (datetime)OrderGetInteger(ORDER_TIME_EXPIRATION);
      g_pending.last_update_time = TimeCurrent();
      g_pending.active         = true;
      g_pending.state          = PENDING_STATE_ACTIVE;
      g_pending.broker_comment = OrderGetString(ORDER_COMMENT);

      if(type == ORDER_TYPE_BUY_LIMIT ||
         type == ORDER_TYPE_SELL_LIMIT)
         g_pending.plan_type = ENTRY_PLAN_LIMIT;
      else
         g_pending.plan_type = ENTRY_PLAN_STOP;

      g_pending.direction =
         (type == ORDER_TYPE_BUY_LIMIT ||
          type == ORDER_TYPE_BUY_STOP)
         ? SCENARIO_DIRECTION_BUY
         : SCENARIO_DIRECTION_SELL;

      return;
   }
}

//====================================================================
// نگه‌داری State اصلی قبل/بعد از هر چرخه
//====================================================================
void RefreshPendingPoolStates()
{
   for(int i = 0; i < ArraySize(g_pending_pool); i++)
   {
      if(g_pending_pool[i].ticket == 0)
         continue;

      PendingOrder_UpdateState(
         g_pending_pool[i],
         TimeCurrent());
   }

   if(g_pending.ticket > 0)
      PendingOrder_UpdateState(
         g_pending,
         TimeCurrent());

   PendingPool_Clean();
   SyncPrimaryPendingState();
}

//====================================================================
// اصلاح SL/TP معامله
//====================================================================
bool ModifyPositionSLTP(
   const ulong ticket,
   const string symbol,
   const double new_sl,
   const double new_tp)
{
   if(ticket == 0)
      return false;

   double sl =
      NormalizeDouble(
         new_sl,
         _Digits);

   double tp =
      NormalizeDouble(
         new_tp,
         _Digits);

   if(sl <= 0.0 &&
      tp <= 0.0)
      return false;

   MqlTradeRequest req;
   MqlTradeResult res;

   ZeroMemory(req);
   ZeroMemory(res);

   req.action =
      TRADE_ACTION_SLTP;

   req.position = ticket;
   req.symbol = symbol;
   req.sl = sl;
   req.tp = tp;

   ResetLastError();

   if(!OrderSend(req, res))
   {
      Print(
         "[SLTP MODIFY FAIL] | Ticket=",
         ticket,
         " | Error=",
         GetLastError(),
         " | Retcode=",
         res.retcode);

      return false;
   }

   return
      (res.retcode ==
         TRADE_RETCODE_DONE ||
       res.retcode ==
         TRADE_RETCODE_DONE_PARTIAL);
}

//====================================================================
// بستن حجم معامله
//====================================================================
bool ClosePositionVolume(
   const ulong ticket,
   const string symbol,
   const bool is_buy,
   const double volume,
   const string comment)
{
   if(ticket == 0)
      return false;

   double close_volume =
      NormalizeVolume(volume);

   if(close_volume <= 0.0)
      return false;

   MqlTradeRequest req;
   MqlTradeResult res;

   ZeroMemory(req);
   ZeroMemory(res);

   MqlTick tick;

   if(!SymbolInfoTick(
      symbol,
      tick))
      return false;

   req.action =
      TRADE_ACTION_DEAL;

   req.position = ticket;
   req.symbol = symbol;
   req.volume = close_volume;

   req.type =
      (is_buy
       ? ORDER_TYPE_SELL
       : ORDER_TYPE_BUY);

   req.price =
      (is_buy
       ? tick.bid
       : tick.ask);

   req.deviation =
      (ulong)Inp_MaxSlippagePoints;

   req.magic =
      Inp_MagicNumber;

   req.comment =
      comment;

   req.type_filling =
      Execution_GetFillingType(
         symbol);

   ResetLastError();

   if(!OrderSend(req, res))
   {
      Print(
         "[CLOSE POSITION FAIL] | Ticket=",
         ticket,
         " | Error=",
         GetLastError());

      return false;
   }

   return
      (res.retcode ==
         TRADE_RETCODE_DONE ||
       res.retcode ==
         TRADE_RETCODE_DONE_PARTIAL);
}

//====================================================================
// بستن معاملات باز مخالف جهت
//====================================================================
void CloseOppositePositions(
   ENUM_SCENARIO_DIRECTION new_direction)
{
   if(!Inp_Close_Opposite_On_Reverse)
      return;

   if(new_direction ==
      SCENARIO_DIRECTION_NONE)
      return;

   for(int i =
      PositionsTotal() - 1;
      i >= 0;
      i--)
   {
      ulong ticket =
         PositionGetTicket(i);

      if(ticket == 0)
         continue;

      if(!PositionSelectByTicket(
         ticket))
         continue;

      if(PositionGetString(
            POSITION_SYMBOL) != _Symbol)
         continue;

      if((ulong)PositionGetInteger(
            POSITION_MAGIC) !=
         Inp_MagicNumber)
         continue;

      long pos_type =
         PositionGetInteger(
            POSITION_TYPE);

      bool is_buy =
         (pos_type ==
            POSITION_TYPE_BUY);

      bool is_sell =
         (pos_type ==
            POSITION_TYPE_SELL);

      if((new_direction ==
            SCENARIO_DIRECTION_BUY &&
          is_sell) ||
         (new_direction ==
            SCENARIO_DIRECTION_SELL &&
          is_buy))
      {
         double vol =
            PositionGetDouble(
               POSITION_VOLUME);

         string comment =
            "TFlab Reverse Close (New Scenario)";

         if(ClosePositionVolume(
            ticket,
            _Symbol,
            is_buy,
            vol,
            comment))
         {
            Print(
               "[REVERSE CLOSE] معامله مخالف بسته شد | Ticket=",
               ticket,
               " | جهت قبلی=",
               (is_buy
                ? "BUY"
                : "SELL"),
               " | سناریوی جدید=",
               ScenarioDirectionToPersian(
                  new_direction));
         }
      }
   }
}

//====================================================================
// تعداد پوزیشن‌های باز در یک جهت
//====================================================================
int CountOpenPositionsByDirection(
   const ENUM_SCENARIO_DIRECTION direction)
{
   int count = 0;

   for(int i = 0;
       i < PositionsTotal();
       i++)
   {
      ulong ticket =
         PositionGetTicket(i);

      if(ticket == 0)
         continue;

      if(!PositionSelectByTicket(
         ticket))
         continue;

      if(PositionGetString(
            POSITION_SYMBOL) != _Symbol)
         continue;

      if((ulong)PositionGetInteger(
            POSITION_MAGIC) !=
         Inp_MagicNumber)
         continue;

      ENUM_POSITION_TYPE pos_type =
         (ENUM_POSITION_TYPE)
         PositionGetInteger(
            POSITION_TYPE);

      if(direction ==
            SCENARIO_DIRECTION_BUY &&
         pos_type ==
            POSITION_TYPE_BUY)
      {
         count++;
      }
      else
      if(direction ==
            SCENARIO_DIRECTION_SELL &&
         pos_type ==
            POSITION_TYPE_SELL)
      {
         count++;
      }
   }

   return count;
}

//====================================================================
// بستن معاملات مخالف و Verify
//====================================================================
bool CloseOppositePositionsAndVerify(
   const ENUM_SCENARIO_DIRECTION new_direction)
{
   if(new_direction ==
      SCENARIO_DIRECTION_NONE)
      return false;

   ENUM_SCENARIO_DIRECTION opposite_direction =
      (new_direction ==
         SCENARIO_DIRECTION_BUY
       ?
         SCENARIO_DIRECTION_SELL
       :
         SCENARIO_DIRECTION_BUY);

   if(CountOpenPositionsByDirection(
      opposite_direction) == 0)
      return true;

   CloseOppositePositions(
      new_direction);

   for(int attempt = 0;
       attempt < 5;
       attempt++)
   {
      Sleep(100);

      if(CountOpenPositionsByDirection(
         opposite_direction) == 0)
      {
         Print(
            "[REVERSE VERIFY] معامله مخالف کاملاً بسته شد | NewDirection=",
            ScenarioDirectionToPersian(
               new_direction));

         return true;
      }
   }

   int remaining =
      CountOpenPositionsByDirection(
         opposite_direction);

   Print(
      "[REVERSE BLOCKED] معامله مخالف هنوز باز است | Remaining=",
      remaining,
      " | NewDirection=",
      ScenarioDirectionToPersian(
         new_direction));

   return false;
}

//====================================================================
// محاسبه TP2 پویا
//====================================================================
bool CalculateDynamicTP2(
   const bool is_buy,
   const double current_price,
   const double tp1,
   double &tp2,
   string &reason)
{
   tp2 = 0.0;
   reason = "";

   if(current_price <= 0.0 ||
      tp1 <= 0.0)
      return false;

   MarketStructureSnapshot fresh_structure;
   MarketStructure_Reset(
      fresh_structure);

   bool structure_ok =
      MarketStructure_Analyze(
         _Symbol,
         Inp_TF_Structure_M15,
         120,
         2,
         2,
         20.0,
         fresh_structure);

   double atr_price =
      g_move.impulse_atr;

   if(atr_price <= 0.0)
      atr_price =
         g_context.atr_points *
         _Point;

   if(atr_price <= 0.0)
      atr_price =
         _Point * 20.0;

   if(structure_ok)
   {
      if(is_buy &&
         fresh_structure.structural_high >
            tp1 &&
         fresh_structure.structural_high >
            current_price)
      {
         tp2 =
            fresh_structure.structural_high;

         reason =
            "TP2 بر اساس ساختار تازه M15";
      }
      else
      if(!is_buy &&
         fresh_structure.structural_low > 0.0 &&
         fresh_structure.structural_low < tp1 &&
         fresh_structure.structural_low < current_price)
      {
         tp2 =
            fresh_structure.structural_low;

         reason =
            "TP2 بر اساس ساختار تازه M15";
      }
   }

   if(tp2 <= 0.0)
   {
      if(is_buy)
         tp2 =
            tp1 + atr_price;
      else
         tp2 =
            tp1 - atr_price;

      reason =
         "TP2 بر اساس ATR تازه";
   }

   tp2 =
      NormalizeDouble(
         tp2,
         (int)SymbolInfoInteger(
            _Symbol,
            SYMBOL_DIGITS));

   return
      (is_buy
       ? tp2 > tp1
       : tp2 < tp1);
}

//====================================================================
// قفل داخلی Pending
//====================================================================
void LockEntryPlanToActivePending()
{
   if(!g_pending.active ||
      g_pending.ticket == 0)
      return;

   if(g_pending.scenario_id !=
      g_scenario.id)
      return;

   g_entry_plan.type =
      g_pending.plan_type;

   g_entry_plan.status =
      ENTRY_PLAN_STATUS_SENT;

   g_entry_plan.executable =
      false;

   g_entry_plan.entry_currently_available =
      false;

   g_entry_plan.entry_reachable =
      true;

   g_entry_plan.reason =
      "Pending واقعی فعال است؛ مسیر ورود قفل شد | Ticket=" +
      (string)g_pending.ticket;
}

//====================================================================
// V5.116: گیت False-BUY در انتهای حرکت کشیده
// فقط مسیر Opportunity مستقیم را کنترل می‌کند؛ فرصت‌یابی عمومی و SELL
// را تغییر نمی‌دهد. هدف: BUY صرفاً به‌خاطر Truth قوی، در انتهای حرکت
// بدون Reaction/Trigger تازه وارد نشود.
//====================================================================
bool V594_DirectBuyHasFreshTrigger(
   const double current_price,
   const double atr_price,
   const ImpulseCorrectionSnapshot &live_move,
   const MarketReadingSnapshot &live_reading,
   const MarketStructureSnapshot &live_structure,
   const MarketTruthSnapshot &live_truth,
   string &reason)
{
   reason = "";

   if(!Inp_Buy_Direct_Exhaustion_Guard_Enabled)
      return true;

   if(current_price <= 0.0 || atr_price <= 0.0)
      return true;

   const double truth_stretch =
      (live_truth.valid ? live_truth.move_atr_multiple : 0.0);
   const double impulse_stretch =
      (live_move.valid && live_move.impulse_valid
       ? live_move.impulse_atr_multiple : 0.0);

   const bool stretched =
      (truth_stretch >= Inp_Buy_Direct_Exhaustion_Truth_ATR ||
       impulse_stretch >= Inp_Buy_Direct_Exhaustion_Impulse_ATR);

   if(!stretched)
      return true;

   // اصلاح نزولی + فشار صعودی فعلی = بازگشت واقعی از اصلاح و Trigger قابل قبول.
   const bool recovered_pullback =
      live_move.valid &&
      live_move.correction_valid &&
      live_move.correction_direction < 0 &&
      live_reading.current_up_pressure;

   double previous_high = iHigh(_Symbol,Inp_TF_Setup_M5,1);
   double previous_close = iClose(_Symbol,Inp_TF_Setup_M5,1);

   const bool closed_bar_breakout =
      (previous_high > 0.0 &&
       current_price > previous_high + atr_price * 0.03);

   const double current_body =
      MathAbs(live_reading.current_price - live_reading.candle_open);

   const bool fresh_body_trigger =
      (previous_close > 0.0 &&
       current_price > previous_close &&
       current_body >= atr_price * 0.10);

   const bool strong_bull_structure =
      live_structure.valid &&
      live_structure.state == STRUCTURE_STATE_BULLISH &&
      live_structure.bullish_sequence;

   // در حرکت کشیده، یکی از سه Trigger واقعی باید وجود داشته باشد:
   // اصلاح معتبر، شکست سقف کندل بسته‌شده، یا بدنه تازه همراه با ساختار صعودی کامل.
   if(recovered_pullback ||
      closed_bar_breakout ||
      (strong_bull_structure && fresh_body_trigger))
      return true;

   reason =
      "BUY مستقیم در حرکت کشیده بدون Trigger تازه متوقف شد" +
      " | TruthMoveATR=" + DoubleToString(truth_stretch,2) +
      " | ImpulseATR=" + DoubleToString(impulse_stretch,2) +
      " | انتظار=اصلاح معتبر یا شکست تازه یا بدنه تأییدشده";

   Print("[V5.116 BUY EXHAUSTION BLOCK] ", reason);
   return false;
}

//====================================================================
// مدیریت Scenario و Entry
//====================================================================

//====================================================================
// V5.116: تضاد Truth میان‌مدت برای Opportunity مستقیم
// فقط وقتی M15 و M30 هر دو خلاف جهت فرصت باشند و حداقل یکی از آنها
// حرکت مخالف معنادار داشته باشد، ورود مستقیم متوقف می‌شود.
// H4/H1 همچنان صرفاً زمینه هستند و در تصمیم مستقیم جایگزین نمی‌شوند.
//====================================================================
bool V594_DirectOpportunityPassesMultiTFTruth(
   const ENUM_SCENARIO_DIRECTION direction,
   string &reason)
{
   reason = "";

   if(!Inp_Direct_Opportunity_MTF_Truth_Guard_Enabled)
      return true;

   // V5.116: M15/M30 فقط Context هستند و دیگر مجوز ورود M5 را لغو نمی‌کنند.
   // تصمیم Direction/Entry در این مسیر بر پایه Market Truth و ساختار/حرکت زنده M5 است.
   MarketTruthSnapshot m15_truth;
   MarketTruthSnapshot m30_truth;
   MarketTruth_Reset(m15_truth);
   MarketTruth_Reset(m30_truth);

   const bool m15_ok =
      MarketTruth_Analyze(
         _Symbol,
         PERIOD_M15,
         Inp_Market_Truth_Lookback,
         m15_truth);

   const bool m30_ok =
      MarketTruth_Analyze(
         _Symbol,
         PERIOD_M30,
         Inp_Market_Truth_Lookback,
         m30_truth);

   if(!m15_ok || !m30_ok ||
      !m15_truth.valid || !m30_truth.valid)
      return true;

   const bool is_buy =
      (direction == SCENARIO_DIRECTION_BUY);

   const ENUM_MARKET_TRUTH_DIRECTION opposite =
      (is_buy
       ? MARKET_TRUTH_SELL
       : MARKET_TRUTH_BUY);

   const bool m15_opposite =
      (m15_truth.direction == opposite);
   const bool m30_opposite =
      (m30_truth.direction == opposite);

   const bool m15_strong =
      m15_opposite &&
      m15_truth.strong_market_move &&
      m15_truth.move_atr_multiple >=
         Inp_Direct_Opportunity_MTF_Truth_Min_ATR;

   const bool m30_strong =
      m30_opposite &&
      m30_truth.strong_market_move &&
      m30_truth.move_atr_multiple >=
         Inp_Direct_Opportunity_MTF_Truth_Min_ATR;

   if(m15_opposite && m30_opposite &&
      (m15_strong || m30_strong))
   {
      reason =
         (is_buy
          ? "Context M15/M30 خلاف BUY است؛ فقط به‌عنوان هشدار ثبت شد و ورود M5 متوقف نمی‌شود"
          : "Context M15/M30 خلاف SELL است؛ فقط به‌عنوان هشدار ثبت شد و ورود M5 متوقف نمی‌شود") +
         " | M15=" + MarketTruth_DirectionToString(m15_truth.direction) +
         "(" + DoubleToString(m15_truth.move_atr_multiple,2) + "ATR)" +
         " | M30=" + MarketTruth_DirectionToString(m30_truth.direction) +
         "(" + DoubleToString(m30_truth.move_atr_multiple,2) + "ATR)";
      Print("[V5.116 DIRECT MTF CONTEXT] ",reason);
   }

   return true;
}

//====================================================================
// V5.116: جلوگیری از تعقیب حرکت کشیده در ساختار متعادل
// در V5.116 این مشکل برای BUY با گیت اختصاصی پوشش داده شده بود،
// اما SELL مستقیم نیز در 22 سپتامبر با TruthMoveATR=7.07 وارد شد.
// این گیت مستقیم فقط محدوده Balance + Range را هدف می‌گیرد؛ Transition برای حفظ فرصت‌های معتبر به‌تنهایی مسدود نمی‌شود.
//====================================================================
bool V594_DirectOpportunityPassesLateStretch(
   const ENUM_SCENARIO_DIRECTION direction,
   const MarketRegimeState &regime,
   const MarketStructureSnapshot &structure,
   const MarketTruthSnapshot &truth,
   string &reason)
{
   reason = "";

   if(!Inp_Direct_Opportunity_Late_Stretch_Guard_Enabled)
      return true;

   if(!regime.valid ||
      !structure.valid ||
      !truth.valid)
      return true;

   const bool balanced_context =
      (structure.state == STRUCTURE_STATE_BALANCED);
   const bool range_context =
      (regime.regime == MARKET_REGIME_RANGE);

   if(!balanced_context || !range_context)
      return true;

   const double live_stretch =
      MathMax(truth.move_atr_multiple,
              g_opportunity_capture.truth_move_atr);

   if(live_stretch < Inp_Direct_Opportunity_Late_Truth_ATR)
      return true;

   reason =
      (direction == SCENARIO_DIRECTION_BUY
       ? "BUY مستقیم به‌دلیل تعقیب حرکت کشیده در ساختار متعادل متوقف شد"
       : "SELL مستقیم به‌دلیل تعقیب حرکت کشیده در ساختار متعادل متوقف شد") +
      " | TruthMoveATR=" +
      DoubleToString(live_stretch,2) +
      " | حد=" +
      DoubleToString(Inp_Direct_Opportunity_Late_Truth_ATR,2);

   Print("[V5.116 DIRECT LATE STRETCH BLOCK] ",reason);
   return false;
}

//====================================================================
// V5.116: تأیید کندل بسته‌شده M5 پیش از ورود مستقیم
// اگر آخرین کندل بسته‌شده با جهت Opportunity مخالف باشد، ورود مستقیم
// تا زمان شکل‌گیری Trigger تأییدشده روی کندل بسته‌شده متوقف می‌شود.
// شکست داخل کندل جاری به‌تنهایی Trigger کافی نیست.
//====================================================================
bool V594_DirectOpportunityPassesClosedM5Confirmation(
   const ENUM_SCENARIO_DIRECTION direction,
   const double atr_price,
   string &reason)
{
   reason = "";

   if(!Inp_Direct_Opportunity_Closed_M5_Confirm_Enabled)
      return true;

   if(atr_price <= 0.0)
      return true;

   const double closed_open   = iOpen(_Symbol,Inp_TF_Setup_M5,1);
   const double closed_close  = iClose(_Symbol,Inp_TF_Setup_M5,1);
   const double previous_high = iHigh(_Symbol,Inp_TF_Setup_M5,2);
   const double previous_low  = iLow(_Symbol,Inp_TF_Setup_M5,2);

   if(closed_open <= 0.0 || closed_close <= 0.0 ||
      previous_high <= 0.0 || previous_low <= 0.0)
      return true;

   const bool closed_buy  = (closed_close > closed_open);
   const bool closed_sell = (closed_close < closed_open);
   const double body = MathAbs(closed_close - closed_open);
   const double breakout_buffer = MathMax(_Point * 2.0, atr_price * 0.03);
   const double min_body = MathMax(_Point * 2.0, atr_price * 0.10);

   bool confirmed = false;

   if(direction == SCENARIO_DIRECTION_BUY)
   {
      confirmed = closed_buy && body >= min_body;

      // Trigger معتبر فقط با شکست روی کندل بسته‌شده پذیرفته می‌شود.
      if(!confirmed)
      {
         confirmed =
            closed_close > (previous_high + breakout_buffer) &&
            body >= min_body;
      }
   }
   else
   if(direction == SCENARIO_DIRECTION_SELL)
   {
      confirmed = closed_sell && body >= min_body;

      if(!confirmed)
      {
         confirmed =
            closed_close < (previous_low - breakout_buffer) &&
            body >= min_body;
      }
   }
   else
   {
      reason = "جهت Opportunity برای تأیید M5 مشخص نیست";
      return false;
   }

   if(confirmed)
      return true;

   reason =
      (direction == SCENARIO_DIRECTION_BUY
       ? "ورود مستقیم BUY به‌دلیل نبود تأیید کندل بسته‌شده M5 متوقف شد"
       : "ورود مستقیم SELL به‌دلیل نبود تأیید کندل بسته‌شده M5 متوقف شد") +
      " | ClosedOpen=" + DoubleToString(closed_open,_Digits) +
      " | ClosedClose=" + DoubleToString(closed_close,_Digits) +
      " | Body=" + DoubleToString(body,_Digits) +
      " | نیاز=بدنه هم‌جهت یا شکست تأییدشده روی کندل بسته‌شده";

   Print("[V5.116 CLOSED M5 BLOCK] ",reason);
   return false;
}

//====================================================================
// V5.116: تأیید Trigger زنده برای Opportunity مستقیم
//
// اصل: تأیید کندل بسته‌شده تنها مسیر ورود نیست. وقتی بازار در لحظه
// واکنش + فشار هم‌جهت + ساختار معتبر دارد، Opportunity باید بتواند
// بدون صبر اجباری برای بسته‌شدن کندل وارد شود.
//
// در ساختار متعادل، آستانه Trigger عمداً سخت‌تر است تا نمونه‌هایی مثل
// BUY 2026.09.22 04:25 با بدنه بسیار ضعیف وارد معامله نشوند.
//====================================================================
//====================================================================
// V5.116: پل مستقل Opportunity تا Execution؛ زمان‌بندی ورود پیش از آن کنترل می‌شود
// Opportunity قویِ ثبت‌شده نباید فقط به‌خاطر نبود Trigger عمومی تکراری
// یا کندل‌تأیید عمومی از مسیر اجرای واقعی حذف شود.
//====================================================================
//====================================================================
// V5.116: گیت زمان‌بندی ورود Opportunity مستقیم
// اصل: Opportunity معتبر است، اما «سناریو معتبر» به معنی «ورود همین تیک» نیست.
// این گیت فقط زمان اجرای Market را کنترل می‌کند و خود Opportunity را حذف نمی‌کند.
// مسیر Pending/Opportunity Audit و فرصت‌یابی بدون تغییر باقی می‌ماند.
//====================================================================
bool V597_DirectOpportunityPassesEntryTiming(
   const ENUM_SCENARIO_DIRECTION direction,
   const double current_price,
   const double atr_price,
   const MarketReadingSnapshot &live_reading,
   const MarketStructureSnapshot &live_structure,
   const ImpulseCorrectionSnapshot &live_move,
   const MarketTruthSnapshot &live_truth,
   const MarketRegimeState &live_regime,
   string &reason)
{
   reason = "";

   if(!Inp_Opportunity_Timing_Gate_Enabled)
      return true;

   if(current_price <= 0.0 || atr_price <= 0.0 ||
      !live_reading.valid || !live_structure.valid ||
      !live_move.valid || !live_truth.valid || !live_regime.valid)
   {
      reason = "داده کافی برای سنجش زمان ورود Opportunity وجود ندارد";
      return false;
   }

   const bool is_buy = (direction == SCENARIO_DIRECTION_BUY);
   if(!is_buy && direction != SCENARIO_DIRECTION_SELL)
   {
      reason = "جهت Opportunity برای گیت زمان‌بندی معتبر نیست";
      return false;
   }

   // فشار باید در لحظه اجرا هم‌جهت باشد؛ فشار قدیمی Capture به‌تنهایی کافی نیست.
   const bool pressure_ok =
      (is_buy
       ? (live_reading.current_up_pressure && !live_reading.current_down_pressure)
       : (live_reading.current_down_pressure && !live_reading.current_up_pressure));

   if(!pressure_ok)
   {
      reason =
         (is_buy
          ? "زمان ورود BUY مناسب نیست؛ فشار لحظه‌ای صعودی تأیید نشده است"
          : "زمان ورود SELL مناسب نیست؛ فشار لحظه‌ای نزولی تأیید نشده است");
      return false;
   }

   const int desired_dir = (is_buy ? 1 : -1);
   const double body_atr =
      MathAbs(live_reading.current_price - live_reading.candle_open) /
      MathMax(atr_price,_Point * 10.0);

   const double breakout_buffer =
      MathMax(_Point * 2.0,atr_price * 0.02);

   const double previous_high = iHigh(_Symbol,Inp_TF_Setup_M5,1);
   const double previous_low  = iLow(_Symbol,Inp_TF_Setup_M5,1);

   const bool micro_breakout =
      (is_buy
       ? (previous_high > 0.0 && current_price > previous_high + breakout_buffer)
       : (previous_low > 0.0 && current_price < previous_low - breakout_buffer));

   const bool structural_breakout =
      (is_buy
       ? (live_structure.structural_high > 0.0 &&
          current_price > live_structure.structural_high + breakout_buffer)
       : (live_structure.structural_low > 0.0 &&
          current_price < live_structure.structural_low - breakout_buffer));

   const bool recovered_pullback =
      live_move.correction_valid &&
      live_move.correction_direction == -desired_dir &&
      live_move.impulse_valid &&
      live_move.impulse_direction == desired_dir;

   const bool directional_structure =
      (is_buy
       ? (live_structure.state == STRUCTURE_STATE_BULLISH || live_structure.bullish_sequence)
       : (live_structure.state == STRUCTURE_STATE_BEARISH || live_structure.bearish_sequence));

   const bool fresh_trigger =
      recovered_pullback ||
      (structural_breakout && pressure_ok) ||
      (micro_breakout && pressure_ok &&
       body_atr >= MathMax(0.04,Inp_Opportunity_Timing_Min_Body_ATR));

   // «نامشخص» دیگر مجوز Market مستقیم نیست؛ Opportunity همچنان در Audit باقی می‌ماند
   // تا با شکل‌گیری جهت معتبر دوباره ارزیابی شود.
   if(live_regime.regime == MARKET_REGIME_UNCERTAIN)
   {
      reason =
         "Opportunity ثبت شده، اما زمان ورود اکنون در رژیم نامشخص معتبر نیست" +
         " | RegimeConfidence=" + DoubleToString(live_regime.confidence,1);
      Print("[V5.116 TIMING BLOCK] ",reason);
      return false;
   }

   // Transition با اطمینان پایین فقط وقتی وارد می‌شود که Truth بسیار قوی باشد
   // و Trigger تازه/واقعی هم وجود داشته باشد؛ این بخش جلوی نمونه‌هایی مثل O2/O15/O40 را می‌گیرد.
   if(live_regime.regime == MARKET_REGIME_TRANSITION)
   {
      const bool strong_transition =
         live_regime.confidence >= Inp_Opportunity_Timing_Transition_Min_Regime_Confidence &&
         g_opportunity_capture.quality >= Inp_Opportunity_Timing_Transition_Min_Quality &&
         live_truth.strong_market_move &&
         live_truth.continuation_ready &&
         live_truth.move_atr_multiple >=
            MathMax(3.75,Inp_Opportunity_Timing_Transition_Min_Truth_ATR) &&
         live_move.impulse_valid &&
         live_move.impulse_direction == desired_dir &&
         fresh_trigger;

      if(!strong_transition)
      {
         reason =
            "زمان ورود در Transition تأیید کافی ندارد" +
            " | Confidence=" + DoubleToString(live_regime.confidence,1) +
            " | Quality=" + DoubleToString(g_opportunity_capture.quality,1) +
            " | TruthATR=" + DoubleToString(live_truth.move_atr_multiple,2) +
            " | FreshTrigger=" + (fresh_trigger ? "YES" : "NO");
         Print("[V5.116 TIMING BLOCK] ",reason);
         return false;
      }
   }

   // مرجع زمان‌بندی: ابتدا Reaction Anchor، و در نبود آن نقطه ثبت Opportunity.
   const double timing_anchor =
      (g_opportunity_capture.reaction_anchor > 0.0
       ? g_opportunity_capture.reaction_anchor
       : g_opportunity_capture.current_price);

   const double timing_width =
      MathMax(
         atr_price * MathMax(0.10,Inp_Opportunity_Timing_Window_ATR),
         g_opportunity_capture.reaction_zone_width > 0.0
         ? g_opportunity_capture.reaction_zone_width
         : atr_price * 0.50);

   const double anchor_distance_atr =
      (timing_anchor > 0.0
       ? MathAbs(current_price - timing_anchor) / atr_price
       : 0.0);

   const double capture_distance_atr =
      (g_opportunity_capture.current_price > 0.0
       ? MathAbs(current_price - g_opportunity_capture.current_price) / atr_price
       : 0.0);

   const bool in_reaction_window =
      timing_anchor > 0.0 &&
      MathAbs(current_price - timing_anchor) <= timing_width;

   // ورود جبرانی فقط وقتی مجاز است که Pullback/Break تازه شکل گرفته باشد؛
   // حرکت مطلوبِ صرف دیگر بهانه‌ای برای تعقیب قیمت نیست.
   if(capture_distance_atr >
         MathMax(0.75,Inp_Opportunity_Timing_Max_Drift_ATR) &&
      !fresh_trigger)
   {
      reason =
         "Opportunity معتبر است، اما قیمت از مرجع خود بیش از حد جلو رفته و Trigger تازه ندارد" +
         " | CaptureDriftATR=" + DoubleToString(capture_distance_atr,2) +
         " | Max=" + DoubleToString(Inp_Opportunity_Timing_Max_Drift_ATR,2);
      Print("[V5.116 TIMING BLOCK] ",reason);
      return false;
   }

   // ساختار متعادل حساس‌ترین حالت برای Timing است: یا باید در محدوده واکنش باشیم
   // و بازگشت Pullback دیده شود، یا Breakout ساختاری واقعی شکل گرفته باشد.
   if(live_structure.state == STRUCTURE_STATE_BALANCED)
   {
      const bool balanced_reentry =
         in_reaction_window &&
         recovered_pullback &&
         body_atr >= MathMax(0.01,Inp_Opportunity_Timing_Min_Body_ATR);

      const bool balanced_break =
         structural_breakout &&
         pressure_ok &&
         body_atr >= MathMax(0.01,Inp_Opportunity_Timing_Min_Body_ATR);

      if(!balanced_reentry && !balanced_break)
      {
         reason =
            (is_buy
             ? "BUY Opportunity در ساختار متعادل، زمان ورود معتبر ندارد"
             : "SELL Opportunity در ساختار متعادل، زمان ورود معتبر ندارد") +
            " | InReaction=" + (in_reaction_window ? "YES" : "NO") +
            " | PullbackRecovery=" + (recovered_pullback ? "YES" : "NO") +
            " | StructuralBreak=" + (structural_breakout ? "YES" : "NO") +
            " | BodyATR=" + DoubleToString(body_atr,2);
         Print("[V5.116 TIMING BLOCK] ",reason);
         return false;
      }
   }
   else
   {
      // در ساختار جهت‌دار، ورود می‌تواند کمی از Anchor فاصله گرفته باشد،
      // اما بدون Pullback یا Break تازه نباید به دنبال حرکت دوید.
      if(anchor_distance_atr >
            MathMax(1.00,Inp_Opportunity_Timing_Max_Drift_ATR) &&
         !recovered_pullback &&
         !structural_breakout)
      {
         reason =
            "ورود مستقیم در ساختار جهت‌دار دیر شده و Trigger تازه ندارد" +
            " | AnchorDistanceATR=" + DoubleToString(anchor_distance_atr,2);
         Print("[V5.116 TIMING BLOCK] ",reason);
         return false;
      }

      if(!fresh_trigger && !in_reaction_window &&
         body_atr < MathMax(0.01,Inp_Opportunity_Timing_Min_Body_ATR))
      {
         reason =
            "Entry NOW تأیید نشد؛ Opportunity معتبر است اما Trigger زمانی کافی ندارد" +
            " | BodyATR=" + DoubleToString(body_atr,2) +
            " | InReaction=" + (in_reaction_window ? "YES" : "NO");
         Print("[V5.116 TIMING BLOCK] ",reason);
         return false;
      }
   }

   Print(
      "[V5.116 TIMING PASS] Entry NOW تأیید شد",
      " | Direction=",is_buy ? "BUY" : "SELL",
      " | AnchorDistanceATR=",DoubleToString(anchor_distance_atr,2),
      " | CaptureDriftATR=",DoubleToString(capture_distance_atr,2),
      " | InReaction=",in_reaction_window ? "YES" : "NO",
      " | PullbackRecovery=",recovered_pullback ? "YES" : "NO",
      " | StructuralBreak=",structural_breakout ? "YES" : "NO",
      " | BodyATR=",DoubleToString(body_atr,2));

   return true;
}

bool V596_PriorityOpportunityExecutionBridge(
   const ENUM_SCENARIO_DIRECTION direction,
   const double current_price,
   const double atr_price,
   const MarketReadingSnapshot &live_reading,
   const MarketStructureSnapshot &live_structure,
   const ImpulseCorrectionSnapshot &live_move,
   const MarketTruthSnapshot &live_truth,
   string &reason)
{
   reason = "";

   if(!Inp_Opportunity_Direct_Market_Enabled ||
      !Inp_Opportunity_CatchUp_Market_Enabled)
      return false;

   if(!g_opportunity_capture.valid ||
      !g_opportunity_capture.priority ||
      g_opportunity_capture.quality < Inp_Opportunity_CatchUp_Min_Quality ||
      current_price <= 0.0 || atr_price <= 0.0 ||
      !live_reading.valid || !live_structure.valid ||
      !live_move.valid || !live_truth.valid)
      return false;

   const bool is_buy = (direction == SCENARIO_DIRECTION_BUY);
   if(!is_buy && direction != SCENARIO_DIRECTION_SELL)
      return false;

   const ENUM_MARKET_TRUTH_DIRECTION expected_truth =
      (is_buy ? MARKET_TRUTH_BUY : MARKET_TRUTH_SELL);

   if(live_truth.direction != expected_truth)
      return false;

   if(live_truth.phase == MARKET_TRUTH_PHASE_REVERSAL ||
      (live_truth.strong_market_move && !live_truth.continuation_ready &&
       live_truth.move_atr_multiple >= 2.50))
      return false;

   const double reference =
      g_opportunity_capture.current_price > 0.0
      ? g_opportunity_capture.current_price
      : current_price;

   const bool favorable_move =
      (is_buy ? current_price >= reference : current_price <= reference);

   const double distance_atr =
      MathAbs(current_price - reference) / atr_price;

   if(!favorable_move ||
      distance_atr > MathMax(1.75,Inp_Opportunity_CatchUp_Max_Distance_ATR))
      return false;

   const int desired_dir = (is_buy ? 1 : -1);
   if(!live_move.impulse_valid ||
      live_move.impulse_direction != desired_dir)
   {
      if(!(live_move.correction_valid &&
           live_move.correction_direction == -desired_dir))
         return false;
   }

   const bool transition_structure =
      (live_structure.state == STRUCTURE_STATE_TRANSITION);

   if(transition_structure)
   {
      if(live_truth.move_atr_multiple <
         MathMax(3.75,Inp_Opportunity_Transition_Min_Truth_ATR))
         return false;

      if(!live_move.impulse_valid ||
         live_move.impulse_direction != desired_dir)
         return false;
   }

   const double live_body_atr =
      MathAbs(live_reading.current_price - live_reading.candle_open) /
      MathMax(atr_price,_Point * 10.0);

   const bool pressure_ok =
      (is_buy
       ? (live_reading.current_up_pressure && !live_reading.current_down_pressure)
       : (live_reading.current_down_pressure && !live_reading.current_up_pressure));

   const double breakout_buffer =
      MathMax(_Point * 2.0,atr_price * 0.02);

   const double previous_high = iHigh(_Symbol,Inp_TF_Setup_M5,1);
   const double previous_low  = iLow(_Symbol,Inp_TF_Setup_M5,1);

   const bool micro_breakout =
      (is_buy
       ? (previous_high > 0.0 && current_price > previous_high + breakout_buffer)
       : (previous_low > 0.0 && current_price < previous_low - breakout_buffer));

   const bool structural_breakout =
      (is_buy
       ? (live_structure.structural_high > 0.0 &&
          current_price > live_structure.structural_high + breakout_buffer)
       : (live_structure.structural_low > 0.0 &&
          current_price < live_structure.structural_low - breakout_buffer));

   const bool recovered_pullback =
      live_move.correction_valid &&
      live_move.correction_direction == -desired_dir &&
      live_move.impulse_valid &&
      live_move.impulse_direction == desired_dir;

   const bool directional_structure =
      (is_buy
       ? (live_structure.state == STRUCTURE_STATE_BULLISH || live_structure.bullish_sequence)
       : (live_structure.state == STRUCTURE_STATE_BEARISH || live_structure.bearish_sequence));

   const bool fresh_trigger =
      (pressure_ok && (micro_breakout || structural_breakout || recovered_pullback)) ||
      (directional_structure && live_body_atr >=
         MathMax(0.04,Inp_Direct_Opportunity_Directional_Min_Trigger_Body_ATR * 0.80));

   if(!fresh_trigger ||
      live_truth.move_atr_multiple < MathMax(2.00,Inp_Opportunity_Min_Truth_ATR))
      return false;

   reason =
      "Opportunity Bridge فعال شد" +
      " | Quality=" + DoubleToString(g_opportunity_capture.quality,1) +
      " | TruthMoveATR=" + DoubleToString(live_truth.move_atr_multiple,2) +
      " | DistanceATR=" + DoubleToString(distance_atr,2) +
      " | Pressure=" + (pressure_ok ? "YES" : "NO") +
      " | Transition=" + (transition_structure ? "YES" : "NO");

   Print("[V5.116 OPPORTUNITY BRIDGE] ",reason);
   return true;
}

bool V594_DirectOpportunityPassesLiveEntryTrigger(
   const ENUM_SCENARIO_DIRECTION direction,
   const double current_price,
   const double atr_price,
   const MarketReadingSnapshot &live_reading,
   const MarketStructureSnapshot &live_structure,
   const ImpulseCorrectionSnapshot &live_move,
   const MarketTruthSnapshot &live_truth,
   string &reason)
{
   reason = "";

   if(!Inp_Direct_Opportunity_Live_Trigger_Enabled)
      return false;

   if(current_price <= 0.0 ||
      atr_price <= 0.0 ||
      !live_reading.valid ||
      !live_structure.valid)
   {
      reason = "Trigger زنده برای Opportunity قابل ارزیابی نیست";
      return false;
   }

   const bool is_buy = (direction == SCENARIO_DIRECTION_BUY);
   if(!is_buy && direction != SCENARIO_DIRECTION_SELL)
   {
      reason = "جهت Opportunity نامعتبر است";
      return false;
   }

   const bool pressure_ok =
      (is_buy
       ? (live_reading.current_up_pressure && !live_reading.current_down_pressure)
       : (live_reading.current_down_pressure && !live_reading.current_up_pressure));

   const double body_atr =
      MathAbs(live_reading.current_price - live_reading.candle_open) /
      MathMax(atr_price,_Point * 10.0);

   const double breakout_buffer =
      MathMax(_Point * 2.0, atr_price * 0.02);

   const double previous_high =
      iHigh(_Symbol,Inp_TF_Setup_M5,1);
   const double previous_low =
      iLow(_Symbol,Inp_TF_Setup_M5,1);

   const bool micro_breakout =
      (is_buy
       ? (previous_high > 0.0 && current_price > previous_high + breakout_buffer)
       : (previous_low > 0.0 && current_price < previous_low - breakout_buffer));

   // شکست ساختاری، برخلاف شکست صرفاً یک کندل قبلی، تأیید واقعی‌تری برای
   // ورود در ساختار متعادل است.
   const bool structural_breakout =
      (is_buy
       ? (live_structure.structural_high > 0.0 &&
          current_price > live_structure.structural_high + breakout_buffer)
       : (live_structure.structural_low > 0.0 &&
          current_price < live_structure.structural_low - breakout_buffer));

   //--- اصلاح معتبر در جهت خلاف حرکت اصلی، سپس بازگشت فشار به جهت Opportunity.
   const int desired_dir = (is_buy ? 1 : -1);
   const bool recovered_pullback =
      live_move.valid &&
      live_move.impulse_valid &&
      live_move.impulse_direction == desired_dir &&
      live_move.correction_valid &&
      live_move.correction_direction == -desired_dir;

   const bool directional_structure =
      (is_buy
       ? (live_structure.state == STRUCTURE_STATE_BULLISH ||
          live_structure.bullish_sequence)
       : (live_structure.state == STRUCTURE_STATE_BEARISH ||
          live_structure.bearish_sequence));

   // V5.116: در ساختار در حال تغییر، تنها ادامه‌حرکت بسیار قوی اجازه Catch-up دارد.
   // این مسیر برای فرصت‌های واضحی مثل 08:05 و 15:30 طراحی شده و با آستانه Truth
   // بالاتر از مسیر عادی، کیفیت کافی و هم‌جهتی Impulse محافظت می‌شود.
   const bool transition_structure =
      (live_structure.state == STRUCTURE_STATE_TRANSITION);

   const bool strong_transition_catchup =
      transition_structure &&
      live_structure.valid &&
      live_move.valid &&
      live_move.impulse_valid &&
      live_move.impulse_direction == desired_dir &&
      live_truth.valid &&
      live_truth.strong_market_move &&
      live_truth.continuation_ready &&
      live_truth.move_atr_multiple >=
         MathMax(3.50,Inp_Opportunity_Transition_Min_Truth_ATR) &&
      g_opportunity_capture.quality >= 85.0 &&
      (!pressure_ok ?
         body_atr <= MathMax(0.20,
            Inp_Direct_Opportunity_Directional_Min_Trigger_Body_ATR * 4.0)
         : true);

   // V5.95: Recovery محدود برای Transitionهای واقعاً قوی. O49 با Truth~3.23
   // به این مسیر وارد نمی‌شود؛ در عوض Opportunityهای قوی‌تر می‌توانند
   // بدون انتظار برای فشار دوگانه همان تیک، Catch-up شوند.
   const bool transition_capture_recovery =
      transition_structure &&
      live_structure.valid &&
      live_move.valid &&
      live_move.impulse_valid &&
      live_move.impulse_direction == desired_dir &&
      live_truth.valid &&
      live_truth.strong_market_move &&
      live_truth.continuation_ready &&
      live_truth.move_atr_multiple >=
         MathMax(3.75,Inp_Opportunity_Transition_Min_Truth_ATR) &&
      g_opportunity_capture.quality >= 85.0 &&
      (recovered_pullback ||
       micro_breakout ||
       structural_breakout ||
       pressure_ok ||
       body_atr >= MathMax(0.04,
          Inp_Direct_Opportunity_Directional_Min_Trigger_Body_ATR * 0.80));

   const bool balanced_structure =
      (live_structure.state == STRUCTURE_STATE_BALANCED);

   //--- ساختار متعادل: میکرو-شکست یک کندل به‌تنهایی Trigger نیست.
   if(balanced_structure)
   {
      if(structural_breakout && pressure_ok)
         return true;

      if(body_atr < MathMax(0.01,Inp_Direct_Opportunity_Balanced_Min_Trigger_Body_ATR))
      {
         reason =
            (is_buy
             ? "BUY مستقیم در ساختار متعادل به‌دلیل Trigger زنده ضعیف متوقف شد"
             : "SELL مستقیم در ساختار متعادل به‌دلیل Trigger زنده ضعیف متوقف شد") +
            " | BodyATR=" + DoubleToString(body_atr,2) +
            " | نیاز=" + DoubleToString(Inp_Direct_Opportunity_Balanced_Min_Trigger_Body_ATR,2) +
            "ATR";
         return false;
      }

      if(!recovered_pullback)
      {
         reason =
            (is_buy
             ? "BUY مستقیم در ساختار متعادل بدون Pullback معتبر یا شکست ساختاری تأییدکننده متوقف شد"
             : "SELL مستقیم در ساختار متعادل بدون Pullback معتبر یا شکست ساختاری تأییدکننده متوقف شد");
         return false;
      }

      if(!pressure_ok)
      {
         reason =
            (is_buy
             ? "BUY مستقیم در ساختار متعادل هنوز فشار به سمت خرید برنگشته است"
             : "SELL مستقیم در ساختار متعادل هنوز فشار به سمت فروش برنگشته است");
         return false;
      }

      return true;
   }

   //--- ساختار جهت‌دار: ادامه‌حرکت قوی می‌تواند حتی روی یک کندل اصلاحی کوچک
   // بدون فشار معکوسِ قوی وارد شود، به شرط آنکه Truth و Impulse هم‌جهت باشند.
   const bool strong_directional_continuation =
      directional_structure &&
      live_move.valid &&
      live_move.impulse_valid &&
      live_move.impulse_direction == desired_dir &&
      live_truth.valid &&
      live_truth.move_atr_multiple >=
         MathMax(2.50,Inp_Direct_Opportunity_MTF_Truth_Min_ATR) &&
      (!pressure_ok ?
         body_atr <= MathMax(0.20,
            Inp_Direct_Opportunity_Directional_Min_Trigger_Body_ATR * 4.0)
         : true);

   if((pressure_ok &&
       (micro_breakout || structural_breakout)) ||
      strong_directional_continuation ||
      strong_transition_catchup ||
      transition_capture_recovery)
      return true;

   if(pressure_ok &&
      body_atr >= MathMax(0.01,Inp_Direct_Opportunity_Directional_Min_Trigger_Body_ATR) &&
      (directional_structure || recovered_pullback))
      return true;

   reason =
      (is_buy
       ? "BUY مستقیم بدون Trigger زنده کافی متوقف شد"
       : "SELL مستقیم بدون Trigger زنده کافی متوقف شد") +
      " | BodyATR=" + DoubleToString(body_atr,2) +
      " | نیاز=" + DoubleToString(Inp_Direct_Opportunity_Directional_Min_Trigger_Body_ATR,2) +
      "ATR";

   return false;
}

//====================================================================
// اجرای مستقل فرصت اولویت‌دار
//
// V5.116: Opportunity دیگر منتظر ساخته‌شدن یا معتبر ماندن Scenario و
// EntryPlan عمومی نمی‌ماند. پس از تأیید مجدد لحظه‌ای Truth + Structure
// + Pressure + Reaction، مستقیماً یک برنامه Market ساخته می‌شود.
// مسیرهای Risk / Spread / MarketOpen / OppositePosition / Revalidation
// و Broker Execution همچنان اجباری باقی می‌مانند.
//====================================================================
bool PrepareDirectPriorityOpportunityMarketEntry(
   const double current_price,
   const datetime current_time,
   string &reason)
{
   reason = "";

   if(!Inp_Opportunity_Direct_Market_Enabled)
      return false;

   if(!g_opportunity_capture.valid ||
      !g_opportunity_capture.priority)
   {
      reason = "فرصت اولویت‌دار معتبر وجود ندارد";
      return false;
   }

   if(g_opportunity_capture.quality <
      Inp_Opportunity_CatchUp_Min_Quality)
   {
      reason = "کیفیت فرصت زیر حد مجاز است";
      return false;
   }

   if(g_opportunity_capture.direction != SCENARIO_DIRECTION_BUY &&
      g_opportunity_capture.direction != SCENARIO_DIRECTION_SELL)
   {
      reason = "جهت فرصت مشخص نیست";
      return false;
   }

   // فشار لحظه ثبت Opportunity ممکن است چند دقیقه بعد با یک کندل اصلاحی
   // خلاف جهت موقت شود؛ در این حالت تصمیم نهایی باید بر اساس Trigger زنده
   // و ساختار/حرکت جاری گرفته شود، نه فلگ فشار قدیمی Capture.
   if(!g_opportunity_capture.reaction_confirmed)
   {
      reason = "واکنش فرصت اولویت‌دار در داده Capture تأیید نشده است";
      return false;
   }

   if(current_price <= 0.0)
   {
      reason = "قیمت جاری معتبر نیست";
      return false;
   }

   //--- تمام مؤلفه‌های کلیدی در لحظه ورود دوباره خوانده می‌شوند.
   MarketTruthSnapshot live_truth;
   MarketTruth_Reset(live_truth);
   if(!MarketTruth_Analyze(
      _Symbol,
      Inp_TF_Setup_M5,
      Inp_Market_Truth_Lookback,
      live_truth) || !live_truth.valid)
   {
      reason = "Truth زنده پیش از اجرای فرصت قابل تأیید نبود";
      return false;
   }

   MarketStructureSnapshot live_structure;
   MarketStructure_Reset(live_structure);
   if(!MarketStructure_Analyze(
      _Symbol,
      Inp_TF_Structure_M15,
      120,
      2,
      2,
      20.0,
      live_structure) || !live_structure.valid)
   {
      reason = "Structure زنده پیش از اجرای فرصت قابل تأیید نبود";
      return false;
   }

   MarketReadingSnapshot live_reading;
   MarketReading_Reset(live_reading);
   if(!MarketReading_Analyze(
      _Symbol,
      Inp_TF_Setup_M5,
      live_truth,
      live_structure,
      live_reading) || !live_reading.valid)
   {
      reason = "خوانش زنده M5 پیش از اجرای فرصت قابل تأیید نبود";
      return false;
   }

   //--- State جاری با همان داده‌ای که مبنای تصمیم مستقیم بوده هم‌تراز می‌شود.
   g_market_truth = live_truth;
   g_structure = live_structure;
   g_market_reading = live_reading;

   //===============================================================
   // V5.116: گیت نهایی جهت زنده
   // Opportunity نمی‌تواند با یک Truth مخالف، روند زنده صریح بازار را override کند.
   // این گیت فقط تضاد روشن را می‌بندد تا Capture فرصت‌های معتبر کم نشود.
   //===============================================================
   MarketRegimeState live_regime;
   MarketRegime_Reset(live_regime);
   if(!MarketRegime_Analyze(
      _Symbol,
      Inp_TF_Context_M30,
      Inp_ADX_Period,
      Inp_RSI_Period,
      Inp_EMA_Trend_Period,
      Inp_ATR_Period,
      Inp_ADX_Min_Trend,
      Inp_ADX_Exhaustion_Level,
      Inp_RSI_Overbought,
      Inp_RSI_Oversold,
      Inp_Max_Price_EMA_ATR_Distance,
      live_regime) ||
      !live_regime.valid)
   {
      reason = "Regime زنده پیش از اجرای Opportunity قابل تأیید نبود";
      return false;
   }

   g_regime = live_regime;

   const ENUM_SCENARIO_DIRECTION direction =
      g_opportunity_capture.direction;

   string mtf_truth_reason = "";
   if(!V594_DirectOpportunityPassesMultiTFTruth(
         direction,
         mtf_truth_reason))
   {
      reason = mtf_truth_reason;
      return false;
   }

   if(live_regime.confidence >= Inp_Min_Regime_Confidence)
   {
      if(direction == SCENARIO_DIRECTION_BUY &&
         live_regime.regime == MARKET_REGIME_DOWNTREND)
      {
         reason =
            "BUY مستقیم به‌دلیل روند زنده نزولی متوقف شد" +
            " | Confidence=" + DoubleToString(live_regime.confidence,1);
         Print("[V5.116 LIVE DIRECTION BLOCK] BUY | Regime=روند نزولی | Confidence=",
               DoubleToString(live_regime.confidence,1));
         return false;
      }

      if(direction == SCENARIO_DIRECTION_SELL &&
         live_regime.regime == MARKET_REGIME_UPTREND)
      {
         reason =
            "SELL مستقیم به‌دلیل روند زنده صعودی متوقف شد" +
            " | Confidence=" + DoubleToString(live_regime.confidence,1);
         Print("[V5.116 LIVE DIRECTION BLOCK] SELL | Regime=روند صعودی | Confidence=",
               DoubleToString(live_regime.confidence,1));
         return false;
      }
   }

   // جهت زنده M5 دیگر به‌تنهایی معیار نهایی نیست. در ادامه‌حرکت معتبر،
   // یک کندل اصلاحی کوچک خلاف جهت می‌تواند وجود داشته باشد؛ این حالت
   // توسط Trigger زنده بعد از تحلیل Impulse/Correction کنترل می‌شود.
   const double neutral_epsilon = MathMax(_Point, _Point * 0.5);
   const double live_delta = live_reading.current_price - live_reading.candle_open;
   if(MathAbs(live_delta) <= neutral_epsilon)
   {
      reason = "جهت زنده M5 خنثی است";
      return false;
   }

   if(live_truth.direction !=
      (direction == SCENARIO_DIRECTION_BUY
       ? MARKET_TRUTH_BUY
       : MARKET_TRUTH_SELL))
   {
      reason = "جهت Market Truth زنده با فرصت هم‌جهت نیست";
      return false;
   }

   if(!live_truth.strong_market_move ||
      !live_truth.continuation_ready ||
      (live_truth.phase != MARKET_TRUTH_PHASE_EXPANSION &&
       live_truth.phase != MARKET_TRUTH_PHASE_PULLBACK))
   {
      reason = "حرکت زنده Truth دیگر در وضعیت معتبر ادامه حرکت نیست";
      return false;
   }

   // V5.116: ساختار Transition زودتر از Trigger رد نمی‌شود؛
   // گیت Trigger پایین‌تر فقط Transition واقعاً قوی را عبور می‌دهد.
   if(direction == SCENARIO_DIRECTION_BUY)
   {
      if(live_structure.state != STRUCTURE_STATE_BULLISH &&
         live_structure.state != STRUCTURE_STATE_BALANCED &&
         live_structure.state != STRUCTURE_STATE_TRANSITION)
      {
         reason = "ساختار زنده برای BUY مناسب نیست";
         return false;
      }
   }
   else
   {
      if(live_structure.state != STRUCTURE_STATE_BEARISH &&
         live_structure.state != STRUCTURE_STATE_BALANCED &&
         live_structure.state != STRUCTURE_STATE_TRANSITION)
      {
         reason = "ساختار زنده برای SELL مناسب نیست";
         return false;
      }
   }

   // این مسیر برای Capture همان لحظه است؛ فرصت قدیمی در چند کندل بعد دنبال نمی‌شود.
   if(g_opportunity_capture.current_price > 0.0)
   {
      double capture_atr = 0.0;
      if(live_truth.move_atr_multiple > 0.0 && live_truth.move_size > 0.0)
         capture_atr = live_truth.move_size / live_truth.move_atr_multiple;
      if(capture_atr <= 0.0)
         capture_atr = GetCurrentATRPrice();

      if(capture_atr > 0.0)
      {
         const double capture_distance_atr =
            MathAbs(current_price - g_opportunity_capture.current_price) / capture_atr;
         if(capture_distance_atr >
            MathMax(0.25, Inp_Opportunity_CatchUp_Max_Distance_ATR))
         {
            // V5.116: حرکت مطلوب به‌دلیل تأخیر ورود نباید با حد فاصله اولیه
            // یک فرصت صحیح را از بین ببرد. برای جلوگیری از تعقیب افراطی،
            // Catch-up مطلوب حداکثر تا 5 ATR مجاز است؛ حرکت نامطلوب همچنان
            // با حد فاصله قبلی متوقف می‌شود.
            const bool favorable_move =
               (direction == SCENARIO_DIRECTION_BUY
                ? current_price > g_opportunity_capture.current_price
                : current_price < g_opportunity_capture.current_price);

            const double favorable_cap_atr =
               MathMax(5.0,
                  MathMax(0.25,Inp_Opportunity_CatchUp_Max_Distance_ATR) * 3.0);

            if(!favorable_move || capture_distance_atr > favorable_cap_atr)
            {
               reason = favorable_move
                  ? "قیمت بیش از سقف Catch-up مطلوب از نقطه ثبت فرصت دور شده است"
                  : "قیمت از نقطه ثبت فرصت در جهت نامطلوب بیش از محدوده مجاز دور شده است";
               return false;
            }
         }
      }
   }

   //--- حرکت M5 فعلی باید با جهت فرصت سازگار باشد؛ Pullback مخالف همچنان مجاز است.
   ImpulseCorrectionSnapshot live_move;
   ImpulseCorrection_Reset(live_move);
   if(!ImpulseCorrection_Analyze(
      _Symbol,
      Inp_TF_Setup_M5,
      120,
      2,
      2,
      20.0,
      live_move) || !live_move.valid)
   {
      reason = "حرکت M5 زنده برای اجرای فرصت قابل تأیید نبود";
      return false;
   }

   const int desired_dir =
      (direction == SCENARIO_DIRECTION_BUY ? 1 : -1);

   if(live_move.impulse_valid &&
      live_move.impulse_direction != desired_dir &&
      !live_move.correction_valid)
   {
      reason = "حرکت مخالف جهت فرصت Pullback معتبر ندارد";
      return false;
   }

   if(live_move.impulse_valid &&
      live_move.impulse_direction != desired_dir &&
      live_move.correction_valid &&
      live_move.correction_direction != desired_dir)
   {
      reason = "Correction زنده با جهت Opportunity سازگار نیست";
      return false;
   }

   g_move = live_move;

   //===============================================================
   // V5.116: ورود مستقیم دیگر منتظر تأیید اجباری کندل بسته‌شده نیست.
   // Trigger زنده قوی می‌تواند جایگزین آن شود؛ در غیر این صورت
   // ساختارهای جهت‌دار هنوز از محافظ کندل بسته‌شده استفاده می‌کنند.
   // ساختار متعادل با Trigger ضعیف مستقیماً متوقف می‌شود.
   //===============================================================
   string live_trigger_reason = "";
   const bool live_trigger_ready =
      V594_DirectOpportunityPassesLiveEntryTrigger(
         direction,
         current_price,
         MathMax(GetCurrentATRPrice(), _Point * 10.0),
         live_reading,
         live_structure,
         live_move,
         live_truth,
         live_trigger_reason);

   const double bridge_atr_price = MathMax(GetCurrentATRPrice(), _Point * 10.0);

   // V5.116: قبل از فعال شدن Opportunity Bridge، زمان «Entry NOW» جداگانه تأیید می‌شود.
   string timing_reason = "";
   if(!V597_DirectOpportunityPassesEntryTiming(
         direction,
         current_price,
         bridge_atr_price,
         live_reading,
         live_structure,
         live_move,
         live_truth,
         live_regime,
         timing_reason))
   {
      reason = timing_reason;
      return false;
   }

   string bridge_reason = "";
   const bool opportunity_bridge_ready =
      V596_PriorityOpportunityExecutionBridge(
         direction,
         current_price,
         bridge_atr_price,
         live_reading,
         live_structure,
         live_move,
         live_truth,
         bridge_reason);

   if(Inp_Direct_Opportunity_Live_Trigger_Enabled &&
      !live_trigger_ready &&
      !opportunity_bridge_ready &&
      live_structure.state == STRUCTURE_STATE_BALANCED)
   {
      reason = live_trigger_reason;
      return false;
   }

   string late_stretch_reason = "";
   if(!V594_DirectOpportunityPassesLateStretch(
         direction,
         live_regime,
         live_structure,
         live_truth,
         late_stretch_reason))
   {
      reason = late_stretch_reason;
      return false;
   }

   // اگر Trigger زنده قوی نیست، محافظ کندل بسته‌شده همچنان به‌عنوان
   // لایه دوم حفاظت فعال می‌ماند. این لایه دیگر مانع Trigger زنده معتبر نیست.
   if(!live_trigger_ready && !opportunity_bridge_ready)
   {
      string closed_m5_reason = "";
      if(!V594_DirectOpportunityPassesClosedM5Confirmation(
            direction,
            MathMax(GetCurrentATRPrice(), _Point * 10.0),
            closed_m5_reason))
      {
         reason = closed_m5_reason;
         return false;
      }
   }

   // V5.116: BUY مستقیم در انتهای حرکت کشیده باید Trigger تازه داشته باشد.
   if(direction == SCENARIO_DIRECTION_BUY)
   {
      string buy_trigger_reason = "";
      if(!opportunity_bridge_ready &&
         !V594_DirectBuyHasFreshTrigger(
            current_price,
            MathMax(GetCurrentATRPrice(), _Point * 10.0),
            live_move,
            live_reading,
            live_structure,
            live_truth,
            buy_trigger_reason))
      {
         reason = buy_trigger_reason;
         return false;
      }
   }

   // اگر Scenario عمومی معتبر و هم‌جهت است، فقط از اطلاعات حفاظتی آن استفاده می‌کنیم.
   const bool have_matching_scenario =
      g_scenario.id > 0 &&
      Scenario_IsValid(g_scenario) &&
      g_scenario.direction == direction;

   if(!have_matching_scenario)
   {
      ZoneInfo opportunity_zone;
      Zone_Init(opportunity_zone);

      if(g_opportunity_capture.synthetic_zone_created)
      {
         double opportunity_atr = 0.0;
         if(live_truth.move_atr_multiple > 0.0 && live_truth.move_size > 0.0)
            opportunity_atr = live_truth.move_size / live_truth.move_atr_multiple;
         if(opportunity_atr <= 0.0)
            opportunity_atr = GetCurrentATRPrice();

         if(opportunity_atr <= 0.0 ||
            !OpportunityCapture_CreateSyntheticZone(
               g_opportunity_capture,
               live_move,
               opportunity_atr,
               opportunity_zone))
         {
            reason = "ساخت ناحیه واکنش مصنوعی فرصت ناموفق بود";
            return false;
         }
      }
      else
      {
         opportunity_zone =
            (direction == SCENARIO_DIRECTION_BUY
             ? g_buy_zone
             : g_sell_zone);

         if(!Zone_IsValid(opportunity_zone))
         {
            reason = "Zone ثبت‌شده فرصت در لحظه اجرا معتبر نیست";
            return false;
         }
      }

      Scenario_Init(g_scenario);
      g_scenario.id = g_scenario_next_id++;
      if(g_scenario.id == 0)
         g_scenario.id = g_scenario_next_id++;

      g_scenario.direction = direction;
      g_scenario.status = SCENARIO_STATUS_VALID;
      g_scenario.activation_type = SCENARIO_ACTIVATION_CUSTOM;
      g_scenario.symbol = _Symbol;
      g_scenario.market_regime = g_regime.regime;
      g_scenario.context_state = g_context.state;
      g_scenario.structure_state = live_structure.state;
      g_scenario.move_state = live_move.state;
      g_scenario.zone_id = opportunity_zone.id;
      g_scenario.zone_type = opportunity_zone.type;
      g_scenario.zone_lower = opportunity_zone.lower_price;
      g_scenario.zone_upper = opportunity_zone.upper_price;
      g_scenario.entry_price = current_price;
      g_scenario.invalidation_price = opportunity_zone.invalidation_price;
      g_scenario.created_time = current_time;
      g_scenario.created_m5_bar_time = iTime(_Symbol,Inp_TF_Setup_M5,1);
      g_scenario.updated_time = current_time;
      g_scenario.expiry_time = current_time + (Inp_Scenario_Max_Age_Minutes * 60);
      g_scenario.source_timeframe = (int)Inp_TF_Structure_M15;
      g_scenario.setup_timeframe = (int)Inp_TF_Setup_M5;
      g_scenario.structure_valid = live_structure.valid;
      g_scenario.impulse_valid = live_move.impulse_valid;
      g_scenario.correction_valid = live_move.correction_valid;
      g_scenario.zone_valid = Zone_IsValid(opportunity_zone);
      g_scenario.activation_ready = true;
      g_scenario.background_aligned = true;
      g_scenario.conflict_present = false;
      g_scenario.regime_aligned = true;
      g_scenario.alignment_value = g_opportunity_capture.quality;
      g_scenario.quality_value = g_opportunity_capture.quality;
      g_scenario.structure_reason = live_structure.reason;
      g_scenario.impulse_reason = live_move.reason;
      g_scenario.correction_reason =
         (live_move.correction_valid ? "اصلاح معتبر" : "بدون اصلاح مستقل");
      g_scenario.zone_reason = opportunity_zone.reason;
      g_scenario.activation_reason = "فرصت اولویت‌دار پس از تأیید مستقیم آماده اجرا شد";
      g_scenario.invalidation_reason = "ابطال بر اساس ناحیه واکنش و ساختار جاری";
      g_scenario.general_reason =
         "Opportunity First | واکنش + ساختار + جهت + Truth + فشار جاری تأیید شد";

      g_last_strategy_type = STRATEGY_NONE;
      g_last_strategy_confidence = g_opportunity_capture.quality;
   }

   if(!Scenario_IsValid(g_scenario))
   {
      reason = "سناریوی اجرایی Opportunity پس از ساخت معتبر نیست";
      return false;
   }

   //===============================================================
   // V5.116: هر Opportunity یکتا فقط یک‌بار اجازه اجرای واقعی دارد
   // مگر اینکه ممیزی فرصت یک شناسه جدید ایجاد کرده باشد. این مانع
   // ورودهای پشت‌سرهم از همان Opportunity در 5 دقیقه‌های مجاور است.
   //===============================================================
   double opportunity_audit_atr =
      (live_truth.move_atr_multiple > 0.0 && live_truth.move_size > 0.0
       ? live_truth.move_size / live_truth.move_atr_multiple
       : 0.0);
   if(opportunity_audit_atr <= 0.0)
      opportunity_audit_atr = GetCurrentATRPrice();

   ulong current_opportunity_id =
      SignalAudit_FindOrCreateOpportunity(
         g_signal_audit,
         g_scenario,
         opportunity_audit_atr);

   if(current_opportunity_id > 0 &&
      current_opportunity_id == g_last_executed_opportunity_id)
   {
      reason =
         "این Opportunity قبلاً معامله شده است و ورود تکراری مجاز نیست" +
         " | OpportunityID=" + (string)current_opportunity_id;
      return false;
   }

   const datetime current_live_m5_bar =
      iTime(_Symbol,Inp_TF_Setup_M5,1);
   if(current_opportunity_id == 0 &&
      g_last_direct_opportunity_direction == direction &&
      current_live_m5_bar > 0 &&
      g_last_direct_opportunity_bar > 0 &&
      (current_live_m5_bar - g_last_direct_opportunity_bar) <=
         (long)MathMax(1,Inp_Opportunity_Pending_Max_M5_Bars) * 300 &&
      g_last_direct_opportunity_anchor > 0.0 &&
      MathAbs(g_opportunity_capture.reaction_anchor -
              g_last_direct_opportunity_anchor) <=
         MathMax(
            MathMax(opportunity_audit_atr, _Point * 20.0) * 0.25,
            g_opportunity_capture.reaction_zone_width))
   {
      reason = "Opportunity نزدیک به رویداد قبلی تشخیص داده شد؛ ورود تکراری متوقف شد";
      return false;
   }

   TradingScenario sl_reference_scenario = g_scenario;
   sl_reference_scenario.entry_price = current_price;

   double atr_price = 0.0;
   if(live_truth.move_atr_multiple > 0.0 && live_truth.move_size > 0.0)
      atr_price = live_truth.move_size / live_truth.move_atr_multiple;
   if(atr_price <= 0.0)
      atr_price = GetCurrentATRPrice();
   if(atr_price <= 0.0)
      atr_price = _Point * 100.0;

   SLPlan direct_sl;
   ZeroMemory(direct_sl);
   if(!BuildExecutionSLFromScenario(
      direction,
      sl_reference_scenario,
      atr_price,
      direct_sl) ||
      !SL_IsValid(direct_sl))
   {
      reason = "SL مستقیم فرصت قابل ساخت یا تأیید نیست";
      return false;
   }

   double system_target =
      (g_scenario.target_2 > 0.0
       ? g_scenario.target_2
       : g_scenario.target_1);

   if(direction == SCENARIO_DIRECTION_BUY &&
      live_structure.structural_high > current_price)
      system_target = live_structure.structural_high;
   else
   if(direction == SCENARIO_DIRECTION_SELL &&
           live_structure.structural_low > 0.0 &&
           live_structure.structural_low < current_price)
      system_target = live_structure.structural_low;

   if(system_target <= 0.0)
   {
      system_target =
         (direction == SCENARIO_DIRECTION_BUY
          ? current_price + atr_price * 2.0
          : current_price - atr_price * 2.0);
   }

   if(!EnsureTargetMeetsMinimumRR(
      direction,
      current_price,
      direct_sl.stop_price,
      system_target,
      atr_price))
   {
      reason = "هدف مستقیم Opportunity با حداقل R/R قابل تأیید نیست";
      return false;
   }

   //--- Target داخلی با Entry واقعی Market هم‌تراز می‌شود و همان رفتار دو سطحی قبلی حفظ می‌گردد.
   const double minimum_reward = MathAbs(current_price - direct_sl.stop_price);
   double direct_tp1 =
      (direction == SCENARIO_DIRECTION_BUY
       ? current_price + minimum_reward
       : current_price - minimum_reward);
   const double half_tp =
      current_price +
      (system_target - current_price) * 0.50;

   if(direction == SCENARIO_DIRECTION_BUY)
   {
      if(half_tp > direct_tp1)
         direct_tp1 = half_tp;
   }
   else
   {
      if(half_tp < direct_tp1)
         direct_tp1 = half_tp;
   }

   g_scenario.target_1 = direct_tp1;
   g_scenario.target_2 = system_target;

   TP_Init(g_tp_result);
   TP_Target direct_tp_target;
   TP_TargetInit(direct_tp_target);
   if(!TP_CreateTarget(
      1,
      TP_TARGET_STRUCTURE,
      TP_STATUS_VALID,
      direct_tp1,
      g_opportunity_capture.quality,
      "هدف اول ساختاری مستقیم فرصت",
      "OpportunityFirst",
      direct_tp_target))
   {
      reason = "ساخت Target اول Opportunity ناموفق بود";
      return false;
   }
   if(!TP_SetTarget(g_tp_result,1,direct_tp_target))
   {
      reason = "ثبت Target اول Opportunity ناموفق بود";
      return false;
   }
   TP_Target direct_tp2_target;
   TP_TargetInit(direct_tp2_target);
   if(!TP_CreateTarget(
      2,
      TP_TARGET_STRUCTURE,
      TP_STATUS_VALID,
      system_target,
      g_opportunity_capture.quality,
      "هدف دوم ساختاری مستقیم فرصت",
      "OpportunityFirst",
      direct_tp2_target) ||
      !TP_SetTarget(g_tp_result,2,direct_tp2_target))
   {
      reason = "ثبت Target دوم Opportunity ناموفق بود";
      return false;
   }
   TP_ValidateTargets(
      direction == SCENARIO_DIRECTION_BUY,
      current_price,
      g_tp_result);

   Target_Init(g_target);
   if(!Target_Create(
      1000000 + g_scenario.id,
      TARGET_TYPE_STRUCTURE,
      TARGET_PRIORITY_PRIMARY,
      system_target,
      0.0,
      0.0,
      current_time,
      g_scenario.expiry_time,
      g_opportunity_capture.quality,
      "فرصت مستقیم",
      "هدف ساختاری مستقیم Opportunity",
      g_target) ||
      !Target_SetEntryDistance(
         g_target,
         direction == SCENARIO_DIRECTION_BUY ? ORDER_TYPE_BUY : ORDER_TYPE_SELL,
         current_price) ||
      !Target_UpdateStatus(g_target,current_time))
   {
      reason = "ثبت Target Engine فرصت ناموفق بود";
      return false;
   }

   g_sl_plan = direct_sl;

   EntryPlan_Init(g_entry_plan);
   g_entry_plan.scenario_id = g_scenario.id;
   g_entry_plan.direction = direction;
   g_entry_plan.symbol = _Symbol;
   g_entry_plan.current_price = current_price;
   g_entry_plan.entry_price = current_price;
   g_entry_plan.zone_lower = g_scenario.zone_lower;
   g_entry_plan.zone_upper = g_scenario.zone_upper;
   g_entry_plan.invalidation_price = g_scenario.invalidation_price;
   g_entry_plan.created_time = current_time;
   g_entry_plan.expiry_time = g_scenario.expiry_time;
   g_entry_plan.type = ENTRY_PLAN_MARKET;
   g_entry_plan.status = ENTRY_PLAN_STATUS_READY;
   g_entry_plan.executable = true;
   g_entry_plan.entry_currently_available = true;
   g_entry_plan.entry_reachable = true;
   g_entry_plan.pending_allowed = false;
   g_entry_plan.reason =
      "فرصت مستقیم ورود لحظه‌ای | Opportunity + Timing + واکنش + ساختار + جهت زنده + Truth + فشار جاری تأیید شد" +
      " | Quality=" + DoubleToString(g_opportunity_capture.quality,1) +
      " | TruthMoveATR=" + DoubleToString(live_truth.move_atr_multiple,2) +
      " | RoomATR=" + DoubleToString(g_opportunity_capture.estimated_room_atr,2) +
      " | Entry=" + DoubleToString(current_price,_Digits);

   Print(
      "[فرصت مستقیم ورود لحظه‌ای] اجرای مستقیم آماده شد | جهت=",
      direction == SCENARIO_DIRECTION_BUY ? "خرید" : "فروش",
      " | سناریو=",g_scenario.id,
      " | کیفیت=",DoubleToString(g_opportunity_capture.quality,1),
      " | قیمت جاری=",DoubleToString(current_price,_Digits),
      " | حد ضرر=",DoubleToString(g_sl_plan.stop_price,_Digits),
      " | حد سود=",DoubleToString(system_target,_Digits));

   LogCycle("فرصت مستقیم",g_entry_plan.reason);
   reason = g_entry_plan.reason;
   return true;
}

// مسیر Catch-Up قدیمی اکنون همان مسیر مستقل Opportunity را صدا می‌زند.
bool PromotePriorityOpportunityToMarket(
   const double current_price,
   const datetime current_time,
   EntryPlan &plan)
{
   string local_reason = "";
   if(!PrepareDirectPriorityOpportunityMarketEntry(
      current_price,
      current_time,
      local_reason))
      return false;

   plan = g_entry_plan;
   return true;
}

//====================================================================
// V5.116: ممانعت از دور زدن گیت Opportunity با Fallback به Scenario عمومی
// فقط وقتی رد شدن Opportunity به علت یک شرط ایمنیِ لحظه‌ای باشد،
// Scenario عمومی حق تبدیل همان Opportunity به معامله را ندارد.
//====================================================================
bool V594_DirectOpportunitySafetyBlockStopsFallback(const string &reason)
{
   if(reason == "")
      return false;

   const string blocks[] =
   {
      "متوقف شد",
      "هم‌جهت نیست",
      "خنثی یا متضاد است",
      "حرکت مخالف جهت فرصت",
      "Correction زنده",
      "قیمت از نقطه ثبت فرصت",
      "Truth زنده پیش از اجرای فرصت",
      "Structure زنده پیش از اجرای فرصت",
      "خوانش زنده M5 پیش از اجرای فرصت",
      "روند زنده",
      "کندل بسته‌شده M5"
   };

   for(int i=0; i<ArraySize(blocks); ++i)
   {
      if(StringFind(reason,blocks[i]) >= 0)
         return true;
   }

   return false;
}

bool V594_GeneralLateStretchGuardBlocksEntry(
   const ENUM_SCENARIO_DIRECTION direction,
   string &reason)
{
   reason = "";

   if(!Inp_Direct_Opportunity_Late_Stretch_Guard_Enabled)
      return false;

   if(!g_market_truth.valid ||
      !g_structure.valid ||
      !g_regime.valid)
      return false;

   if(direction != SCENARIO_DIRECTION_BUY &&
      direction != SCENARIO_DIRECTION_SELL)
      return false;

   const bool balanced =
      (g_structure.state == STRUCTURE_STATE_BALANCED);
   const bool range =
      (g_regime.regime == MARKET_REGIME_RANGE);

   if(!balanced || !range)
      return false;

   if(g_market_truth.direction !=
      (direction == SCENARIO_DIRECTION_BUY
       ? MARKET_TRUTH_BUY
       : MARKET_TRUTH_SELL))
      return false;

   const double stretch =
      g_market_truth.move_atr_multiple;

   if(stretch < Inp_Direct_Opportunity_Late_Truth_ATR)
      return false;

   reason =
      (direction == SCENARIO_DIRECTION_BUY
       ? "BUY سناریوی عمومی در Range + ساختار متعادل به‌دلیل کشیدگی شدید متوقف شد"
       : "SELL سناریوی عمومی در Range + ساختار متعادل به‌دلیل کشیدگی شدید متوقف شد") +
      " | TruthMoveATR=" + DoubleToString(stretch,2) +
      " | حد=" + DoubleToString(Inp_Direct_Opportunity_Late_Truth_ATR,2);

   Print("[V5.116 GENERAL LATE STRETCH BLOCK] ",reason);
   return true;
}

//====================================================================
// V5.116: گیت نهایی مشترک برای تمام Market Entryهای خودکار
//
// همه مسیرهای خودکار Market در آخرین نقطه قبل از OrderSend این گیت را
// می‌گذرانند تا Scenario عمومی نتواند کنترل Trigger مسیر Opportunity را
// دور بزند. HTF/M15/M30 در اینجا داور ورود نیستند.
//====================================================================
bool V594_FinalAutomaticMarketEntryGate(
   const ENUM_SCENARIO_DIRECTION direction,
   const double current_price,
   string &reason)
{
   reason = "";

   if(!Inp_Enable_Entry_Decision_Gate)
      return true;

   if(direction != SCENARIO_DIRECTION_BUY &&
      direction != SCENARIO_DIRECTION_SELL)
   {
      reason = "جهت Market Entry معتبر نیست";
      return false;
   }

   if(current_price <= 0.0)
   {
      reason = "قیمت لحظه اجرای Market معتبر نیست";
      return false;
   }

   MarketTruthSnapshot live_truth;
   MarketTruth_Reset(live_truth);
   if(Inp_Use_Market_Truth)
   {
      if(!MarketTruth_Analyze(
            _Symbol,
            Inp_TF_Setup_M5,
            Inp_Market_Truth_Lookback,
            live_truth) ||
         !live_truth.valid)
      {
         reason = "Truth زنده M5 در گیت نهایی قابل تأیید نیست";
         return false;
      }

      const bool opposite =
         (direction == SCENARIO_DIRECTION_BUY &&
          live_truth.direction == MARKET_TRUTH_SELL) ||
         (direction == SCENARIO_DIRECTION_SELL &&
          live_truth.direction == MARKET_TRUTH_BUY);

      if(opposite &&
         live_truth.strong_market_move &&
         live_truth.continuation_ready &&
         live_truth.phase == MARKET_TRUTH_PHASE_REVERSAL &&
         live_truth.move_atr_multiple >= 2.50)
      {
         reason =
            "ورود Market به‌دلیل برگشت قوی و تأییدشده M5 متوقف شد" +
            " | Truth=" + MarketTruth_DirectionToString(live_truth.direction) +
            " | MoveATR=" + DoubleToString(live_truth.move_atr_multiple,2);
         return false;
      }

      if(opposite && live_truth.strong_market_move)
      {
         reason =
            (direction == SCENARIO_DIRECTION_BUY
             ? "BUY Market با جهت قوی Truth زنده هم‌جهت نیست"
             : "SELL Market با جهت قوی Truth زنده هم‌جهت نیست") +
            " | Truth=" + MarketTruth_DirectionToString(live_truth.direction) +
            " | MoveATR=" + DoubleToString(live_truth.move_atr_multiple,2);
         return false;
      }
   }

   const bool direct_opportunity_plan =
      (StringFind(g_entry_plan.reason,"فرصت مستقیم ورود لحظه‌ای") >= 0);

   if(direct_opportunity_plan)
   {
      Print("[V5.116 FINAL DIRECT BRIDGE] گیت عمومی Trigger برای Opportunity مستقیم تکرار نشد");
      return true;
   }

   MarketStructureSnapshot live_structure;
   MarketStructure_Reset(live_structure);
   if(!MarketStructure_Analyze(
         _Symbol,
         Inp_TF_Structure_M15,
         120,
         2,
         2,
         20.0,
         live_structure) ||
      !live_structure.valid)
   {
      reason = "Structure زنده پیش از Market قابل تأیید نیست";
      return false;
   }

   ImpulseCorrectionSnapshot live_move;
   ImpulseCorrection_Reset(live_move);
   if(!ImpulseCorrection_Analyze(
         _Symbol,
         Inp_TF_Setup_M5,
         120,
         2,
         2,
         20.0,
         live_move) ||
      !live_move.valid)
   {
      reason = "حرکت M5 زنده پیش از Market قابل تأیید نیست";
      return false;
   }

   const int desired_dir =
      (direction == SCENARIO_DIRECTION_BUY ? 1 : -1);
   const bool transition_structure =
      (live_structure.state == STRUCTURE_STATE_TRANSITION);
   const bool continuation_strategy =
      (g_last_strategy_type == STRATEGY_SELL_CONTINUATION ||
       g_last_strategy_type == STRATEGY_BUY_CONTINUATION);

   const bool strong_transition =
      transition_structure &&
      live_move.impulse_valid &&
      live_move.impulse_direction == desired_dir &&
      Inp_Use_Market_Truth &&
      live_truth.valid &&
      live_truth.strong_market_move &&
      live_truth.continuation_ready &&
      live_truth.move_atr_multiple >=
         MathMax(3.50, Inp_Direct_Continuation_Max_ATR);

   if(transition_structure && continuation_strategy && !strong_transition)
   {
      reason =
         "ورود Market Continuation در ساختار در حال تغییر بدون حرکت قوی M5 متوقف شد" +
         " | نیاز=" +
         DoubleToString(MathMax(3.50, Inp_Direct_Continuation_Max_ATR),2) +
         "ATR";
      if(Inp_Use_Market_Truth && live_truth.valid)
         reason += " | جاری=" + DoubleToString(live_truth.move_atr_multiple,2);
      return false;
   }

   if(strong_transition &&
      live_truth.move_atr_multiple >= Inp_Direct_Opportunity_Late_Truth_ATR &&
      live_truth.phase == MARKET_TRUTH_PHASE_REVERSAL)
   {
      reason =
         "ورود Market Transition در انتهای حرکت و شروع REVERSAL متوقف شد" +
         " | TruthMoveATR=" + DoubleToString(live_truth.move_atr_multiple,2);
      return false;
   }

   if(live_structure.state == STRUCTURE_STATE_BALANCED)
   {
      MarketReadingSnapshot live_reading;
      MarketReading_Reset(live_reading);
      if(!MarketReading_Analyze(
            _Symbol,
            Inp_TF_Setup_M5,
            live_truth,
            live_structure,
            live_reading) ||
         !live_reading.valid)
      {
         reason = "خوانش زنده M5 برای Trigger متعادل قابل تأیید نیست";
         return false;
      }

      const double atr_price = MathMax(GetCurrentATRPrice(), _Point * 10.0);
      const double body_atr =
         MathAbs(live_reading.current_price - live_reading.candle_open) /
         MathMax(atr_price, _Point * 10.0);
      const double breakout_buffer = MathMax(_Point * 2.0, atr_price * 0.02);
      const double previous_high = iHigh(_Symbol,Inp_TF_Setup_M5,1);
      const double previous_low  = iLow(_Symbol,Inp_TF_Setup_M5,1);
      const bool pressure_ok =
         (direction == SCENARIO_DIRECTION_BUY
          ? (live_reading.current_up_pressure && !live_reading.current_down_pressure)
          : (live_reading.current_down_pressure && !live_reading.current_up_pressure));
      const bool structural_breakout =
         (direction == SCENARIO_DIRECTION_BUY
          ? (live_structure.structural_high > 0.0 &&
             current_price > live_structure.structural_high + breakout_buffer)
          : (live_structure.structural_low > 0.0 &&
             current_price < live_structure.structural_low - breakout_buffer));
      const bool trigger =
         pressure_ok &&
         body_atr >= MathMax(0.01,
            Inp_Direct_Opportunity_Balanced_Min_Trigger_Body_ATR);

      if(!structural_breakout && !trigger)
      {
         reason =
            (direction == SCENARIO_DIRECTION_BUY
             ? "BUY Market در ساختار متعادل بدون Trigger زنده کافی متوقف شد"
             : "SELL Market در ساختار متعادل بدون Trigger زنده کافی متوقف شد") +
            " | BodyATR=" + DoubleToString(body_atr,2) +
            " | نیاز=" +
            DoubleToString(Inp_Direct_Opportunity_Balanced_Min_Trigger_Body_ATR,2) +
            "ATR";
         return false;
      }
   }

   return true;
}

//====================================================================
// V5.95: بازقیمت‌گذاری پویا برای Pendingهای Opportunity
// قیمت فقط در جهت مطلوب و داخل محدوده Reaction Anchor نزدیک می‌شود؛
// هیچ حرکت معکوس و هیچ تغییری در حجم، SL/TP یا سقف معاملات ایجاد نمی‌کند.
//====================================================================
string V5100_HTFToPersian(const ENUM_HTF_DIRECTION direction)
{
   switch(direction)
   {
      case HTF_DIRECTION_BULLISH: return "صعودی";
      case HTF_DIRECTION_BEARISH: return "نزولی";
      case HTF_DIRECTION_NEUTRAL: return "خنثی";
      default: return "نامشخص";
   }
}

bool V5100_FindScenarioInBook(const ulong scenario_id, TradingScenario &scenario)
{
   if(scenario_id == 0)
      return false;

   for(int i=0; i<ArraySize(g_scenario_book); i++)
   {
      if(g_scenario_book[i].id == scenario_id)
      {
         scenario = g_scenario_book[i];
         return true;
      }
   }

   return false;
}

void V5100_LogPendingRescueDecision(
   const PendingOrderRecord &record,
   const string decision,
   const string reason,
   const double live_truth_atr,
   const double scenario_quality,
   const double travel_atr)
{
   string scenario_state = "Pending Rescue";
   string scenario_direction =
      record.direction == SCENARIO_DIRECTION_BUY ? "خرید" :
      (record.direction == SCENARIO_DIRECTION_SELL ? "فروش" : "نامشخص");

   double scenario_entry = record.price;
   double invalidation = record.stop_loss;
   double tp1 = record.take_profit;
   double tp2 = record.take_profit;
   string setup_reason = reason +
      " | تصمیم=" + decision +
      " | TruthMoveATR=" + DoubleToString(live_truth_atr,2) +
      " | ScenarioQuality=" + DoubleToString(scenario_quality,1) +
      " | TravelATR=" + DoubleToString(travel_atr,2);

   TradingScenario sc;
   if(V5100_FindScenarioInBook(record.scenario_id,sc))
   {
      scenario_state = ScenarioStatusToPersian(sc.status);
      scenario_direction = ScenarioDirectionToPersian(sc.direction);
      scenario_entry = sc.entry_price > 0.0 ? sc.entry_price : record.price;
      invalidation = sc.invalidation_price > 0.0 ? sc.invalidation_price : record.stop_loss;
      tp1 = sc.target_1 > 0.0 ? sc.target_1 : record.take_profit;
      tp2 = sc.target_2 > 0.0 ? sc.target_2 : tp1;
   }

   const double atr = MathMax(GetCurrentATRPrice(), _Point * 10.0);
   MarketDetailReport_Write(
      g_market_detail_report,
      TimeCurrent(),
      _Symbol,
      Inp_TF_Setup_M5,
      SymbolInfoDouble(_Symbol,SYMBOL_BID),
      SymbolInfoDouble(_Symbol,SYMBOL_ASK),
      g_context.spread_points,
      V5100_HTFToPersian(g_higher_tf_context.combined_direction),
      V5100_HTFToPersian(g_higher_tf_context.combined_direction),
      MarketRegime_ToPersian(g_regime.regime),
      MarketContext_ToPersian(g_context.state),
      MarketStructure_StateToPersian(g_structure.state),
      "Pending Rescue",
      scenario_direction,
      g_move.valid && atr > 0.0 ? g_move.impulse_size_points / atr : 0.0,
      g_move.valid ? g_move.correction_ratio : 0.0,
      0.0,
      0.0,
      "",
      scenario_state,
      scenario_direction,
      scenario_quality,
      scenario_entry,
      invalidation,
      record.stop_loss,
      tp1,
      tp2,
      "Pending Rescue",
      scenario_direction,
      setup_reason,
      "LIMIT",
      PendingStateToPersian(record.state),
      record.active,
      true,
      setup_reason,
      record.opportunity_priority,
      scenario_quality,
      reason,
      PendingStateToPersian(record.state),
      record.ticket,
      "PENDING_RESCUE_" + decision);
}

bool V5103_FindAuditScenarioSnapshot(
   const PendingOrderRecord &record,
   double &scenario_quality,
   bool &structure_valid,
   bool &impulse_valid,
   bool &zone_valid,
   string &audit_direction,
   double &audit_truth_atr,
   ulong &matched_signal_id,
   ulong &matched_opportunity_id)
{
   scenario_quality=0.0;
   structure_valid=false;
   impulse_valid=false;
   zone_valid=false;
   audit_direction="";
   audit_truth_atr=0.0;
   matched_signal_id=0;
   matched_opportunity_id=0;

   if(!g_signal_audit.initialized || !g_signal_audit.enabled || ArraySize(g_signal_audit.records)<=0)
      return false;

   const double atr_floor=MathMax(GetCurrentATRPrice(),_Point*10.0);
   const double reference_price=(record.opportunity_reference_price>0.0 ? record.opportunity_reference_price : record.price);
   const datetime reference_time=(record.created_time>0 ? record.created_time : (record.placed_time>0 ? record.placed_time : TimeCurrent()));
   const string wanted_direction=ScenarioDirectionToPersian(record.direction);
   const long max_gap=(long)MathMax(30,MathMax(1,Inp_Opportunity_Max_Gap_Minutes))*60;
   const double max_dist_atr=MathMax(1.50,Inp_Opportunity_Max_Entry_Distance_ATR);

   int best=-1;
   double best_score=1.0e100;
   int exact_best=-1;
   double exact_score=1.0e100;

   for(int i=0;i<ArraySize(g_signal_audit.records);i++)
   {
      const SignalAuditRecord r=g_signal_audit.records[i];
      if(!r.active || r.direction!=wanted_direction)
         continue;

      const long gap=(long)MathAbs((double)(reference_time-r.signal_time));
      if(gap>max_gap)
         continue;

      const double atr=MathMax(r.atr_price,atr_floor);
      const double dist_atr=MathAbs(reference_price-r.entry_price)/atr;
      if(dist_atr>max_dist_atr)
         continue;

      const bool exact_id=(record.scenario_id>0 && r.signal_id==record.scenario_id);
      const double score=(double)gap/60.0 + dist_atr*20.0 - r.scenario_quality*0.10 - (exact_id ? 1000.0 : 0.0);
      if(score<best_score)
      {
         best=i;
         best_score=score;
      }
      if(exact_id && score<exact_score)
      {
         exact_best=i;
         exact_score=score;
      }
   }

   if(exact_best>=0)
      best=exact_best;
   if(best<0)
      return false;

   const SignalAuditRecord r=g_signal_audit.records[best];
   scenario_quality=r.scenario_quality;
   structure_valid=r.structure_valid;
   impulse_valid=r.impulse_valid;
   zone_valid=r.zone_valid;
   audit_direction=r.direction;
   audit_truth_atr=r.truth_move_atr;
   matched_signal_id=r.signal_id;
   matched_opportunity_id=r.opportunity_id;
   return true;
}

bool V595_RepricePriorityPendingRecord(
   PendingOrderRecord &record,
   const double bid,
   const double ask,
   const double atr_price,
   const datetime now)
{
   if(!Inp_AllowPendingOrders ||
      !record.active ||
      record.ticket == 0 ||
      record.plan_type != ENTRY_PLAN_LIMIT ||
      atr_price <= 0.0)
      return false;

   if(record.direction != SCENARIO_DIRECTION_BUY &&
      record.direction != SCENARIO_DIRECTION_SELL)
      return false;

   const double base_reference =
      record.opportunity_reference_price > 0.0
      ? record.opportunity_reference_price
      : record.price;

   if(base_reference <= 0.0)
      return false;

   const bool favorable_move =
      (record.direction == SCENARIO_DIRECTION_BUY ? bid > base_reference : ask < base_reference);
   if(!favorable_move)
      return false;

   const double moved_price =
      (record.direction == SCENARIO_DIRECTION_BUY ? bid : ask);
   const double travel_atr = MathAbs(moved_price-base_reference)/atr_price;

   bool rescue_mode = false;
   double scenario_quality = 0.0;
   string reject_reason = "";

   TradingScenario linked_scenario;
   const bool linked = V5100_FindScenarioInBook(record.scenario_id,linked_scenario);
   if(linked)
      scenario_quality = linked_scenario.quality_value;

   // V5.116: کیفیت و ساختار Rescue از Evidence ممیزی مستقل نیز قابل بازیابی است؛
   // حتی اگر Scenario فعلی پاک، منقضی یا با کیفیت صفر شده باشد.
   double audit_quality=0.0;
   bool audit_structure_valid=false;
   bool audit_impulse_valid=false;
   bool audit_zone_valid=false;
   string audit_direction="";
   double audit_truth_atr=0.0;
   ulong matched_signal_id=0;
   ulong matched_opportunity_id=0;
   const bool audit_snapshot_found=
      V5103_FindAuditScenarioSnapshot(
         record,
         audit_quality,
         audit_structure_valid,
         audit_impulse_valid,
         audit_zone_valid,
         audit_direction,
         audit_truth_atr,
         matched_signal_id,
         matched_opportunity_id);

   if(audit_snapshot_found)
      scenario_quality=MathMax(scenario_quality,audit_quality);

   const bool rescue_candidate=
      Inp_Opportunity_Pending_Rescue_Enabled &&
      travel_atr>=MathMax(0.50,Inp_Opportunity_Pending_Reprice_Threshold_ATR);

   if(rescue_candidate)
   {
      MarketTruthSnapshot rescue_truth;
      ImpulseCorrectionSnapshot rescue_move;
      MarketStructureSnapshot rescue_structure;
      MarketTruth_Reset(rescue_truth);
      ImpulseCorrection_Reset(rescue_move);
      MarketStructure_Reset(rescue_structure);

      const bool truth_ok=MarketTruth_Analyze(_Symbol,Inp_TF_Setup_M5,Inp_Market_Truth_Lookback,rescue_truth) && rescue_truth.valid;
      const bool move_ok=ImpulseCorrection_Analyze(_Symbol,Inp_TF_Setup_M5,120,2,2,20.0,rescue_move) && rescue_move.valid;
      const bool structure_ok=MarketStructure_Analyze(_Symbol,Inp_TF_Setup_M5,Inp_Market_Truth_Lookback,2,2,20.0,rescue_structure) && rescue_structure.valid;

      const bool direction_ok=truth_ok && rescue_truth.direction==(record.direction==SCENARIO_DIRECTION_BUY ? MARKET_TRUTH_BUY : MARKET_TRUTH_SELL);
      const int desired_dir=(record.direction==SCENARIO_DIRECTION_BUY ? 1 : -1);
      const bool live_impulse_ok=move_ok && rescue_move.impulse_valid && rescue_move.impulse_direction==desired_dir;
      const bool audit_impulse_ok=audit_snapshot_found && audit_impulse_valid && audit_direction==ScenarioDirectionToPersian(record.direction);
      const bool impulse_ok=audit_impulse_ok || live_impulse_ok;

      const bool live_structure_opposite=
         structure_ok &&
         ((record.direction==SCENARIO_DIRECTION_BUY && rescue_structure.state==STRUCTURE_STATE_BEARISH) ||
          (record.direction==SCENARIO_DIRECTION_SELL && rescue_structure.state==STRUCTURE_STATE_BULLISH));
      const bool structure_safe=!live_structure_opposite && (structure_ok || audit_structure_valid);

      const bool linked_scenario_live=linked &&
         linked_scenario.status!=SCENARIO_STATUS_INVALID &&
         linked_scenario.status!=SCENARIO_STATUS_EXPIRED &&
         linked_scenario.status!=SCENARIO_STATUS_CANCELLED;

      const bool linked_scenario_ok=linked_scenario_live &&
         linked_scenario.direction==record.direction &&
         linked_scenario.structure_valid &&
         linked_scenario.impulse_valid &&
         linked_scenario.zone_valid &&
         linked_scenario.regime_aligned &&
         !linked_scenario.conflict_present &&
         scenario_quality>=MathMax(70.0,Inp_Opportunity_Pending_Rescue_Min_Quality);

      const bool audit_scenario_ok=audit_snapshot_found &&
         audit_direction==ScenarioDirectionToPersian(record.direction) &&
         audit_quality>=MathMax(70.0,Inp_Opportunity_Pending_Rescue_Min_Quality) &&
         audit_structure_valid && audit_zone_valid;

      const bool rescue_quality_ok=linked_scenario_ok || audit_scenario_ok;
      const bool truth_strength_ok=truth_ok &&
         rescue_truth.move_atr_multiple>=MathMax(2.50,Inp_Opportunity_Pending_Rescue_Min_Truth_ATR);

      rescue_mode=truth_ok && direction_ok && truth_strength_ok && rescue_quality_ok && impulse_ok && structure_safe;

      if(!rescue_mode)
      {
         if(!truth_ok) reject_reason="Truth زنده معتبر نیست";
         else if(!direction_ok) reject_reason="جهت Truth با Pending همسو نیست";
         else if(!truth_strength_ok) reject_reason="قدرت Truth برای Rescue کافی نیست";
         else if(!rescue_quality_ok) reject_reason="سناریوی Audit/Live کیفیت و ساختار لازم را ندارد";
         else if(!impulse_ok) reject_reason="Impulse Evidence سناریو جهت Pending را تأیید نمی‌کند";
         else if(!structure_safe) reject_reason="ساختار زنده علیه Pending است";
         else reject_reason="Rescue رد شد";

         V5100_LogPendingRescueDecision(
            record,"REJECT",
            reject_reason+" | AuditMatch="+(audit_snapshot_found ? "YES" : "NO")+
            " | SignalID="+(string)matched_signal_id+
            " | OpportunityID="+(string)matched_opportunity_id,
            truth_ok ? rescue_truth.move_atr_multiple : 0.0,
            scenario_quality,travel_atr);
         return false;
      }

      if(travel_atr > MathMax(5.0,Inp_Opportunity_Pending_Rescue_Max_Drift_ATR))
      {
         reject_reason = "فاصله از Entry اولیه بیش از سقف Rescue است";
         V5100_LogPendingRescueDecision(
            record,
            "REJECT",
            reject_reason,
            rescue_truth.move_atr_multiple,
            scenario_quality,
            travel_atr);
         return false;
      }
   }

   // بازقیمت‌گذاری عادی همچنان فقط برای Opportunity Priority قبلی مجاز است.
   if(!rescue_mode &&
      (!Inp_Opportunity_Dynamic_Pending_Enabled || !record.opportunity_priority))
      return false;

   const double allowed_max_travel =
      rescue_mode
      ? MathMax(5.0,Inp_Opportunity_Pending_Rescue_Max_Drift_ATR)
      : MathMax(0.50,Inp_Opportunity_Pending_Reprice_Max_ATR);

   if(travel_atr < MathMax(0.05,Inp_Opportunity_Pending_Reprice_Threshold_ATR) ||
      travel_atr > allowed_max_travel)
      return false;

   const double point = SymbolInfoDouble(_Symbol,SYMBOL_POINT);
   const long stops_level = SymbolInfoInteger(_Symbol,SYMBOL_TRADE_STOPS_LEVEL);
   const long freeze_level = SymbolInfoInteger(_Symbol,SYMBOL_TRADE_FREEZE_LEVEL);
   const double min_gap = MathMax(
      point,
      (double)MathMax(1,MathMax(stops_level,freeze_level))*point);

   double target = record.price;

   if(rescue_mode)
   {
      // Rescue مرحله‌ای: هر بار فقط 50 درصد فاصله باقی‌مانده تا بازار طی می‌شود.
      const double rescue_fraction=0.50;
      const double market_anchor=(record.direction==SCENARIO_DIRECTION_BUY ? bid-min_gap : ask+min_gap);
      if(market_anchor<=0.0)
         return false;

      target=record.price+(market_anchor-record.price)*rescue_fraction;
      if(record.direction==SCENARIO_DIRECTION_BUY && target<=record.price)
         return false;
      if(record.direction==SCENARIO_DIRECTION_SELL && target>=record.price)
         return false;

      const int rescue_bars=MathMax(3,Inp_Opportunity_Pending_Max_M5_Bars);
      const int rescue_seconds=PeriodSeconds(Inp_TF_Setup_M5);
      if(rescue_seconds>0 && rescue_bars>0)
      {
         datetime rescue_expiry=now+(datetime)(rescue_seconds*rescue_bars);
         if(linked && linked_scenario.expiry_time>0 && rescue_expiry>linked_scenario.expiry_time)
            rescue_expiry=linked_scenario.expiry_time;
         if(record.expiry_time==0 || record.expiry_time<rescue_expiry)
            record.expiry_time=rescue_expiry;
      }
   }

   else if(record.direction == SCENARIO_DIRECTION_BUY)
   {
      const double anchor = record.opportunity_reaction_anchor;
      const double width = MathMax(record.opportunity_reaction_width,atr_price*MathMax(0.05,Inp_Opportunity_Reaction_Zone_ATR));
      const double market_cap = ask-min_gap;
      const double anchor_cap = anchor > 0.0 ? anchor+width : market_cap;
      target = MathMin(market_cap,anchor_cap);
      if(target <= record.price)
         return false;
   }
   else
   {
      const double anchor = record.opportunity_reaction_anchor;
      const double width = MathMax(record.opportunity_reaction_width,atr_price*MathMax(0.05,Inp_Opportunity_Reaction_Zone_ATR));
      const double market_floor = bid+min_gap;
      const double anchor_floor = anchor > 0.0 ? anchor-width : market_floor;
      target = MathMax(market_floor,anchor_floor);
      if(target >= record.price)
         return false;
   }

   if(MathAbs(target-record.price) < atr_price*MathMax(0.05,Inp_Opportunity_Pending_Reprice_Threshold_ATR))
      return false;

   string modify_reason = "";
   const bool modified = PendingOrder_ModifyPrice(record,target,now,modify_reason);

   if(rescue_mode)
   {
      V5100_LogPendingRescueDecision(
         record,
         modified ? "ACCEPT" : "MODIFY_FAIL",
         modified ? "Pending قوی با حرکت واقعی بازار نجات داده شد" : modify_reason,
         g_market_truth.valid ? g_market_truth.move_atr_multiple : 0.0,
         scenario_quality,
         travel_atr);
   }

   return modified;
}

void V595_RepricePriorityPendingOrders(
   const double bid,
   const double ask,
   const double current_price,
   const datetime now)
{
   if(!Inp_Opportunity_Dynamic_Pending_Enabled)
      return;

   double atr_price = GetCurrentATRPrice();
   if(atr_price <= 0.0 && g_market_truth.valid &&
      g_market_truth.move_atr_multiple > 0.0 && g_market_truth.move_size > 0.0)
      atr_price = g_market_truth.move_size/g_market_truth.move_atr_multiple;
   if(atr_price <= 0.0)
      return;

   V595_RepricePriorityPendingRecord(g_pending,bid,ask,atr_price,now);

   for(int i=0;i<ArraySize(g_pending_pool);i++)
   {
      if(g_pending_pool[i].ticket == 0 || !g_pending_pool[i].active ||
         g_pending_pool[i].ticket == g_pending.ticket)
         continue;
      V595_RepricePriorityPendingRecord(g_pending_pool[i],bid,ask,atr_price,now);
   }
}

//====================================================================
// مدیریت ورود و سناریو
//====================================================================
void ManageScenarioAndEntry()
{
   double bid, ask, current_price;

   if(!GetCurrentPrices(bid, ask, current_price))
      return;

   datetime now = TimeCurrent();

   if(!EnforceActiveScenarioFreshness())
      return;

   RefreshPendingPoolStates();

   // V5.95: ابتدا Pendingهای Opportunity با قیمت جاری هم‌تراز می‌شوند.
   // Market مستقیم همچنان اولویت بالاتری دارد و قبل از ساخت مسیر عمومی اجرا می‌شود.
   V595_RepricePriorityPendingOrders(bid,ask,current_price,now);

   //=================================================================
   // V5.95: Opportunity First → Market
   // قبل از اعتبارسنجی عمومی Scenario اجرا می‌شود تا فرصت مستقل نیز
   // حق رسیدن به مسیر واقعی Market را داشته باشد.
   //=================================================================
   string direct_opportunity_reason = "";
   const bool direct_opportunity_ready =
      PrepareDirectPriorityOpportunityMarketEntry(
         current_price,
         now,
         direct_opportunity_reason);

   if(!direct_opportunity_ready &&
      direct_opportunity_reason != "" &&
      g_opportunity_capture.valid &&
      g_opportunity_capture.priority)
   {
      LogCycle(
         "فرصت مستقیم - مسدود",
         direct_opportunity_reason);

      // V5.116: اگر Opportunity در لحظه به دلیل ایمنی رد شد،
      // Scenario عمومی نباید همان Opportunity را دوباره وارد معامله کند.
      if(Inp_Opportunity_Direct_Market_Enabled &&
         V594_DirectOpportunitySafetyBlockStopsFallback(direct_opportunity_reason))
      {
         g_entry_plan.type = ENTRY_PLAN_WAIT;
         g_entry_plan.status = ENTRY_PLAN_STATUS_PLANNED;
         g_entry_plan.executable = false;
         g_entry_plan.entry_currently_available = false;
         g_entry_plan.entry_reachable = false;
         g_entry_plan.reason =
            "Opportunity مستقیم به‌دلیل شرط ایمنی لحظه‌ای رد شد؛ Fallback عمومی مسدود است | " +
            direct_opportunity_reason;
         SetScenarioDiagnostic(g_entry_plan.reason);
         return;
      }
   }

   if(direct_opportunity_ready)
   {
      // برنامه ورود مستقیم آماده است و نباید دوباره با EntryPlan عمومی بازنویسی شود.
   }
   else if(g_scenario.id <= 0 || !Scenario_IsValid(g_scenario))
   {
      g_entry_plan.type = ENTRY_PLAN_WAIT;
      g_entry_plan.status = ENTRY_PLAN_STATUS_PLANNED;
      g_entry_plan.executable = false;
      return;
   }

   InvalidationResult inv;

   if(!Invalidation_UpdateScenario(
      g_scenario,
      current_price,
      now,
      inv))
   {
      g_main_state.last_error = "ارزیابی Invalidation ناموفق بود";
      return;
   }

   if(g_scenario.status == SCENARIO_STATUS_INVALID ||
      g_scenario.status == SCENARIO_STATUS_EXPIRED)
   {
      Print(
         "[SCENARIO BLOCKED] سناریو دیگر معتبر نیست | ID=",
         g_scenario.id,
         " | Direction=",
         ScenarioDirectionToPersian(g_scenario.direction));

      CancelPendingOrdersForScenario(
         g_scenario.id,
         "Scenario Invalid/Expired");

      ResetActiveScenarioState(
         g_scenario.status == SCENARIO_STATUS_INVALID
         ? "Scenario Invalidated"
         : "Scenario Expired");

      return;
   }

   Setup_SetBase(
      g_setup,
      Scenario_IsValid(g_scenario),
      g_scenario.zone_valid,
      false,
      false,
      ScenarioDirectionToPersian(g_scenario.direction),
      current_price,
      g_scenario.zone_lower,
      g_scenario.zone_upper,
      g_scenario.invalidation_price,
      g_scenario.entry_price,
      now);

   Setup_CheckInvalidation(g_setup);
   Setup_Evaluate(g_setup);

   if(!direct_opportunity_ready)
   {
      // V5.116: محافظ عمومی برای همان الگوی ضررده 2026.09.22 01:35.
      // Range + Balanced + Truth کشیده نباید از مسیر Scenario عمومی
      // گیت‌های Opportunity را دور بزند. این محافظ فقط حالت بسیار کشیده
      // را می‌بندد و به روندهای جهت‌دار سالم دست نمی‌زند.
      if(g_scenario.direction == SCENARIO_DIRECTION_BUY ||
         g_scenario.direction == SCENARIO_DIRECTION_SELL)
      {
         string general_stretch_reason = "";
         if(V594_GeneralLateStretchGuardBlocksEntry(g_scenario.direction, general_stretch_reason))
         {
            g_entry_plan.type = ENTRY_PLAN_WAIT;
            g_entry_plan.status = ENTRY_PLAN_STATUS_PLANNED;
            g_entry_plan.executable = false;
            g_entry_plan.entry_currently_available = false;
            g_entry_plan.entry_reachable = false;
            g_entry_plan.reason = general_stretch_reason;
            SetScenarioDiagnostic(general_stretch_reason);
            LogCycle("GENERAL_LATE_STRETCH_BLOCK", general_stretch_reason);
            return;
         }
      }

      if(!EntryPlan_Build(
         g_scenario,
         g_setup,
         current_price,
         now,
         g_entry_plan))
         return;

      // Fallback برای سناریوی عمومی؛ مسیر اصلی Opportunity قبلاً اجرا شده است.
      PromotePriorityOpportunityToMarket(
         current_price,
         now,
         g_entry_plan);
   }

   //=================================================================
   // Pendingهای Scenario قبلی باید مستقل از Scenario جدید بمانند/لغو شوند.
   // برای جلوگیری از مصرف اشتباه سهمیه، Pending قدیمی به Scenario جدید
   // Relink نمی‌شود؛ اگر Scenario عوض شده باشد Pending قبلی لغو می‌شود.
   //=================================================================
   if(g_pending.active && g_pending.ticket > 0 &&
      g_pending.scenario_id != g_scenario.id)
   {
      if(PreservePendingOnSameDirectionScenarioChange(g_pending))
      {
         Print(
            "[OPPORTUNITY CARRY] Pending سناریوی قبلی به‌دلیل هم‌جهت بودن حفظ شد | Ticket=",
            g_pending.ticket,
            " | OldScenario=",g_pending.scenario_id,
            " | NewScenario=",g_scenario.id);

         LogCycle(
            "OPPORTUNITY_CARRY",
            "Pending معتبر هم‌جهت هنگام تغییر سناریو حفظ شد");
      }
      else
      {
         // V5.116: تغییر Scenario مخالف به‌تنهایی باعث حذف Pending قدیمی نمی‌شود.
         // فقط برگشت چندلایهٔ تأییدشده اجازه لغو سفارش را دارد.
         const bool old_pending_is_buy =
            (g_pending.direction == SCENARIO_DIRECTION_BUY);
         const bool confirmed_reversal =
            Inp_Enable_Reversal_Pending_Cancel &&
            ConfirmPendingReversalBeforeCancel(old_pending_is_buy);

         if(confirmed_reversal)
         {
            CancelPendingOrdersForScenario(
               g_pending.scenario_id,
               "برگشت واقعی و تأییدشده؛ Pending سناریوی قبلی لغو شد");

            PendingOrder_Init(g_pending);
            RefreshPendingPoolStates();
         }
         else
         {
            Print("[V5.116 OPPORTUNITY CARRY] Pending سناریوی قبلی حفظ شد؛ تغییر جهت هنوز برگشت قطعی نیست | Ticket=",
                  g_pending.ticket,
                  " | OldScenario=",g_pending.scenario_id,
                  " | NewScenario=",g_scenario.id);
         }
      }
   }

   //=================================================================
   // Early Market
   // Pending اصلی حفظ می‌شود و سهمیه Scenario را مصرف می‌کند.
   //=================================================================

   const int trades_requested =
      MathMax(1, Inp_Simultaneous_Trades);

   // سهمیه Inp_Simultaneous_Trades مربوط به همان Signal/Scenario است؛
   // بنابراین با مقدار پیش‌فرض ۱، یک Signal بیش از یک معامله ایجاد نمی‌کند.
   // فرصت یا Signal جدید، مسیر مستقل خود را دارد و سقف کل معاملات با Inp_MaxOpenTrades کنترل می‌شود.
   if(trades_requested <= 1 &&
      g_last_executed_scenario_id == g_scenario.id)
   {
      LogCycle(
         "SIGNAL_QUOTA",
         "این Signal قبلاً معامله Market موفق داشته است؛ اجرای تکراری متوقف شد");
      return;
   }

   const int scenario_exposure_before =
      CountScenarioExposure(g_scenario.id);

   Print(
      "[SIGNAL QUOTA] Scenario=",
      g_scenario.id,
      " | Requested=",
      trades_requested,
      " | ExistingExposure=",
      scenario_exposure_before,
      " | Open=",
      CountOpenPositionsForScenario(g_scenario.id),
      " | Pending=",
      CountPendingOrdersForScenario(g_scenario.id));

   // اگر این سناریو واقعاً جهت را برگردانده، قبل از باز کردن جهت جدید
   // تمام معاملات جهت قدیمی بسته می‌شوند؛ در غیر این صورت ورود معکوس متوقف می‌شود.
   if(!CloseOldSideBeforeReverseEntry())
   {
      if(HasOppositeOpenPositionForScenarioDirection(g_scenario.direction))
      {
         LogCycle("REVERSE","ورود معکوس تا بسته‌شدن کامل معاملات جهت قبلی متوقف شد");
         return;
      }
   }

   //=================================================================
   // Pending
   //=================================================================
   if(g_entry_plan.type == ENTRY_PLAN_LIMIT ||
      g_entry_plan.type == ENTRY_PLAN_STOP)
   {
      if(!Inp_AllowPendingOrders)
         return;

      if(!IsRealTradingAllowed())
         return;

      string market_reason = "";
      if(!IsMarketOpenForSymbol(market_reason))
      {
         LogCycle(
            "MARKET_CLOSED",
            "ورود Pending لغو شد | " + market_reason);
         return;
      }

      string spread_reason = "";
      if(!IsSpreadAcceptable(spread_reason))
      {
         LogCycle(
            "SPREAD",
            "ورود Pending به دلیل اسپرد بالا لغو شد | " + spread_reason);
         return;
      }

      if(!g_risk_result.approved ||
         g_risk_result.position_volume <= 0.0)
      {
         LogCycle(
            "RISK",
            "ورود Pending به دلیل عدم تأیید ریسک لغو شد");
         return;
      }

      string pending_revalidation_reason = "";

      // V5.116: پیش از هر ثبت Pending، جهت زنده هم بررسی می‌شود؛
      // چون ممکن است OnTick ابتدایی قبل از ساخت Scenario اجرا شده باشد.
      if(g_scenario.direction == SCENARIO_DIRECTION_SELL &&
         g_last_strategy_type == STRATEGY_SELL_CONTINUATION)
      {
         double live_bid = 0.0;
         double live_ask = 0.0;
         double live_mid = 0.0;
         if(GetCurrentPrices(live_bid,live_ask,live_mid))
         {
            const bool live_conflict =
               LiveSellContinuationDirectionConflict(live_bid);

            if(live_conflict)
            {
               g_live_sell_block_scenario_id = g_scenario.id;
               LogCycle(
                  "PENDING_DIRECTION",
                  "ثبت Pending SELL در لحظه ساخت متوقف شد | برگشت قوی M5 به صعود تأیید شده است");
               Print(
                  "[SELL PENDING M5 REVERSAL BLOCK] ثبت Pending قبل از ارسال متوقف شد",
                  " | سناریو=",g_scenario.id,
                  " | Bid=",DoubleToString(live_bid,_Digits),
                  " | M15 Open=",DoubleToString(g_execution_htf_context.m15.current_bar_open,_Digits),
                  " | M30 Open=",DoubleToString(g_execution_htf_context.m30.current_bar_open,_Digits),
                  " | H1 Open=",DoubleToString(g_execution_htf_context.h1.current_bar_open,_Digits));
               return;
            }

            if(g_live_sell_block_scenario_id == g_scenario.id)
               g_live_sell_block_scenario_id = 0;
         }
      }

      if(!EntryGate_RevalidateBeforeExecution(
         g_scenario.direction,
         current_price,
         pending_revalidation_reason))
      {
         LogCycle(
            "ENTRY_REVALIDATION",
            "ثبت Pending در لحظه آماده‌سازی متوقف شد | " +
            pending_revalidation_reason);

         Print(
            "[ENTRY REVALIDATION] Pending متوقف شد | Scenario=",
            g_scenario.id,
            " | Direction=",
            ScenarioDirectionToPersian(g_scenario.direction),
            " | Price=",
            DoubleToString(current_price, _Digits),
            " | Reason=",
            pending_revalidation_reason);

         return;
      }

      int existing_scenario_exposure =
         CountScenarioExposure(g_scenario.id);

      int quota_remaining =
         MathMax(0, trades_requested - existing_scenario_exposure);

      if(quota_remaining <= 0)
      {
         LogCycle(
            "SIGNAL_QUOTA",
            "سهمیه این Scenario قبلاً تکمیل شده است | Exposure=" +
            IntegerToString(existing_scenario_exposure) +
            " | Requested=" +
            IntegerToString(trades_requested));
         return;
      }

      const int max_allowed =
         GetEffectiveMaxOpenTrades();

      const int global_exposure =
         Inp_Count_Pending_As_Risk
         ? CountTotalExposure()
         : CountOpenPositions();

      int global_slots =
         MathMax(0, max_allowed - global_exposure);

      if(global_slots <= 0)
      {
         LogCycle(
            "ENTRY",
            "ورود Pending لغو شد | ظرفیت کلی معاملات پر است");
         return;
      }

      const int pending_total = CountPendingOrders();
      const int max_pending =
         MathMax(
            TFLAB_PENDING_TRACK_LIMIT,
            MathMax(Inp_MaxOpenTrades, trades_requested));

      int pending_slots =
         MathMax(0, max_pending - pending_total);

      int orders_to_place =
         MathMin(
            quota_remaining,
            MathMin(global_slots, pending_slots));

      if(orders_to_place <= 0)
      {
         LogCycle(
            "SIGNAL_QUOTA",
            "فضای کافی برای Pendingهای سهمیه این Scenario وجود ندارد");
         return;
      }

      double real_tp_pending = 0.0;

      const double initial_pending_target =
         (g_scenario.target_2 > 0.0
          ? g_scenario.target_2
          : g_scenario.target_1);

      if(!ResolveRealTakeProfit(
         g_scenario.direction,
         g_scenario.entry_price,
         g_risk_result.position_volume,
         initial_pending_target,
         real_tp_pending))
      {
         LogCycle(
            "TP",
            "ساخت Pending لغو شد | حد سود نهایی قابل محاسبه نیست");
         return;
      }

      if(!CloseOppositePositionsAndVerify(
         g_scenario.direction))
      {
         LogCycle(
            "REVERSE",
            "Pending متوقف شد | معامله مخالف هنوز بسته نشده است");
         return;
      }

      int successful_pending = 0;

      for(int order_no = 0;
          order_no < orders_to_place;
          order_no++)
      {
         //--- ظرفیت در هر تکرار دوباره بررسی می‌شود.
         const int live_open = CountOpenPositions();
         const int live_pending = CountPendingOrders();
         const int live_global_exposure =
            Inp_Count_Pending_As_Risk
            ? CountTotalExposure()
            : live_open;

         if(live_global_exposure >= max_allowed ||
            live_pending >= max_pending)
            break;

         if(g_scenario.direction == SCENARIO_DIRECTION_SELL &&
            g_last_strategy_type == STRATEGY_SELL_CONTINUATION &&
            g_live_sell_block_scenario_id == g_scenario.id)
         {
            LogCycle(
               "PENDING_DIRECTION",
               "ساخت Pending SELL برای همان Scenario مسدود است | جهت زنده قبلاً صعودی تشخیص داده شد");
            break;
         }

         PendingOrderRecord record;
         PendingOrder_Init(record);

         if(!PendingOrder_Prepare(
            g_entry_plan,
            g_risk_result.position_volume,
            g_sl_plan.stop_price,
            real_tp_pending,
            now,
            record))
         {
            Print(
               "[MULTI PENDING] Prepare شکست خورد | شماره=",
               order_no + 1,
               " | Reason=",
               record.reason);
            continue;
         }

         // V5.116: Entry اولیه برای Rescue روی همه Pendingها حفظ می‌شود، حتی بدون Opportunity Priority.
         if(record.opportunity_reference_price<=0.0)
            record.opportunity_reference_price=record.price;

         // V5.95: این Pending مستقیماً به Opportunity حاضر متصل می‌شود تا
         // در صورت عبور قیمت، نقطه ورود آن قابل بازقیمت‌گذاری باشد.
         if(g_opportunity_capture.valid &&
            g_opportunity_capture.priority &&
            g_opportunity_capture.direction == g_scenario.direction)
         {
            record.opportunity_priority = true;
            record.opportunity_reference_price =
               g_opportunity_capture.current_price > 0.0
               ? g_opportunity_capture.current_price
               : record.price;
            record.opportunity_reaction_anchor =
               g_opportunity_capture.reaction_anchor > 0.0
               ? g_opportunity_capture.reaction_anchor
               : ((g_scenario.zone_lower > 0.0 && g_scenario.zone_upper > 0.0)
                  ? (g_scenario.zone_lower + g_scenario.zone_upper) * 0.50
                  : record.price);
            record.opportunity_reaction_width =
               g_opportunity_capture.reaction_zone_width > 0.0
               ? g_opportunity_capture.reaction_zone_width
               : ((g_scenario.zone_lower > 0.0 && g_scenario.zone_upper > 0.0)
                  ? MathMax(
                       MathAbs(g_scenario.zone_upper-g_scenario.zone_lower) * 0.50,
                       _Point*20.0)
                  : MathMax(
                       MathMax(GetCurrentATRPrice(),_Point*20.0) *
                          MathMax(0.05,Inp_Opportunity_Reaction_Zone_ATR),
                       _Point*20.0));
         }

         // V5.116: Pending معتبر می‌تواند از یک کندل M5 عبور کند.
         // عمر آن فقط تا سقف عمر Scenario و حداکثر تعداد کندل تعریف‌شده محدود می‌شود.
         const int m5_seconds =
            PeriodSeconds(Inp_TF_Setup_M5);
         int pending_life_bars = Inp_Entry_Revalidation_Max_M5_Bars;

         if(g_opportunity_capture.valid &&
            g_opportunity_capture.priority &&
            g_opportunity_capture.direction == g_scenario.direction)
         {
            pending_life_bars = MathMax(
               pending_life_bars,
               Inp_Opportunity_Pending_Max_M5_Bars);
         }

         if(m5_seconds > 0 &&
            pending_life_bars > 0)
         {
            const datetime current_m5_bar =
               iTime(_Symbol,Inp_TF_Setup_M5,0);
            const datetime pending_max_expiry =
               (current_m5_bar > 0
                ? current_m5_bar +
                  (datetime)(m5_seconds * pending_life_bars)
                : now + (datetime)(m5_seconds * pending_life_bars));

            if(record.expiry_time == 0 ||
               record.expiry_time > pending_max_expiry)
               record.expiry_time = pending_max_expiry;
         }

         if(g_scenario.expiry_time > 0 &&
            (record.expiry_time == 0 ||
             record.expiry_time > g_scenario.expiry_time))
            record.expiry_time = g_scenario.expiry_time;

         string pending_comment =
            MakeSignalTradeComment(
               scenario_exposure_before + successful_pending + 1,
               trades_requested,
               "PENDING");

          bool pending_placed =
             PendingOrder_Place(
                record,
                pending_comment,
                now);

          // Retry فقط برای سفارش دوم: اگر سرور قیمت کاملاً تکراری را رد کند،
          // Entry دوم با یک فاصله بسیار کوچک و در همان سمت معتبر دوباره ارسال می‌شود.
          if(!pending_placed && order_no > 0)
          {
             const double point =
                SymbolInfoDouble(_Symbol, SYMBOL_POINT);

             const long stops_level =
                SymbolInfoInteger(_Symbol, SYMBOL_TRADE_STOPS_LEVEL);

             const double retry_step =
                MathMax(point,
                        (double)MathMax(1, stops_level) * point * 0.25);

             if(g_scenario.direction == SCENARIO_DIRECTION_BUY)
                record.price -= retry_step;
             else
                record.price += retry_step;

             record.price = NormalizeDouble(record.price, _Digits);
             record.state = PENDING_STATE_PLANNED;
             record.active = false;
             record.ticket = 0;

             Print("[MULTI PENDING] Retry معامله دوم | Entry جدید=",
                   DoubleToString(record.price,_Digits));

             pending_placed =
                PendingOrder_Place(
                   record,
                   pending_comment,
                   now);
          }

          if(!pending_placed)
          {
             Print(
                "[MULTI PENDING] Place شکست خورد | شماره=",
                order_no + 1,
                " | Reason=",
                record.reason,
                " | Broker=",
                record.broker_comment);
             continue;
          }

         successful_pending++;

         //--- رکورد اول در Legacy State، بقیه در Pool نگه‌داری می‌شوند.
         if(g_pending.ticket == 0 || !g_pending.active)
            g_pending = record;
         else
            PendingPool_Store(record);

         Print(
            "[MULTI PENDING] معامله ",
            successful_pending,
            "/",
            orders_to_place,
            " ثبت شد | Scenario=",
            g_scenario.id,
            " | Ticket=",
            record.ticket,
            " | Price=",
            DoubleToString(record.price, _Digits),
            " | Type=",
            EntryPlanTypeToPersian(record.plan_type));
      }

      SyncPrimaryPendingState();

      if(successful_pending > 0)
      {

         const int pending_exposure_after =
            CountScenarioExposure(g_scenario.id);
         const bool pending_quota_complete =
            (pending_exposure_after >= trades_requested);

         // فقط پس از تکمیل سهمیه، EntryPlan قفل می‌شود.
         if(pending_quota_complete)
            EntryPlan_MarkSent(g_entry_plan);

         Print(
            "[SIGNAL QUOTA] Pendingهای ثبت‌شده=",
            successful_pending,
            " | ExposureAfter=",
            pending_exposure_after,
            " | Scenario=",
            g_scenario.id,
            " | سهمیه هدف=",
            trades_requested,
            " | کامل=",
            (pending_quota_complete ? "YES" : "NO"));
      }

      return;
   }

   //=================================================================
   // Market
   //=================================================================
   if(g_entry_plan.type == ENTRY_PLAN_MARKET &&
      Inp_EnableTrading &&
      ((g_scenario.direction == SCENARIO_DIRECTION_BUY && Inp_AllowBuy) ||
       (g_scenario.direction == SCENARIO_DIRECTION_SELL && Inp_AllowSell)))
   {
      string market_reason2 = "";

      if(!IsMarketOpenForSymbol(market_reason2))
      {
         LogCycle(
            "MARKET_CLOSED",
            "ورود Market لغو شد | " + market_reason2);
         return;
      }

      if(!g_risk_result.approved ||
         g_risk_result.position_volume <= 0.0)
      {
         LogCycle(
            "RISK",
            "ورود Market به دلیل عدم تأیید ریسک لغو شد");
         return;
      }

      string market_spread_reason = "";

      if(!IsSpreadAcceptable(market_spread_reason))
      {
         LogCycle(
            "SPREAD",
            "ورود Market به دلیل اسپرد بالا لغو شد | " + market_spread_reason);
         return;
      }

      if(!IsRealTradingAllowed())
      {
         LogCycle(
            "EXECUTION",
            "شرایط معاملاتی غیرفعال");
         return;
      }

      bool candle_ok = true;
      string candle_reason = "";

      const bool direct_opportunity_plan =
         (StringFind(g_entry_plan.reason,"فرصت مستقیم ورود لحظه‌ای") >= 0);

      if(Inp_Require_Candle_Confirmation && !direct_opportunity_plan)
      {
         candle_ok =
            CandleConfirmation_ConfirmsDirection(
               _Symbol,
               Inp_TF_Setup_M5,
               Inp_PinBar_Min_Wick_Ratio,
               g_scenario.direction == SCENARIO_DIRECTION_BUY,
               candle_reason);

         if(!candle_ok)
         {
            LogCycle(
               "CANDLE_CONFIRM",
               "ورود Market به تعویق افتاد: " + candle_reason);

            if(Inp_Candle_Confirm_Timeout_Minutes > 0 &&
               g_scenario.created_time > 0)
            {
               int waited_minutes =
                  (int)((now - g_scenario.created_time) / 60);

               if(waited_minutes >= Inp_Candle_Confirm_Timeout_Minutes)
               {
                  candle_ok = true;

                  LogCycle(
                     "CANDLE_CONFIRM",
                     "مهلت انتظار کندل تأییدی تمام شد - ورود بدون تأیید کندلی انجام می‌شود");
               }
            }
         }
      }

      if(!candle_ok)
         return;

      if(direct_opportunity_plan && Inp_Require_Candle_Confirmation)
      {
         Print("[V5.116 DIRECT CANDLE BRIDGE] تأیید کندل عمومی دوباره اعمال نشد؛ Opportunity قبلاً Trigger مستقل را تأیید کرده است");
      }

      if(!CloseOppositePositionsAndVerify(
         g_scenario.direction))
      {
         LogCycle(
            "REVERSE",
            "Market متوقف شد | معامله مخالف هنوز بسته نشده است");
         return;
      }

      const int requested =
         MathMax(1, Inp_Simultaneous_Trades);

      int current_scenario_exposure =
         CountScenarioExposure(g_scenario.id);

      int quota_remaining =
         MathMax(0, requested - current_scenario_exposure);

      if(quota_remaining <= 0)
      {
         LogCycle(
            "SIGNAL_QUOTA",
            "سهمیه Market این Scenario تکمیل شده است");
         return;
      }

      const int max_allowed = GetEffectiveMaxOpenTrades();
      int current_global_exposure =
         Inp_Count_Pending_As_Risk
         ? CountTotalExposure()
         : CountOpenPositions();

      int global_slots =
         MathMax(0, max_allowed - current_global_exposure);

      int trades_to_open =
         MathMin(quota_remaining, global_slots);

      if(trades_to_open <= 0)
      {
         LogCycle(
            "ENTRY",
            "Market متوقف شد | ظرفیت کلی معاملات پر است");
         return;
      }

      //--- TP بر اساس قیمت واقعی Market هر معامله محاسبه می‌شود.
      int successful_trades = 0;

      for(int trade_no = 0;
          trade_no < trades_to_open;
          trade_no++)
      {
         if((Inp_Count_Pending_As_Risk
             ? CountTotalExposure()
             : CountOpenPositions()) >= max_allowed)
            break;

         double live_bid = 0.0;
         double live_ask = 0.0;
         double live_current = 0.0;

         if(!GetCurrentPrices(
            live_bid,
            live_ask,
            live_current))
            break;

         string entry_revalidation_reason = "";

         // V5.116: Market SELL Continuation نیز همان Direction Gate زنده را دارد.
         if(g_scenario.direction == SCENARIO_DIRECTION_SELL &&
            g_last_strategy_type == STRATEGY_SELL_CONTINUATION)
         {
            if(LiveSellContinuationDirectionConflict(live_bid))
            {
               g_live_sell_block_scenario_id = g_scenario.id;
               LogCycle(
                  "ENTRY_REVALIDATION",
                  "ورود Market SELL متوقف شد | برگشت قوی M5 به صعود تأیید شده است");
               Print(
                  "[SELL M5 REVERSAL BLOCK] ورود Market SELL متوقف شد | Scenario=",
                  g_scenario.id,
                  " | Bid=",DoubleToString(live_bid,_Digits));
               break;
            }
         }

         if(!EntryGate_RevalidateBeforeExecution(
            g_scenario.direction,
            live_current,
            entry_revalidation_reason))
         {
            LogCycle(
               "ENTRY_REVALIDATION",
               "ورود Market در لحظه اجرا متوقف شد | " +
               entry_revalidation_reason);

            Print(
               "[ENTRY REVALIDATION] ورود متوقف شد | Scenario=",
               g_scenario.id,
               " | Direction=",
               ScenarioDirectionToPersian(g_scenario.direction),
               " | Price=",
               DoubleToString(live_current, _Digits),
               " | Reason=",
               entry_revalidation_reason);

            break;
         }

         string final_market_gate_reason = "";
         if(!V594_FinalAutomaticMarketEntryGate(
               g_scenario.direction,
               live_current,
               final_market_gate_reason))
         {
            LogCycle(
               "V5.116_FINAL_MARKET_GATE",
               final_market_gate_reason);
            Print(
               "[V5.116 FINAL MARKET GATE] ورود Market متوقف شد | Scenario=",
               g_scenario.id,
               " | Direction=",
               ScenarioDirectionToPersian(g_scenario.direction),
               " | Reason=",
               final_market_gate_reason);
            break;
         }

         ExecutionRequest req;
         ExecutionResult res;

         Execution_InitRequest(req);

         req.symbol = _Symbol;
         req.magic = Inp_MagicNumber;
         req.scenario_id = g_scenario.id;
         req.signal_id = g_scenario.id;
         req.order_type =
            (g_scenario.direction == SCENARIO_DIRECTION_BUY
             ? EXECUTION_BUY_MARKET
             : EXECUTION_SELL_MARKET);
         req.volume = g_risk_result.position_volume;
         req.price = live_current;
         req.stop_loss = g_sl_plan.stop_price;

         double system_tp_market =
            (g_scenario.target_2 > 0.0
             ? g_scenario.target_2
             : g_scenario.target_1);

         double real_tp_market = 0.0;

         if(!ResolveRealTakeProfit(
            g_scenario.direction,
            live_current,
            req.volume,
            system_tp_market,
            real_tp_market))
         {
            LogCycle(
               "TP",
               "ورود Market لغو شد | TP واقعی قابل محاسبه نیست");
            break;
         }

         req.take_profit = real_tp_market;
         req.comment =
            MakeSignalTradeComment(
               current_scenario_exposure + successful_trades + 1,
               requested,
               "MARKET");
         req.reason =
            "Strategy/Scenario/Setup فعال شدند | Multi-Signal Quota";

         if(Execution_SendMarket(req, res))
         {
            SignalAudit_MarkCapture(g_signal_audit,g_scenario.id,"Market اجرا شد");

            if(StringFind(g_entry_plan.reason,"فرصت مستقیم ورود لحظه‌ای") >= 0)
            {
               const double audit_atr_now =
                  (g_market_truth.move_atr_multiple > 0.0 && g_market_truth.move_size > 0.0
                   ? g_market_truth.move_size / g_market_truth.move_atr_multiple
                   : GetCurrentATRPrice());
               g_last_executed_opportunity_id =
                  SignalAudit_FindOrCreateOpportunity(
                     g_signal_audit,
                     g_scenario,
                     MathMax(audit_atr_now,_Point*10.0));
               g_last_direct_opportunity_bar =
                  iTime(_Symbol,Inp_TF_Setup_M5,1);
               g_last_direct_opportunity_anchor =
                  g_opportunity_capture.reaction_anchor;
               g_last_direct_opportunity_direction =
                  g_opportunity_capture.direction;
               Print("[V5.116 OPPORTUNITY LOCK] معامله ثبت شد | OpportunityID=",
                     (string)g_last_executed_opportunity_id,
                     " | Direction=",
                     ScenarioDirectionToPersian(g_last_direct_opportunity_direction));
            }

            successful_trades++;

            if(requested <= 1)
               g_last_executed_scenario_id = g_scenario.id;

            Print(
               "[MULTI ENTRY] معامله ",
               successful_trades,
               "/",
               trades_to_open,
               " اجرا شد | Scenario=",
               g_scenario.id,
               " | Entry=",
               DoubleToString(live_current, _Digits),
               " | Volume=",
               DoubleToString(req.volume, 4));
         }
         else
         {
            Print(
               "[MULTI ENTRY] معامله ",
               trade_no + 1,
               " ناموفق بود | Reason=",
               res.reason);
            continue;
         }
      }

      if(successful_trades > 0)
      {
         const int market_exposure_after =
            CountScenarioExposure(g_scenario.id);
         const bool market_quota_complete =
            (market_exposure_after >= requested);

         // سناریو فقط پس از تکمیل سهمیه Executed می‌شود.
         if(market_quota_complete)
         {
            g_last_executed_scenario_id = g_scenario.id;
            EntryPlan_MarkSent(g_entry_plan);

            Scenario_Trigger(
               g_scenario,
               current_price,
               now,
               "ورود Market اجرا شد");

            Scenario_MarkExecuted(
               g_scenario,
               now,
               "معاملات Market اجرا شد | تعداد=" +
               IntegerToString(successful_trades));

            AIJournal_MarkExecuted(g_scenario.id);
         }

         Print(
            "[SIGNAL QUOTA] مجموع Market اجراشده=",
            successful_trades,
            " | ExposureAfter=",
            market_exposure_after,
            " | Scenario=",
            g_scenario.id,
            " | سهمیه هدف=",
            requested,
            " | کامل=",
            (market_quota_complete ? "YES" : "NO"));
      }
   }
}

//====================================================================
// محاسبه برد/باخت متوالی
//====================================================================
void CalculateRecentStreak(
   int &consecutive_losses,
   int &consecutive_wins)
{
   consecutive_losses = 0;
   consecutive_wins = 0;

   if(!HistorySelect(
      0,
      TimeCurrent()))
      return;

   int total =
      HistoryDealsTotal();

   if(total <= 0)
      return;

   double results[];
   datetime times[];

   ArrayResize(results, 0);
   ArrayResize(times, 0);

   for(int i = 0;
       i < total;
       i++)
   {
      ulong ticket =
         HistoryDealGetTicket(i);

      if(ticket == 0)
         continue;

      if(HistoryDealGetString(
            ticket,
            DEAL_SYMBOL) !=
         _Symbol)
         continue;

      if((ulong)HistoryDealGetInteger(
            ticket,
            DEAL_MAGIC) !=
         Inp_MagicNumber)
         continue;

      if((ENUM_DEAL_ENTRY)
         HistoryDealGetInteger(
            ticket,
            DEAL_ENTRY) !=
         DEAL_ENTRY_OUT)
         continue;

      double v =
         HistoryDealGetDouble(
            ticket,
            DEAL_PROFIT) +
         HistoryDealGetDouble(
            ticket,
            DEAL_SWAP) +
         HistoryDealGetDouble(
            ticket,
            DEAL_COMMISSION);

      int n =
         ArraySize(results);

      ArrayResize(
         results,
         n + 1);

      ArrayResize(
         times,
         n + 1);

      results[n] = v;

      times[n] =
         (datetime)
         HistoryDealGetInteger(
            ticket,
            DEAL_TIME);
   }

   int count =
      ArraySize(results);

   if(count == 0)
      return;

   for(int i = 0;
       i < count - 1;
       i++)
   {
      for(int j = 0;
          j < count - 1 - i;
          j++)
      {
         if(times[j] >
            times[j + 1])
         {
            datetime tt =
               times[j];

            times[j] =
               times[j + 1];

            times[j + 1] =
               tt;

            double rr =
               results[j];

            results[j] =
               results[j + 1];

            results[j + 1] =
               rr;
         }
      }
   }

   bool streak_is_loss = false;
   bool streak_started = false;
   int streak_count = 0;

   for(int i = count - 1;
       i >= 0;
       i--)
   {
      if(results[i] == 0.0)
         continue;

      bool is_loss =
         (results[i] < 0.0);

      if(!streak_started)
      {
         streak_started = true;
         streak_is_loss =
            is_loss;

         streak_count = 1;
      }
      else
      if(is_loss ==
         streak_is_loss)
      {
         streak_count++;
      }
      else
      {
         break;
      }
   }

   if(streak_is_loss)
      consecutive_losses =
         streak_count;
   else
      consecutive_wins =
         streak_count;
}

//====================================================================
// به‌روزرسانی ریسک
//====================================================================
void UpdateRisk()
{
   Risk_InitResult(g_risk_result);

   if(g_scenario.id == 0 ||
      !Scenario_IsValid(g_scenario) ||
      g_sl_plan.stop_price <= 0.0 ||
      g_scenario.target_1 <= 0.0)
      return;

   double fixed_volume = Inp_Fixed_Lot_Size;
   if(fixed_volume <= 0.0)
      fixed_volume = 0.01;

   const double min_volume = SymbolInfoDouble(_Symbol,SYMBOL_VOLUME_MIN);
   const double max_volume = SymbolInfoDouble(_Symbol,SYMBOL_VOLUME_MAX);
   const double step_volume = SymbolInfoDouble(_Symbol,SYMBOL_VOLUME_STEP);

   fixed_volume = MathMax(fixed_volume,min_volume);
   if(max_volume > 0.0)
      fixed_volume = MathMin(fixed_volume,max_volume);
   if(step_volume > 0.0)
      fixed_volume = MathFloor((fixed_volume+1e-12)/step_volume)*step_volume;
   fixed_volume = MathMax(fixed_volume,min_volume);

   g_risk_result.status = RISK_STATUS_APPROVED;
   g_risk_result.approved = true;
   g_risk_result.risk_money = 0.0;
   g_risk_result.risk_percent = 0.0;
   g_risk_result.reward_money = 0.0;
   g_risk_result.rr = 0.0;
   g_risk_result.stop_distance_price = MathAbs(g_scenario.entry_price-g_sl_plan.stop_price);
   g_risk_result.stop_distance_points =
      (g_risk_result.stop_distance_price > 0.0 && _Point > 0.0
       ? g_risk_result.stop_distance_price/_Point
       : 0.0);
   g_risk_result.position_volume = fixed_volume;
   g_risk_result.reason = "ریسک سرمایه‌ای غیرفعال؛ حجم ثابت 0.01 لات";

   Print("[RISK OFF] حجم ثابت=",DoubleToString(g_risk_result.position_volume,2),
         " | سرمایه=",DoubleToString(AccountInfoDouble(ACCOUNT_BALANCE),2),
         " | محدودیت درصد ریسک در اجرا اعمال نمی‌شود");
}

//====================================================================
// حجم اولیه پوزیشن
//====================================================================
double GetPositionInitialVolume(
   const ulong position_id,
   const double fallback)
{
   if(position_id == 0 ||
      !HistorySelectByPosition(
         position_id))
      return fallback;

   double volume = 0.0;

   uint total =
      (uint)HistoryDealsTotal();

   for(uint i = 0;
       i < total;
       i++)
   {
      const ulong deal =
         HistoryDealGetTicket(i);

      if(deal == 0)
         continue;

      if(HistoryDealGetInteger(
            deal,
            DEAL_ENTRY) ==
         DEAL_ENTRY_IN)
      {
         volume +=
            HistoryDealGetDouble(
               deal,
               DEAL_VOLUME);
      }
   }

   return
      (volume > 0.0
       ? volume
       : fallback);
}

//====================================================================
// ابزارهای مدیریت دقیقه‌ای
//====================================================================
int DynamicTP_FindState(const ulong position_id)
{
   for(int i=0;i<ArraySize(g_dynamic_tp_tracker);i++)
      if(g_dynamic_tp_tracker[i].position_id==position_id)
         return i;
   return -1;
}

int DynamicTP_GetOrCreateState(const ulong position_id,
                               const ulong ticket,
                               const double entry_price,
                               const double current_tp,
                               const double current_sl)
{
   if(position_id==0)
      return -1;

   int idx=DynamicTP_FindState(position_id);
   if(idx>=0)
   {
      g_dynamic_tp_tracker[idx].ticket=ticket;
      g_dynamic_tp_tracker[idx].last_seen=TimeCurrent();
      return idx;
   }

   int n=ArraySize(g_dynamic_tp_tracker);
   ArrayResize(g_dynamic_tp_tracker,n+1);
   g_dynamic_tp_tracker[n].position_id=position_id;
   g_dynamic_tp_tracker[n].ticket=ticket;
   g_dynamic_tp_tracker[n].entry_price=entry_price;
   g_dynamic_tp_tracker[n].initial_tp=current_tp;
   g_dynamic_tp_tracker[n].initial_sl=current_sl;
   g_dynamic_tp_tracker[n].initial_risk_distance=(current_sl>0.0 && entry_price>0.0)
      ? MathAbs(entry_price-current_sl) : 0.0;
   g_dynamic_tp_tracker[n].max_favorable_price=entry_price;
   g_dynamic_tp_tracker[n].profit_lock_armed=false;
   g_dynamic_tp_tracker[n].first_seen=TimeCurrent();
   g_dynamic_tp_tracker[n].last_seen=TimeCurrent();

   return n;
}

void DynamicTP_Cleanup()
{
   datetime now=TimeCurrent();
   for(int i=ArraySize(g_dynamic_tp_tracker)-1;i>=0;i--)
   {
      bool found=false;
      for(int j=0;j<PositionsTotal();j++)
      {
         ulong ticket=PositionGetTicket(j);
         if(ticket==0 || !PositionSelectByTicket(ticket))
            continue;
         if(PositionGetString(POSITION_SYMBOL)!=_Symbol)
            continue;
         if((ulong)PositionGetInteger(POSITION_MAGIC)!=Inp_MagicNumber)
            continue;
         if((ulong)PositionGetInteger(POSITION_IDENTIFIER)==g_dynamic_tp_tracker[i].position_id)
         { found=true; break; }
      }
      if(!found && (now-g_dynamic_tp_tracker[i].last_seen)>120)
      {
         int last=ArraySize(g_dynamic_tp_tracker)-1;
         if(i!=last)
            g_dynamic_tp_tracker[i]=g_dynamic_tp_tracker[last];
         ArrayResize(g_dynamic_tp_tracker,last);
      }
   }
}

double ClampScore(const double value)
{
   return MathMax(0.0,MathMin(100.0,value));
}

void CalculateMinuteScores()
{
   g_minute_monitor.valid=false;
   g_minute_monitor.analysis_time=TimeCurrent();
   MarketRegime_Reset(g_minute_monitor.m1_regime);
   MarketTruth_Reset(g_minute_monitor.m5_truth);
   g_minute_monitor.buy_continuation=50.0;
   g_minute_monitor.sell_continuation=50.0;
   g_minute_monitor.buy_reversal=0.0;
   g_minute_monitor.sell_reversal=0.0;

   bool regime_ok=false;
   if(Inp_Use_M1_Monitor)
      regime_ok=MarketRegime_Analyze(_Symbol,Inp_TF_Monitor_M1,g_minute_monitor.m1_regime);

   bool truth_ok=false;
   if(Inp_Use_Market_Truth)
      truth_ok=MarketTruth_Analyze(_Symbol,Inp_TF_Setup_M5,Inp_Market_Truth_Lookback,g_minute_monitor.m5_truth);

   if(!regime_ok && !truth_ok)
      return;

   double buy=50.0;
   double sell=50.0;

   if(regime_ok && g_minute_monitor.m1_regime.valid)
   {
      if(g_minute_monitor.m1_regime.regime==MARKET_REGIME_UPTREND)
      {
         buy += MathMin(30.0,g_minute_monitor.m1_regime.confidence*0.35);
         sell -= MathMin(35.0,g_minute_monitor.m1_regime.confidence*0.35);
      }
      else if(g_minute_monitor.m1_regime.regime==MARKET_REGIME_DOWNTREND)
      {
         sell += MathMin(30.0,g_minute_monitor.m1_regime.confidence*0.35);
         buy -= MathMin(35.0,g_minute_monitor.m1_regime.confidence*0.35);
      }
      else if(g_minute_monitor.m1_regime.regime==MARKET_REGIME_TRANSITION)
      {
         buy -= 5.0;
         sell -= 5.0;
      }
   }

   if(truth_ok && g_minute_monitor.m5_truth.valid)
   {
      if(g_minute_monitor.m5_truth.direction==MARKET_TRUTH_BUY)
      {
         buy += 18.0;
         sell -= 18.0;
      }
      else if(g_minute_monitor.m5_truth.direction==MARKET_TRUTH_SELL)
      {
         sell += 18.0;
         buy -= 18.0;
      }

      if(g_minute_monitor.m5_truth.reversal_candidate)
      {
         if(g_minute_monitor.m5_truth.direction==MARKET_TRUTH_BUY)
            sell += 10.0;
         else if(g_minute_monitor.m5_truth.direction==MARKET_TRUTH_SELL)
            buy += 10.0;
      }
   }

   g_minute_monitor.buy_continuation=ClampScore(buy);
   g_minute_monitor.sell_continuation=ClampScore(sell);

   g_minute_monitor.buy_reversal=ClampScore(100.0-buy);
   g_minute_monitor.sell_reversal=ClampScore(100.0-sell);

   // اگر M30 اصلی سناریو جهت مخالف معامله را تأیید کرده باشد، امتیاز برگشت قوی‌تر می‌شود.
   if(g_regime.valid)
   {
      if(g_regime.regime==MARKET_REGIME_DOWNTREND)
         g_minute_monitor.buy_reversal=ClampScore(g_minute_monitor.buy_reversal+20.0*(g_regime.confidence/100.0));
      if(g_regime.regime==MARKET_REGIME_UPTREND)
         g_minute_monitor.sell_reversal=ClampScore(g_minute_monitor.sell_reversal+20.0*(g_regime.confidence/100.0));
   }

   g_minute_monitor.valid=true;
}

bool EnsureMinuteMarketMonitorFresh()
{
   if(!Inp_Use_M1_Monitor && !Inp_Use_Market_Truth)
      return false;

   if(!g_minute_monitor.valid ||
      (TimeCurrent()-g_minute_monitor.analysis_time)>=MathMax(1,Inp_Monitor_Update_Seconds))
      CalculateMinuteScores();

   return g_minute_monitor.valid;
}

double MinuteContinuationScore(const bool is_buy)
{
   return is_buy ? g_minute_monitor.buy_continuation : g_minute_monitor.sell_continuation;
}

double MinuteReversalScore(const bool is_buy)
{
   return is_buy ? g_minute_monitor.buy_reversal : g_minute_monitor.sell_reversal;
}

bool ClosedM5BarsConfirmOppositeDirection(const bool old_is_buy,const int requested_bars)
{
   int bars_required=MathMax(2,requested_bars);
   double atr=GetCurrentATRPrice();
   double min_body=(atr>0.0) ? atr*MathMax(0.0,Inp_Reversal_Confirm_Min_Bar_ATR) : 0.0;
   double previous_close=0.0;
   int confirmed=0;

   for(int shift=1; shift<=bars_required; ++shift)
   {
      double o=iOpen(_Symbol,Inp_TF_Setup_M5,shift);
      double c=iClose(_Symbol,Inp_TF_Setup_M5,shift);
      datetime t=iTime(_Symbol,Inp_TF_Setup_M5,shift);
      if(t<=0 || o<=0.0 || c<=0.0)
         return false;

      bool opposite=old_is_buy ? (c<o) : (c>o);
      double body=MathAbs(c-o);
      if(!opposite || body<min_body)
         return false;

      if(previous_close>0.0)
      {
         // shift=1 جدیدترین کندل بسته‌شده است؛ کندل قبلی باید در همان جهت
         // قرار داشته باشد: برای SELL-reversal، Close قدیمی بالاتر است؛
         // برای BUY-reversal، Close قدیمی پایین‌تر است.
         if(old_is_buy && c<=previous_close)
            return false;
         if(!old_is_buy && c>=previous_close)
            return false;
      }

      previous_close=c;
      confirmed++;
   }

   return confirmed>=bars_required;
}

bool ConfirmedPositionReversal(const bool is_buy,const double reversal,const double continuation);

bool NewScenarioConfirmsReverseFromPosition(const bool old_is_buy)
{
   if(g_scenario.id<=0) return false;
   if(g_scenario.direction==SCENARIO_DIRECTION_NONE) return false;

   bool new_is_buy=(g_scenario.direction==SCENARIO_DIRECTION_BUY);
   if(old_is_buy==new_is_buy)
      return false;

   if(!EnsureMinuteMarketMonitorFresh())
      return false;

   double score=MinuteReversalScore(old_is_buy);

   // سناریوی جدید باید واقعاً خلاف معامله موجود باشد و امتیاز برگشت به آستانه برسد.
   if(score < Inp_Reversal_Exit_Min_Confidence)
      return false;

   bool truth_support=true;
   if(g_minute_monitor.m5_truth.valid)
   {
      if(old_is_buy && g_minute_monitor.m5_truth.direction!=MARKET_TRUTH_SELL)
         truth_support=false;
      if(!old_is_buy && g_minute_monitor.m5_truth.direction!=MARKET_TRUTH_BUY)
         truth_support=false;
   }

   // V5.116: تغییر سناریو فقط بعد از دو کندل بسته‌شده M5 متوالی معتبر است.
   if(!ClosedM5BarsConfirmOppositeDirection(old_is_buy,Inp_Reversal_Confirm_M5_Bars))
      return false;

   return truth_support;
}

bool CloseAllPositionsOppositeToScenario(const ENUM_SCENARIO_DIRECTION new_direction)
{
   bool new_is_buy=(new_direction==SCENARIO_DIRECTION_BUY);
   bool all_ok=true;
   int closed=0;

   for(int i=PositionsTotal()-1;i>=0;i--)
   {
      ulong ticket=PositionGetTicket(i);
      if(ticket==0 || !PositionSelectByTicket(ticket))
         continue;
      if(PositionGetString(POSITION_SYMBOL)!=_Symbol)
         continue;
      if((ulong)PositionGetInteger(POSITION_MAGIC)!=Inp_MagicNumber)
         continue;

      bool pos_is_buy=(PositionGetInteger(POSITION_TYPE)==POSITION_TYPE_BUY);
      if(pos_is_buy==new_is_buy)
         continue;

      double volume=PositionGetDouble(POSITION_VOLUME);
      if(volume<=0.0)
         continue;

      if(IsRealTradingAllowed() &&
         ClosePositionVolume(ticket,_Symbol,pos_is_buy,volume,"TFlab Confirmed Reversal Close"))
      {
         closed++;
         Print("[REVERSAL CLOSE] تمام معاملات جهت قبلی بسته شد | Ticket=",ticket," | NewDirection=",ScenarioDirectionToPersian(new_direction));
      }
      else
      {
         all_ok=false;
      }
   }

   Print("[REVERSAL CLOSE] نتیجه | Closed=",closed," | AllOK=",(all_ok?"YES":"NO"));
   return all_ok && CountOpenPositionsByDirection(new_is_buy ? SCENARIO_DIRECTION_SELL : SCENARIO_DIRECTION_BUY)==0;
}

bool HasOppositeOpenPositionForScenarioDirection(const ENUM_SCENARIO_DIRECTION new_direction)
{
   bool new_is_buy=(new_direction==SCENARIO_DIRECTION_BUY);
   for(int i=0;i<PositionsTotal();i++)
   {
      ulong ticket=PositionGetTicket(i);
      if(ticket==0 || !PositionSelectByTicket(ticket)) continue;
      if(PositionGetString(POSITION_SYMBOL)!=_Symbol) continue;
      if((ulong)PositionGetInteger(POSITION_MAGIC)!=Inp_MagicNumber) continue;
      bool pos_is_buy=(PositionGetInteger(POSITION_TYPE)==POSITION_TYPE_BUY);
      if(pos_is_buy!=new_is_buy) return true;
   }
   return false;
}

bool CloseOldSideBeforeReverseEntry()
{
   if(!Inp_Enable_Confirmed_Reversal_Close)
      return true;

   if(g_scenario.id<=0 || !Scenario_IsValid(g_scenario))
      return true;

   // فقط وقتی ربات واقعاً برنامه ورود جدید دارد، معاملات جهت قبلی بسته می‌شوند.
   if(!g_entry_plan.executable ||
      g_entry_plan.direction!=g_scenario.direction)
      return true;

   bool new_is_buy=(g_scenario.direction==SCENARIO_DIRECTION_BUY);
   bool has_old=false;

   for(int i=0;i<PositionsTotal();i++)
   {
      ulong ticket=PositionGetTicket(i);
      if(ticket==0 || !PositionSelectByTicket(ticket)) continue;
      if(PositionGetString(POSITION_SYMBOL)!=_Symbol) continue;
      if((ulong)PositionGetInteger(POSITION_MAGIC)!=Inp_MagicNumber) continue;
      bool pos_is_buy=(PositionGetInteger(POSITION_TYPE)==POSITION_TYPE_BUY);
      if(pos_is_buy!=new_is_buy) { has_old=true; break; }
   }

   if(!has_old)
      return true;

   if(!EnsureMinuteMarketMonitorFresh())
      return false;

   bool confirmed_for_at_least_one=false;
   for(int i=0;i<PositionsTotal();i++)
   {
      ulong ticket=PositionGetTicket(i);
      if(ticket==0 || !PositionSelectByTicket(ticket)) continue;
      if(PositionGetString(POSITION_SYMBOL)!=_Symbol) continue;
      if((ulong)PositionGetInteger(POSITION_MAGIC)!=Inp_MagicNumber) continue;
      bool pos_is_buy=(PositionGetInteger(POSITION_TYPE)==POSITION_TYPE_BUY);
      if(pos_is_buy==new_is_buy) continue;
      if(NewScenarioConfirmsReverseFromPosition(pos_is_buy))
      { confirmed_for_at_least_one=true; break; }
   }

   if(!confirmed_for_at_least_one)
   {
      LogCycle("REVERSE","سیگنال معکوس وجود دارد اما اطمینان برگشت هنوز به حد لازم نرسیده است");
      return false;
   }

   return CloseAllPositionsOppositeToScenario(g_scenario.direction);
}

double DynamicTP_ComputeNewTarget(const double initial_tp)
{
   // حد سود اصلی ثابت می‌ماند؛ محافظت قبل از TP به موتور برگشت سپرده شده است.
   if(initial_tp<=0.0)
      return 0.0;
   return NormalizeDouble(initial_tp,_Digits);
}

//====================================================================
// محافظت از سود قبل از برگشت
//====================================================================
bool TryProfitProtection(const ulong ticket,
                         const bool is_buy,
                         const double entry,
                         const double current,
                         const double current_sl,
                         const double initial_tp,
                         const double max_favorable_price,
                         bool &profit_lock_armed,
                         string &action_code,
                         string &action_reason)
{
   action_code="";
   action_reason="";
   if(!Inp_Enable_Profit_Protection || profit_lock_armed || ticket==0 || entry<=0.0 || current<=0.0 || initial_tp<=0.0)
      return false;

   double target_distance=MathAbs(initial_tp-entry);
   if(target_distance<=_Point)
      return false;

   double progress_fraction=MathMax(0.50,MathMin(0.95,Inp_Profit_Protection_TP_Progress_Fraction));
   double lock_fraction=MathMax(0.05,MathMin(0.60,Inp_Profit_Protection_Lock_TP_Fraction));
   double favorable_move=is_buy
      ? MathMax(0.0,max_favorable_price-entry)
      : MathMax(0.0,entry-max_favorable_price);
   if(favorable_move+_Point < target_distance*progress_fraction)
      return false;

   // اگر SL فعلی از سطح قفل سود هم محافظتی‌تر است، هرگز آن را عقب نمی‌بریم.
   double lock_distance=target_distance*lock_fraction;
   double new_sl=NormalizeDouble(is_buy ? entry+lock_distance : entry-lock_distance,_Digits);
   bool existing_is_better=is_buy
      ? (current_sl>0.0 && current_sl>=new_sl-_Point)
      : (current_sl>0.0 && current_sl<=new_sl+_Point);
   if(existing_is_better)
   {
      profit_lock_armed=true;
      return false;
   }

   // اگر قیمت قبل از نصب SL از سطح قفل عبور کرده باشد، SL نامعتبر نمی‌فرستیم.
   // موتور برگشت ساختاری مسئول تصمیم خروج در همین چرخه است.
   double min_distance=(double)MathMax(SymbolInfoInteger(_Symbol,SYMBOL_TRADE_STOPS_LEVEL),
                                       SymbolInfoInteger(_Symbol,SYMBOL_TRADE_FREEZE_LEVEL))*_Point;
   min_distance=MathMax(min_distance,2.0*_Point);
   bool price_room=is_buy ? (current>new_sl+min_distance) : (current<new_sl-min_distance);
   if(!price_room)
   {
      action_code="PROFIT_LOCK_SKIPPED";
      action_reason="قیمت پس از طی‌شدن دوسوم مسیر از سطح قفل عبور کرده یا فاصله مجاز بروکر کافی نیست؛ حد ضرر عقب‌گرد داده نشد";
      return false;
   }

   if(!SL_IsBrokerValidForPosition(ticket,_Symbol,new_sl) || !IsRealTradingAllowed())
      return false;

   if(!PositionSelectByTicket(ticket))
      return false;
   double current_tp=PositionGetDouble(POSITION_TP);
   if(!SL_ModifyPositionSLTP(ticket,_Symbol,new_sl,current_tp))
      return false;

   profit_lock_armed=true;
   action_code="PROFIT_LOCK_ONCE";
   action_reason="پس از طی‌شدن دوسوم فاصله حد سود اولیه، حد ضرر فقط یک‌بار در یک‌سوم مسیر سود قفل شد؛ دنبال‌کردن قیمت غیرفعال است";
   Print("[PROFIT LOCK ONCE] Ticket=",ticket,
         " | TargetDistance=",DoubleToString(target_distance,_Digits),
         " | Progress=",DoubleToString(favorable_move/target_distance,3),
         " | NewSL=",DoubleToString(new_sl,_Digits));
   return true;
}

//====================================================================
// کنترل زیان شناور و جلوگیری از مصرف کامل SL بزرگ
//====================================================================
bool TryAdaptiveLossProtection(const ulong ticket,
                                const bool is_buy,
                                const double entry,
                                const double current,
                                const double current_sl,
                                const double original_sl,
                                const double continuation,
                                const double reversal)
{
   if(!Inp_Enable_Adaptive_Loss_Protection)
      return false;

   if(ticket == 0 || entry <= 0.0 || current <= 0.0)
      return false;

   double atr = GetCurrentATRPrice();
   if(atr <= 0.0)
      return false;

   double adverse_move = is_buy
      ? MathMax(0.0, entry - current)
      : MathMax(0.0, current - entry);

   if(adverse_move <= 0.0)
      return false;

   double risk_distance = original_sl > 0.0
      ? MathAbs(entry - original_sl)
      : MathAbs(entry - current_sl);

   if(risk_distance <= 0.0)
      risk_distance = atr;

   double soft_trigger = MathMax(
      atr * Inp_Adverse_Move_ATR_Trigger,
      risk_distance * Inp_Adverse_Move_Risk_Fraction);

   double hard_trigger = MathMax(
      atr * Inp_Adverse_Move_Hard_ATR_Trigger,
      risk_distance * Inp_Adverse_Move_Hard_Risk_Fraction);

   bool truth_reverse = false;
   if(g_minute_monitor.m5_truth.valid)
   {
      truth_reverse =
         (is_buy && g_minute_monitor.m5_truth.direction == MARKET_TRUTH_SELL) ||
         (!is_buy && g_minute_monitor.m5_truth.direction == MARKET_TRUTH_BUY);
   }

   bool soft_confirmed =
      truth_reverse ||
      (reversal >= Inp_Adverse_Move_Min_Reversal_Confidence &&
       continuation <= Inp_Adverse_Move_Max_Continuation);

   bool m5_two_bar_reversal =
      ClosedM5BarsConfirmOppositeDirection(is_buy,Inp_Reversal_Confirm_M5_Bars);

   double early_guard_trigger = MathMax(
      atr * MathMax(0.0,Inp_Early_Loss_Guard_ATR),
      risk_distance * MathMax(0.0,Inp_Early_Loss_Guard_Risk_Fraction));

   bool early_loss_guard =
      (adverse_move >= early_guard_trigger &&
       m5_two_bar_reversal &&
       truth_reverse &&
       reversal >= Inp_Early_Loss_Guard_Reversal &&
       continuation <= Inp_Adverse_Move_Max_Continuation);

   bool should_close =
      (adverse_move >= hard_trigger) ||
      (adverse_move >= soft_trigger && soft_confirmed) ||
      early_loss_guard;

   if(!should_close || !IsRealTradingAllowed())
      return false;

   double volume = PositionGetDouble(POSITION_VOLUME);
   if(volume <= 0.0)
      return false;

   if(ClosePositionVolume(ticket, _Symbol, is_buy, volume,
                          "TFlab Adaptive Loss Protection"))
   {
      Print("[ADAPTIVE LOSS] معامله قبل از مصرف SL بزرگ بسته شد",
            " | Ticket=", ticket,
            " | AdverseMove=", DoubleToString(adverse_move, _Digits),
            " | Soft=", DoubleToString(soft_trigger, _Digits),
            " | Hard=", DoubleToString(hard_trigger, _Digits),
            " | Continuation=", DoubleToString(continuation, 1),
            " | Reversal=", DoubleToString(reversal, 1),
            " | TruthReverse=", (truth_reverse ? "YES" : "NO"),
            " | M5TwoBar=", (m5_two_bar_reversal ? "YES" : "NO"),
            " | EarlyGuard=", (early_loss_guard ? "YES" : "NO"));
      return true;
   }

   return false;
}

//====================================================================
// تشخیص شکست ساختار کوتاه‌مدت M1 برای موتور برگشت؛ از کندل آینده استفاده نمی‌شود.
// برای BUY، شکست کف چند کندل اخیر و برای SELL، شکست سقف چند کندل اخیر بررسی می‌شود.
//====================================================================
bool ReversalEngine_M1StructureBreak(const bool old_is_buy,
                                     const double current,
                                     const double atr,
                                     bool &live_break,
                                     bool &closed_break,
                                     double &structure_level)
{
   live_break=false;
   closed_break=false;
   structure_level=0.0;
   ENUM_TIMEFRAMES tf=Inp_TF_Monitor_M1;
   int lookback=MathMax(2,MathMin(10,Inp_Reversal_Engine_M1_Lookback));
   if(Bars(_Symbol,tf)<lookback+3 || current<=0.0)
      return false;

   double buffer=MathMax(0.0,atr)*MathMax(0.0,Inp_Reversal_Engine_M1_Buffer_ATR);
   double level=old_is_buy ? 1.0e100 : 0.0;
   for(int shift=2;shift<=lookback+1;shift++)
   {
      double value=old_is_buy ? iLow(_Symbol,tf,shift) : iHigh(_Symbol,tf,shift);
      if(value<=0.0)
         return false;
      level=old_is_buy ? MathMin(level,value) : MathMax(level,value);
   }
   double last_closed=iClose(_Symbol,tf,1);
   if(level<=0.0 || last_closed<=0.0)
      return false;
   structure_level=level;

   if(old_is_buy)
   {
      live_break=(current<level-buffer);
      // بسته‌شدن کندل باید هنوز با قیمت اجرایی تأیید شده باشد؛ شکستِ پس‌گرفته‌شده نادیده گرفته می‌شود.
      closed_break=(last_closed<level-buffer && current<=level+buffer);
   }
   else
   {
      live_break=(current>level+buffer);
      closed_break=(last_closed>level+buffer && current>=level-buffer);
   }
   return (live_break || closed_break);
}

bool TryProtectiveReversalExit(const ulong ticket,
                               const bool is_buy,
                               const datetime position_time,
                               const double entry,
                               const double current,
                               const double continuation,
                               const double reversal,
                               const double max_favorable_price,
                               const double initial_risk_distance,
                               string &hold_reason)
{
   hold_reason="";
   if(!Inp_Enable_Reversal_Exit || ticket==0 || entry<=0.0 || current<=0.0)
      return false;

   const double atr=GetCurrentATRPrice();
   if(atr<=0.0)
      return false;

   // V5.92 behavior is the baseline: a score wobble or an M1-only break is not a reversal.
   // Require a materially dominant reversal score and an opposite M5 Market Truth.
   const double confidence=MathMax(78.0,MathMax(50.0,MathMin(95.0,Inp_Reversal_Engine_Min_Confidence)));
   const double score_lead=MathMax(15.0,MathMax(0.0,Inp_Reversal_Engine_Min_Score_Lead));
   const bool score_confirmed=(reversal>=confidence && reversal>=continuation+score_lead);

   if(!score_confirmed)
   {
      if(reversal>=confidence-10.0)
         hold_reason="REVERSAL_HOLD: امتیاز برگشت یا برتری نسبت به ادامه کافی نیست؛ Reverse="+
                     DoubleToString(reversal,1)+" Continue="+DoubleToString(continuation,1);
      return false;
   }

   const bool truth_reverse=(g_minute_monitor.m5_truth.valid &&
      ((is_buy && g_minute_monitor.m5_truth.direction==MARKET_TRUTH_SELL) ||
       (!is_buy && g_minute_monitor.m5_truth.direction==MARKET_TRUTH_BUY)));

   bool live_m1_break=false, closed_m1_break=false;
   double structure_level=0.0;
   const bool any_structure_break=ReversalEngine_M1StructureBreak(
      is_buy,current,atr,live_m1_break,closed_m1_break,structure_level);

   const double truth_move_atr=(g_minute_monitor.m5_truth.valid
      ? g_minute_monitor.m5_truth.move_atr_multiple : 0.0);
   const bool strong_truth_move=(truth_reverse &&
      g_minute_monitor.m5_truth.strong_market_move && truth_move_atr>=0.50);

   const double move_against=is_buy ? MathMax(0.0,entry-current) : MathMax(0.0,current-entry);
   const double required_adverse=MathMax(
      atr*MathMax(0.50,Inp_Reversal_Exit_Min_ATR_Multiple),
      MathMax(70.0,Inp_Reversal_Exit_Min_Points)*_Point);
   const bool moved_against=(move_against>=required_adverse);

   const double peak_move=(max_favorable_price>0.0
      ? (is_buy ? MathMax(0.0,max_favorable_price-entry) : MathMax(0.0,entry-max_favorable_price))
      : 0.0);
   const double pullback_from_peak=(max_favorable_price>0.0
      ? (is_buy ? MathMax(0.0,max_favorable_price-current) : MathMax(0.0,current-max_favorable_price))
      : 0.0);
   const double pullback_threshold=MathMax(
      atr*MathMax(0.30,Inp_Reversal_Exit_Peak_Pullback_ATR),
      MathMax(peak_move*0.15,MathMax(35.0,Inp_Reversal_Exit_Peak_Pullback_Min_Points)*_Point));
   const bool confirmed_peak_turn=(peak_move>=atr*0.45 && pullback_from_peak>=pullback_threshold);

   // Preserve the strict V5.92 safeguard for an existing BUY: require a fresh,
   // executable, high-quality SELL scenario before early closure.
   bool fresh_opposite_scenario=true;
   if(is_buy)
   {
      fresh_opposite_scenario=(g_scenario.id>0 &&
         g_scenario.direction==SCENARIO_DIRECTION_SELL &&
         g_scenario.created_time>position_time &&
         g_entry_plan.executable &&
         g_entry_plan.direction==SCENARIO_DIRECTION_SELL &&
         g_scenario.quality_value>=Inp_Buy_ProtectiveReversal_Min_Scenario_Quality &&
         (g_scenario.status==SCENARIO_STATUS_VALID ||
          g_scenario.status==SCENARIO_STATUS_ARMED ||
          g_scenario.status==SCENARIO_STATUS_TRIGGERED ||
          g_scenario.status==SCENARIO_STATUS_EXECUTED));
   }

   // Normal exit: opposite M5 Truth plus either a closed M1 structure break,
   // a strong Truth impulse, or a sizeable peak pullback backed by a closed M1 break.
   const bool structure_or_truth_confirmed=(closed_m1_break || strong_truth_move ||
                                            (confirmed_peak_turn && closed_m1_break));
   const bool movement_confirmed=(moved_against || strong_truth_move ||
                                  (confirmed_peak_turn && closed_m1_break));

   // Exceptional path only for a very high score and a closed-bar structural break;
   // live/incomplete M1 candles and a peak pullback alone can never close a position.
   const bool emergency_confirmed=(reversal>=96.0 && reversal>=continuation+25.0 &&
                                   closed_m1_break &&
                                   (move_against>=required_adverse*0.50 || confirmed_peak_turn));
   const bool normal_confirmed=(truth_reverse && fresh_opposite_scenario &&
                                 structure_or_truth_confirmed && movement_confirmed);
   const bool should_close=(normal_confirmed || emergency_confirmed);

   if(!should_close)
   {
      if(!truth_reverse && !emergency_confirmed)
         hold_reason="REVERSAL_HOLD: Truth مخالف نیست؛ شکست زنده M1 به‌تنهایی مجوز خروج نیست";
      else if(is_buy && !fresh_opposite_scenario)
         hold_reason="REVERSAL_HOLD: سناریوی SELL تازه و قابل‌اجرا برای خروج BUY تأیید نشده است";
      else if(!closed_m1_break && !strong_truth_move)
         hold_reason="REVERSAL_HOLD: کندل بسته‌شده M1 یا حرکت قوی Truth تأییدکننده وجود ندارد";
      else
         hold_reason="REVERSAL_HOLD: حرکت واقعی خلاف جهت هنوز از آستانه محافظت عبور نکرده است";
      return false;
   }

   if(!IsRealTradingAllowed())
   {
      hold_reason="REVERSAL_HOLD: اجرای واقعی مجاز نیست";
      return false;
   }
   if(!PositionSelectByTicket(ticket))
      return false;
   const double volume=PositionGetDouble(POSITION_VOLUME);
   if(volume<=0.0)
      return false;

   const string close_reason="TFlab Confirmed Trend Reversal Exit";
   if(ClosePositionVolume(ticket,_Symbol,is_buy,volume,close_reason))
   {
      Print("[CONFIRMED TREND REVERSAL] معامله بسته شد",
            " | Ticket=",ticket,
            " | Reverse=",DoubleToString(reversal,1),
            " | Continue=",DoubleToString(continuation,1),
            " | ScoreLead=",DoubleToString(reversal-continuation,1),
            " | TruthOpposite=",(truth_reverse?"YES":"NO"),
            " | M1ClosedBreak=",(closed_m1_break?"YES":"NO"),
            " | M1LiveBreak=",(live_m1_break?"YES":"NO"),
            " | TruthMoveATR=",DoubleToString(truth_move_atr,2),
            " | PeakMove=",DoubleToString(peak_move,_Digits),
            " | Pullback=",DoubleToString(pullback_from_peak,_Digits),
            " | PullbackNeed=",DoubleToString(pullback_threshold,_Digits),
            " | Adverse=",DoubleToString(move_against,_Digits));
      return true;
   }

   hold_reason="REVERSAL_HOLD: درخواست بستن معامله توسط پلتفرم تأیید نشد";
   return false;
}

// حد سود تنها در صورت تأیید واقعی تغییر جهت، به Entry نزدیک می‌شود.
// افت امتیاز ادامه به تنهایی هرگز باعث جابه‌جایی TP نمی‌شود.
// اعتبارسنجی حد سود در سمت درست قیمت و با رعایت محدودیت‌های بروکر
bool DynamicTP_IsBrokerValid(const bool is_buy,const double target_price)
{
   if(target_price<=0.0 || !MathIsValidNumber(target_price))
      return false;

   MqlTick tick;
   if(!SymbolInfoTick(_Symbol,tick) || tick.bid<=0.0 || tick.ask<=0.0)
      return false;

   double point=SymbolInfoDouble(_Symbol,SYMBOL_POINT);
   if(point<=0.0 || !MathIsValidNumber(point))
      point=_Point;
   if(point<=0.0)
      return false;

   long stops_level=0;
   long freeze_level=0;
   long symbol_digits=(long)_Digits;
   SymbolInfoInteger(_Symbol,SYMBOL_TRADE_STOPS_LEVEL,stops_level);
   SymbolInfoInteger(_Symbol,SYMBOL_TRADE_FREEZE_LEVEL,freeze_level);
   SymbolInfoInteger(_Symbol,SYMBOL_DIGITS,symbol_digits);

   const double broker_level=(double)MathMax(stops_level,freeze_level);
   // یک پوینت حاشیه برای جلوگیری از رد شدن به‌علت گردکردن قیمت
   const double min_distance=(broker_level+1.0)*point;
   const double target=NormalizeDouble(target_price,(int)symbol_digits);

   // BUY TP باید بالاتر از Bid و SELL TP پایین‌تر از Ask باشد.
   if(is_buy)
      return (target>tick.bid+min_distance);

   return (target<tick.ask-min_distance);
}

double DynamicTP_ComputeConfirmedReversalTarget(const bool is_buy,
                                                const double entry,
                                                const double initial_tp,
                                                const double continuation,
                                                const double reversal)
{
   if(entry<=0.0 || initial_tp<=0.0 || MathAbs(initial_tp-entry)<=_Point ||
      !g_minute_monitor.m5_truth.valid)
      return 0.0;

   const bool truth_reverse=((is_buy && g_minute_monitor.m5_truth.direction==MARKET_TRUTH_SELL) ||
                             (!is_buy && g_minute_monitor.m5_truth.direction==MARKET_TRUTH_BUY));
   const double confidence=MathMax(78.0,Inp_Reversal_Engine_Min_Confidence);
   const double score_lead=MathMax(15.0,Inp_Reversal_Engine_Min_Score_Lead);
   if(!truth_reverse || reversal<confidence || reversal<continuation+score_lead)
      return 0.0;

   const double atr=GetCurrentATRPrice();
   if(atr<=0.0)
      return 0.0;
   bool live_m1_break=false, closed_m1_break=false;
   double structure_level=0.0;
   ReversalEngine_M1StructureBreak(is_buy,
      is_buy?SymbolInfoDouble(_Symbol,SYMBOL_BID):SymbolInfoDouble(_Symbol,SYMBOL_ASK),
      atr,live_m1_break,closed_m1_break,structure_level);
   const bool strong_truth=(g_minute_monitor.m5_truth.strong_market_move &&
                            g_minute_monitor.m5_truth.move_atr_multiple>=0.50);
   if(!closed_m1_break && !strong_truth)
      return 0.0;

   double remaining_ratio=0.60;
   if(reversal>=90.0 && reversal>=continuation+20.0 &&
      g_minute_monitor.m5_truth.move_atr_multiple>=0.75)
      remaining_ratio=0.35;
   else if(reversal>=85.0 && reversal>=continuation+18.0)
      remaining_ratio=0.45;

   const double target=entry+(initial_tp-entry)*remaining_ratio;
   // خروجی فقط بین Entry و TP اولیه مجاز است.
   if(is_buy && (target<=entry || target>initial_tp)) return 0.0;
   if(!is_buy && (target>=entry || target<initial_tp)) return 0.0;
   return NormalizeDouble(target,_Digits);
}

//====================================================================
// موتور سریع برگشت: فقط پوزیشن‌های باز و معیارهای خروج را کنترل می‌کند.
// چرخه سنگین تحلیل/گزارش جداگانه و با فاصله Inp_Monitor_Update_Seconds اجرا می‌شود.
//====================================================================
void ProcessFastReversalMonitor()
{
   if(!Inp_Enable_Trade_Management ||
      (!Inp_Enable_Reversal_Exit && !Inp_Enable_Profit_Protection && !Inp_Enable_Dynamic_TP))
      return;

   const datetime now=TimeCurrent();
   const int check_seconds=MathMax(1,Inp_Reversal_Engine_Update_Seconds);
   if(g_last_fast_reversal_check>0 && (now-g_last_fast_reversal_check)<check_seconds)
      return;
   g_last_fast_reversal_check=now;

   // امتیازهای روند هر چند ثانیه به‌روزرسانی می‌شوند؛ قفل یک‌باره SL در هر بررسی قیمت اجرا می‌شود.
   const bool need_score=(Inp_Enable_Reversal_Exit || Inp_Enable_Dynamic_TP);
   if(need_score && (!g_minute_monitor.valid || g_last_fast_reversal_score_refresh==0 ||
      (now-g_last_fast_reversal_score_refresh)>=MathMax(5,Inp_Reversal_Score_Refresh_Seconds)))
   {
      CalculateMinuteScores();
      g_last_fast_reversal_score_refresh=now;
   }

   for(int i=PositionsTotal()-1;i>=0;--i)
   {
      const ulong ticket=PositionGetTicket(i);
      if(ticket==0 || !PositionSelectByTicket(ticket)) continue;
      if(PositionGetString(POSITION_SYMBOL)!=_Symbol) continue;
      if((ulong)PositionGetInteger(POSITION_MAGIC)!=Inp_MagicNumber) continue;

      const bool is_buy=(PositionGetInteger(POSITION_TYPE)==POSITION_TYPE_BUY);
      const ulong position_id=(ulong)PositionGetInteger(POSITION_IDENTIFIER);
      const datetime position_time=(datetime)PositionGetInteger(POSITION_TIME);
      const double entry=PositionGetDouble(POSITION_PRICE_OPEN);
      const double current=is_buy ? SymbolInfoDouble(_Symbol,SYMBOL_BID)
                                  : SymbolInfoDouble(_Symbol,SYMBOL_ASK);
      double sl=PositionGetDouble(POSITION_SL);
      double tp=PositionGetDouble(POSITION_TP);
      const double profit=PositionGetDouble(POSITION_PROFIT);
      if(entry<=0.0 || current<=0.0) continue;

      const int idx=DynamicTP_GetOrCreateState(position_id,ticket,entry,tp,sl);
      if(idx<0) continue;
      if(g_dynamic_tp_tracker[idx].max_favorable_price<=0.0)
         g_dynamic_tp_tracker[idx].max_favorable_price=entry;
      if(is_buy)
         g_dynamic_tp_tracker[idx].max_favorable_price=MathMax(g_dynamic_tp_tracker[idx].max_favorable_price,current);
      else
         g_dynamic_tp_tracker[idx].max_favorable_price=MathMin(g_dynamic_tp_tracker[idx].max_favorable_price,current);
      g_dynamic_tp_tracker[idx].last_seen=now;

      const double continuation=MinuteContinuationScore(is_buy);
      const double reversal=MinuteReversalScore(is_buy);
      const double peak=g_dynamic_tp_tracker[idx].max_favorable_price;
      const double initial_risk=g_dynamic_tp_tracker[idx].initial_risk_distance;
      string hold_reason="";

      if(Inp_Enable_Reversal_Exit && g_minute_monitor.valid &&
         TryProtectiveReversalExit(ticket,is_buy,position_time,entry,current,continuation,reversal,
                                   peak,initial_risk,hold_reason))
      {
         BacktestReport_WriteManagementSnapshot(g_backtest_report,now,position_id,ticket,
            is_buy?"BUY":"SELL",entry,current,sl,tp,profit,continuation,reversal,
            "CLOSED_REVERSAL_PROTECT",
            "خروج فقط پس از تأیید امتیاز برگشت و Truth مخالف، همراه با ساختار/حرکت معتبر");
         continue;
      }

      // حد سود قبل از TP تنها بر اساس برگشت تأییدشده (نه افت امتیاز ادامه) نزدیک می‌شود.
      if(Inp_Enable_Dynamic_TP && g_minute_monitor.valid && PositionSelectByTicket(ticket))
      {
         const double initial_tp=g_dynamic_tp_tracker[idx].initial_tp;
         const double desired=DynamicTP_ComputeConfirmedReversalTarget(is_buy,entry,initial_tp,continuation,reversal);
         const bool closer=(desired>0.0 && tp>0.0 &&
            (is_buy ? desired<tp-_Point : desired>tp+_Point));
         if(closer && DynamicTP_IsBrokerValid(is_buy,desired) && IsRealTradingAllowed())
         {
            if(SL_ModifyPositionSLTP(ticket,_Symbol,sl,desired))
            {
               tp=desired;
               BacktestReport_WriteManagementSnapshot(g_backtest_report,now,position_id,ticket,
                  is_buy?"BUY":"SELL",entry,current,sl,tp,profit,continuation,reversal,
                  "TP_MOVED","Truth مخالف و امتیاز برگشت تأیید شد؛ TP فقط به Entry نزدیک شد");
            }
         }
      }

      // قفل سود یک‌بار و فقط بعد از طی‌شدن دوسوم فاصله Entry تا TP اولیه؛ بدون trailing.
      if(Inp_Enable_Profit_Protection && PositionSelectByTicket(ticket))
      {
         sl=PositionGetDouble(POSITION_SL);
         tp=PositionGetDouble(POSITION_TP);
         string protection_action="", protection_reason="";
         const double initial_tp=g_dynamic_tp_tracker[idx].initial_tp;
         const bool locked=TryProfitProtection(ticket,is_buy,entry,current,sl,initial_tp,peak,
                           g_dynamic_tp_tracker[idx].profit_lock_armed,
                           protection_action,protection_reason);
         if(locked)
         {
            if(PositionSelectByTicket(ticket)) sl=PositionGetDouble(POSITION_SL);
            BacktestReport_WriteManagementSnapshot(g_backtest_report,now,position_id,ticket,
               is_buy?"BUY":"SELL",entry,current,sl,tp,profit,continuation,reversal,
               "PROFIT_LOCK_ONCE",protection_reason);
         }
      }
   }
}

void ProcessMinuteTradeManagement()
{
   if(!Inp_Enable_Trade_Management)
      return;

   if(!EnsureMinuteMarketMonitorFresh())
      return;

   DynamicTP_Cleanup();
   datetime now=TimeCurrent();

   //--- ثبت وضعیت دقیقه‌ای و Dynamic TP
   for(int i=PositionsTotal()-1;i>=0;i--)
   {
      ulong ticket=PositionGetTicket(i);
      if(ticket==0 || !PositionSelectByTicket(ticket)) continue;
      if(PositionGetString(POSITION_SYMBOL)!=_Symbol) continue;
      if((ulong)PositionGetInteger(POSITION_MAGIC)!=Inp_MagicNumber) continue;

      bool is_buy=(PositionGetInteger(POSITION_TYPE)==POSITION_TYPE_BUY);
      ulong position_id=(ulong)PositionGetInteger(POSITION_IDENTIFIER);
      double entry=PositionGetDouble(POSITION_PRICE_OPEN);
      datetime position_time=(datetime)PositionGetInteger(POSITION_TIME);
      double current=is_buy ? SymbolInfoDouble(_Symbol,SYMBOL_BID) : SymbolInfoDouble(_Symbol,SYMBOL_ASK);
      double sl=PositionGetDouble(POSITION_SL);
      double current_tp=PositionGetDouble(POSITION_TP);
      double profit=PositionGetDouble(POSITION_PROFIT);
      double continuation=MinuteContinuationScore(is_buy);
      double reversal=MinuteReversalScore(is_buy);
      string action="NONE";
      string reason="بررسی دقیقه‌ای";

      // SL واقعیِ بروکر در اولین مشاهدهٔ هر موقعیت ذخیره می‌شود؛ SL سناریو از Comment
      // ممکن است با SL ارسال‌شده به بروکر فرق داشته باشد و نباید مبنای ریسک باشد.
      int idx=DynamicTP_GetOrCreateState(position_id,ticket,entry,current_tp,sl);
      double initial_sl=(idx>=0 && g_dynamic_tp_tracker[idx].initial_sl>0.0)
         ? g_dynamic_tp_tracker[idx].initial_sl : sl;
      double initial_risk_distance=(idx>=0 && g_dynamic_tp_tracker[idx].initial_risk_distance>0.0)
         ? g_dynamic_tp_tracker[idx].initial_risk_distance
         : (initial_sl>0.0 ? MathAbs(entry-initial_sl) : 0.0);

      if(idx>=0)
      {
         if(g_dynamic_tp_tracker[idx].max_favorable_price<=0.0)
            g_dynamic_tp_tracker[idx].max_favorable_price=entry;
         if(is_buy)
            g_dynamic_tp_tracker[idx].max_favorable_price=MathMax(g_dynamic_tp_tracker[idx].max_favorable_price,current);
         else
            g_dynamic_tp_tracker[idx].max_favorable_price=MathMin(g_dynamic_tp_tracker[idx].max_favorable_price,current);
         g_dynamic_tp_tracker[idx].last_seen=now;
      }
      double max_favorable_price=(idx>=0) ? g_dynamic_tp_tracker[idx].max_favorable_price : entry;

      if(TryAdaptiveLossProtection(ticket,is_buy,entry,current,sl,initial_sl,continuation,reversal))
      {
         BacktestReport_WriteManagementSnapshot(g_backtest_report,now,position_id,ticket,is_buy?"BUY":"SELL",entry,current,sl,current_tp,profit,continuation,reversal,"CLOSED_ADAPTIVE_LOSS","حرکت خلاف جهت از حد مجاز عبور کرد؛ ریسک بر اساس SL واقعی اولیه محاسبه شد");
         continue;
      }

      string reversal_hold_reason="";
      if(TryProtectiveReversalExit(ticket,is_buy,position_time,entry,current,continuation,reversal,
                                  max_favorable_price,initial_risk_distance,reversal_hold_reason))
      {
         BacktestReport_WriteManagementSnapshot(g_backtest_report,now,position_id,ticket,is_buy?"BUY":"SELL",entry,current,sl,current_tp,profit,continuation,reversal,"CLOSED_REVERSAL_PROTECT","امتیاز قوی برگشت و Truth مخالف با ساختار/حرکت معتبر تأیید شد");
         continue;
      }
      if(reversal_hold_reason!="")
      {
         action="REVERSAL_HOLD";
         reason=reversal_hold_reason;
      }

      if(idx>=0)
      {
         string protection_action="";
         string protection_reason="";
         double initial_tp_for_lock=g_dynamic_tp_tracker[idx].initial_tp;
         bool protection_changed=TryProfitProtection(ticket,is_buy,entry,current,sl,initial_tp_for_lock,
                                max_favorable_price,g_dynamic_tp_tracker[idx].profit_lock_armed,
                                protection_action,protection_reason);
         if(protection_changed)
         {
            if(PositionSelectByTicket(ticket))
               sl=PositionGetDouble(POSITION_SL);
            if(protection_action!="PROFIT_LOCK_SKIPPED")
            {
               action=protection_action;
               reason=(reversal_hold_reason!="") ? protection_reason+" | "+reversal_hold_reason : protection_reason;
            }
            else if(reason=="بررسی دقیقه‌ای")
            {
               action=protection_action;
               reason=protection_reason;
            }
         }
      }

      if(Inp_Enable_Dynamic_TP && idx>=0)
      {
         // فقط رسیدن به TP اولیه خروج پشتیبان را فعال می‌کند؛ تغییر TP زودتر
         // در موتور سریع و تنها با برگشت واقعی/تأییدشده انجام می‌شود.
         double initial_tp=g_dynamic_tp_tracker[idx].initial_tp;
         bool passed=is_buy ? (current>=initial_tp && initial_tp>entry) : (current<=initial_tp && initial_tp<entry);
         if(passed && IsRealTradingAllowed() && PositionSelectByTicket(ticket))
         {
            double volume=PositionGetDouble(POSITION_VOLUME);
            if(volume>0.0 && ClosePositionVolume(ticket,_Symbol,is_buy,volume,"TFlab Original TP Fallback"))
            {
               action="CLOSED_DYNAMIC_TP";
               reason="قیمت به حد سود اولیه رسیده یا از آن عبور کرده؛ خروج پشتیبان ثبت شد";
               BacktestReport_WriteManagementSnapshot(g_backtest_report,now,position_id,ticket,is_buy?"BUY":"SELL",entry,current,sl,current_tp,profit,continuation,reversal,action,reason);
               continue;
            }
         }
      }

      BacktestReport_WriteManagementSnapshot(g_backtest_report,now,position_id,ticket,is_buy?"BUY":"SELL",entry,current,sl,current_tp,profit,continuation,reversal,action,reason);
   }

   //--- قبل از ورود معکوس: فقط اگر برگشت تأیید شده، تمام معاملات جهت قدیم بسته شوند.
   if(g_scenario.id>0 && Scenario_IsValid(g_scenario))
      CloseOldSideBeforeReverseEntry();
}

//====================================================================
// رصد معاملات باز
//====================================================================
void MonitorOpenTrades()
{
   if(!Inp_Enable_Trade_Management)
      return;

   const datetime now =
      TimeCurrent();

   for(int i =
      PositionsTotal() - 1;
      i >= 0;
      i--)
   {
      const ulong ticket =
         PositionGetTicket(i);

      if(ticket == 0 ||
         !PositionSelectByTicket(
            ticket))
         continue;

      if(PositionGetString(
            POSITION_SYMBOL) !=
         _Symbol)
         continue;

      if((ulong)PositionGetInteger(
            POSITION_MAGIC) !=
         Inp_MagicNumber)
         continue;

      bool is_buy =
         (PositionGetInteger(
            POSITION_TYPE) ==
          POSITION_TYPE_BUY);

      double volume =
         PositionGetDouble(
            POSITION_VOLUME);

      datetime open_time =
         (datetime)
         PositionGetInteger(
            POSITION_TIME);

      //=============================================================
      // خروج بازگشت روند
      //=============================================================
      // خروج به علت برگشت فقط در مدیریت دقیقه‌ای و همزمان با
      // تأیید قصد ورود معکوس انجام می‌شود؛ اینجا عمداً حذف شده است.

      //=============================================================
      // خروج زمانی
      //=============================================================
      if(Inp_Allow_Time_Exit &&
         Inp_Max_Trade_Duration_Minutes > 0 &&
         open_time > 0)
      {
         if((int)
            ((now - open_time) / 60) >=
            Inp_Max_Trade_Duration_Minutes)
         {
            if(IsRealTradingAllowed() &&
               ClosePositionVolume(
                  ticket,
                  _Symbol,
                  is_buy,
                  volume,
                  "TFlab Time Exit"))
            {
               LogCycle(
                  "TRADE_MGMT",
                  "خروج به دلیل اتمام مدت مجاز");

               continue;
            }
         }
      }

      // V5.116: مدیریت پلکانی و trailing عمومی عمداً اجرا نمی‌شود.
      // تنها انتقال حد ضرر سودمحافظ از موتور یک‌باره انجام می‌شود و آن هم پس از طی‌شدن دوسوم TP اولیه.
      // خروج قبل از TP فقط از موتور مستقل تشخیص برگشت روند در ProcessMinuteTradeManagement انجام می‌شود.
   }
}

//====================================================================
// تشخیص Pending مربوط به SELL Continuation
// ST=SC در Comment برای حفظ تشخیص حتی بعد از بازراه‌اندازی EA ثبت می‌شود.
//====================================================================
bool IsSellContinuationPending(const string comment,
                               const ulong scenario_id)
  {
   if(StringFind(comment,"ST=SC") >= 0 ||
      StringFind(comment,"TFlab SC") == 0)
      return true;

   // سازگاری با Pendingهای همان اجرای EA که Comment قدیمی ندارند.
   if(scenario_id > 0 &&
      g_scenario.id == scenario_id &&
      g_last_strategy_type == STRATEGY_SELL_CONTINUATION)
      return true;

   return false;
  }

//====================================================================
// V5.116: محافظ Pending SELL پیش از Trigger شدن
// HTF فقط Context است؛ لغو Pending فقط با برگشت قوی و تأییدشده M5 انجام می‌شود.
//====================================================================
bool LiveSellContinuationDirectionConflict(
   const double live_bid)
  {
   if(live_bid <= 0.0)
      return false;

   // V5.116: HTF دیگر Trigger/Entry را veto نمی‌کند.
   // فقط یک برگشت واقعی و قوی روی M5 می‌تواند SELL Continuation را متوقف کند.
   MarketTruthSnapshot m5_truth;
   MarketTruth_Reset(m5_truth);

   if(!MarketTruth_Analyze(
         _Symbol,
         Inp_TF_Setup_M5,
         Inp_Market_Truth_Lookback,
         m5_truth) ||
      !m5_truth.valid)
      return false;

   const bool strong_m5_bullish_reversal =
      m5_truth.direction == MARKET_TRUTH_BUY &&
      m5_truth.strong_market_move &&
      m5_truth.continuation_ready &&
      m5_truth.phase == MARKET_TRUTH_PHASE_REVERSAL &&
      m5_truth.move_atr_multiple >= 2.50;

   if(strong_m5_bullish_reversal)
   {
      Print(
         "[V5.116 SELL M5 REVERSAL BLOCK] برگشت قوی M5 تشخیص داده شد | MoveATR=",
         DoubleToString(m5_truth.move_atr_multiple,2));
      return true;
   }

   return false;
  }

//====================================================================
// محافظ Pending SELL Continuation در برابر تغییر جهت زنده
// V5.116: فقط برگشت قوی M5 می‌تواند Pending را برای همان Scenario لغو کند؛ HTF صرفاً Context است.
//====================================================================
bool ProtectLiveSellContinuationPendings()
  {
   bool candidate_exists = false;

   for(int i = OrdersTotal() - 1; i >= 0; i--)
     {
      const ulong ticket = OrderGetTicket(i);
      if(ticket == 0)
         continue;

      if(OrderGetString(ORDER_SYMBOL) != _Symbol)
         continue;

      if((ulong)OrderGetInteger(ORDER_MAGIC) != Inp_MagicNumber)
         continue;

      const ENUM_ORDER_TYPE type =
         (ENUM_ORDER_TYPE)OrderGetInteger(ORDER_TYPE);

      if(type != ORDER_TYPE_SELL_LIMIT &&
         type != ORDER_TYPE_SELL_STOP)
         continue;

      const string comment = OrderGetString(ORDER_COMMENT);
      const ulong scenario_id = ExtractScenarioIdFromComment(comment);

      if(scenario_id == 0 ||
         !IsSellContinuationPending(comment,scenario_id))
         continue;

      candidate_exists = true;
      break;
     }

   if(!candidate_exists)
      return true;

   double bid = 0.0;
   double ask = 0.0;
   double mid = 0.0;
   if(!GetCurrentPrices(bid,ask,mid))
      return true;

   if(!LiveSellContinuationDirectionConflict(bid))
     {
      // اگر جهت زنده از اجماع صعودی خارج شده، قفل سناریو هم آزاد می‌شود.
      if(g_live_sell_block_scenario_id > 0)
         g_live_sell_block_scenario_id = 0;
      return true;
     }

   int removed = 0;

   for(int i = OrdersTotal() - 1; i >= 0; i--)
     {
      const ulong ticket = OrderGetTicket(i);
      if(ticket == 0)
         continue;

      if(OrderGetString(ORDER_SYMBOL) != _Symbol)
         continue;

      if((ulong)OrderGetInteger(ORDER_MAGIC) != Inp_MagicNumber)
         continue;

      const ENUM_ORDER_TYPE type =
         (ENUM_ORDER_TYPE)OrderGetInteger(ORDER_TYPE);

      if(type != ORDER_TYPE_SELL_LIMIT &&
         type != ORDER_TYPE_SELL_STOP)
         continue;

      const string comment = OrderGetString(ORDER_COMMENT);
      const ulong scenario_id = ExtractScenarioIdFromComment(comment);

      if(scenario_id == 0 ||
         !IsSellContinuationPending(comment,scenario_id))
         continue;

      g_live_sell_block_scenario_id = scenario_id;

      if(RemovePendingTicket(
            ticket,
            "برگشت قوی M5 به صعود"))
        {
         removed++;

         Print(
            "[SELL PENDING M5 REVERSAL BLOCK] Pending SELL قبل از Trigger لغو شد",
            " | Ticket=",ticket,
            " | Scenario=",scenario_id,
            " | Bid=",DoubleToString(bid,_Digits),
            " | فقط برگشت قوی M5 معیار لغو است");
        }
     }

   if(removed > 0)
      LogCycle("PENDING_DIRECTION",
               "Pending SELL Continuation به دلیل تغییر جهت زنده حذف شد");

   return (removed == 0);
  }

//====================================================================
// تأیید برگشت واقعی برای حذف Pending
// حداقل دو لایه مستقل باید علیه Pending رأی بدهند.
//====================================================================
bool ConfirmPendingReversalBeforeCancel(
   const bool is_buy)
{
   int votes = 0;

   bool regime_conflict = false;
   bool structure_conflict = false;
   bool truth_conflict = false;

   if(g_regime.valid &&
      g_regime.confidence >= Inp_Reversal_Exit_Min_Confidence)
   {
      regime_conflict =
         (is_buy
          ? g_regime.regime == MARKET_REGIME_DOWNTREND
          : g_regime.regime == MARKET_REGIME_UPTREND);
   }

   if(g_structure.valid)
   {
      structure_conflict =
         (is_buy
          ? (g_structure.state == STRUCTURE_STATE_BEARISH &&
             g_structure.bearish_sequence)
          : (g_structure.state == STRUCTURE_STATE_BULLISH &&
             g_structure.bullish_sequence));
   }

   if(g_market_truth.valid &&
      g_market_truth.strong_market_move &&
      g_market_truth.continuation_ready &&
      g_market_truth.move_atr_multiple >= 3.50)
   {
      truth_conflict =
         (is_buy
          ? g_market_truth.direction == MARKET_TRUTH_SELL
          : g_market_truth.direction == MARKET_TRUTH_BUY);
   }

   bool m5_confirmed =
      ClosedM5BarsConfirmOppositeDirection(is_buy,Inp_Reversal_Confirm_M5_Bars);

   if(regime_conflict)    votes++;
   if(structure_conflict) votes++;
   if(truth_conflict)     votes++;

   Print(
      "[V5.116 PENDING REVERSAL CHECK] ",
      is_buy ? "BUY" : "SELL",
      " | Votes=",votes,
      " | Regime=",regime_conflict ? "YES" : "NO",
      " | Structure=",structure_conflict ? "YES" : "NO",
      " | Truth=",truth_conflict ? "YES" : "NO");

   // V5.116: در حالت دو رأی، حداقل یکی باید تأیید صریح Market Truth باشد؛
   // اختلاف کوتاه‌مدت Regime/Structure به‌تنهایی Pending را حذف نمی‌کند.
   // V5.116: حذف Pending فقط بعد از دو کندل بسته‌شده M5 متوالی مجاز است.
   return m5_confirmed &&
          (votes >= 3 ||
           (votes >= 2 && truth_conflict));
}

//====================================================================
// رصد Pending
//====================================================================
void MonitorPending()
{
   if(g_pending.ticket > 0)
   {
      const datetime now = TimeCurrent();
      const ulong pending_scenario_id = g_pending.scenario_id;

      PendingOrder_UpdateState(g_pending, now);

      if(!g_pending.active &&
         g_pending.state == PENDING_STATE_TRIGGERED)
      {
         if(HasOpenPositionForScenario(pending_scenario_id))
         {
            g_last_executed_scenario_id = pending_scenario_id;
            SignalAudit_MarkCapture(g_signal_audit,pending_scenario_id,"Pending اجرا شد");

            // V5.116: قفل Opportunity باید هنگام Trigger شدن Pending هم ثبت شود؛
            // در غیر این صورت یک Opportunity می‌توانست ابتدا Pending و سپس Market دوم ایجاد کند.
            const int pending_audit_index =
               SignalAudit_Find(g_signal_audit,pending_scenario_id);
            if(pending_audit_index >= 0 &&
               g_signal_audit.records[pending_audit_index].opportunity_id > 0)
            {
               g_last_executed_opportunity_id =
                  g_signal_audit.records[pending_audit_index].opportunity_id;
               g_last_direct_opportunity_bar =
                  iTime(_Symbol,Inp_TF_Setup_M5,1);
               Print(
                  "[V5.116 OPPORTUNITY LOCK] Pending اجرا شد | OpportunityID=",
                  (string)g_last_executed_opportunity_id,
                  " | Scenario=",
                  (string)pending_scenario_id);
            }

            if(g_scenario.id == pending_scenario_id)
            {
               Scenario_Trigger(
                  g_scenario,
                  g_pending.price,
                  now,
                  "Pending فعال شد");

               Scenario_MarkExecuted(
                  g_scenario,
                  now,
                  "معامله از Pending اجرا شد");

               AIJournal_MarkExecuted(g_scenario.id);
               EntryPlan_MarkFilled(g_entry_plan);
            }

            LogCycle(
               "PENDING_TRIGGER",
               "Pending به معامله تبدیل شد | Ticket=" +
               (string)g_pending.ticket);
         }

         PendingOrder_Init(g_pending);
      }
   }

   RefreshPendingPoolStates();

   //=================================================================
   // کنترل مستقیم تمام Pendingهای ربات، نه فقط g_pending
   //=================================================================
   for(int i = OrdersTotal() - 1; i >= 0; i--)
   {
      ulong ticket = OrderGetTicket(i);
      if(ticket == 0)
         continue;

      if(OrderGetString(ORDER_SYMBOL) != _Symbol)
         continue;

      if((ulong)OrderGetInteger(ORDER_MAGIC) != Inp_MagicNumber)
         continue;

      ENUM_ORDER_TYPE type =
         (ENUM_ORDER_TYPE)OrderGetInteger(ORDER_TYPE);

      if(type != ORDER_TYPE_BUY_LIMIT  &&
         type != ORDER_TYPE_SELL_LIMIT &&
         type != ORDER_TYPE_BUY_STOP   &&
         type != ORDER_TYPE_SELL_STOP)
         continue;

      const string comment =
         OrderGetString(ORDER_COMMENT);

      const ulong scenario_id =
         ExtractScenarioIdFromComment(comment);

      if(scenario_id == 0)
         continue;

      bool is_buy =
         (type == ORDER_TYPE_BUY_LIMIT ||
          type == ORDER_TYPE_BUY_STOP);

      double order_sl = OrderGetDouble(ORDER_SL);
      double order_price = OrderGetDouble(ORDER_PRICE_OPEN);

      bool cancel = false;
      string cancel_reason = "";

      if(g_scenario.id == scenario_id &&
         (g_scenario.status == SCENARIO_STATUS_INVALID ||
          g_scenario.status == SCENARIO_STATUS_EXPIRED) &&
         Inp_Cancel_Pending_On_Invalid)
      {
         cancel = true;
         cancel_reason = "ابطال/انقضای Scenario";
      }
      else
      if(Inp_Enable_Reversal_Pending_Cancel &&
         ConfirmPendingReversalBeforeCancel(is_buy))
      {
         cancel = true;
         cancel_reason = "بازگشت واقعی بازار با تأیید چندلایه قبل از فعال شدن سفارش";
      }
      else
      if(Inp_Cancel_Pending_On_SL_Breach &&
         order_sl > 0.0)
      {
         double bid_now = SymbolInfoDouble(_Symbol, SYMBOL_BID);
         double ask_now = SymbolInfoDouble(_Symbol, SYMBOL_ASK);

         if((!is_buy && bid_now >= order_sl) ||
            (is_buy && ask_now <= order_sl))
         {
            cancel = true;
            cancel_reason = "عبور قیمت از حد ضرر قبل از فعال شدن";
         }
      }

      if(cancel)
         RemovePendingTicket(ticket, cancel_reason);
   }

   RefreshPendingPoolStates();
}

//====================================================================
// به‌روزرسانی AI
//====================================================================
void UpdateAI()
{
   if(!Inp_Enable_AI || !Inp_AI_Advisor_Enable)
   {
      AI_AdvisorInit(g_ai_advice);
      return;
   }

   if(g_scenario.id > 0 &&
      Scenario_IsValid(
         g_scenario) &&
      g_scenario.entry_price > 0.0 &&
      g_scenario.target_1 > 0.0 &&
      g_scenario.target_2 > 0.0 &&
      g_sl_plan.stop_price > 0.0)
   {
      if(g_tp_result.valid &&
         Inp_AI_Use_Virtual_Trading &&
         g_virtual_scenario_id !=
         g_scenario.id)
      {
         ulong signal_id =
            g_scenario.id;

         datetime decision_time =
            TimeCurrent();

         ENUM_AI_VIRTUAL_DIRECTION direction =
            (g_scenario.direction ==
               SCENARIO_DIRECTION_BUY
             ?
               AI_VIRTUAL_DIRECTION_BUY
             :
               AI_VIRTUAL_DIRECTION_SELL);

         double planned_entry =
            g_scenario.entry_price;

         double sl_price =
            g_sl_plan.stop_price;

         double tp_price =
            (g_scenario.target_2 > 0.0
             ?
               g_scenario.target_2
             :
               g_scenario.target_1);

         double quantity =
            (g_risk_result.position_volume > 0.0
             ?
               g_risk_result.position_volume
             :
               Inp_AI_Virtual_Initial_Lot);

         if(quantity <= 0.0)
            quantity =
               Inp_AI_Virtual_Initial_Lot;

         double spread =
            SymbolInfoDouble(
               _Symbol,
               SYMBOL_ASK) -
            SymbolInfoDouble(
               _Symbol,
               SYMBOL_BID);

         AIVirtualTrade virtual_trade;

         if(AIVirtualCreatePlan(
            g_ai_virtual_engine,
            signal_id,
            _Symbol,
            decision_time,
            direction,
            planned_entry,
            sl_price,
            tp_price,
            quantity,
            spread,
            "TFlab_Scenario_Virtual",
            "سناریوی معتبر با Confluence بالا",
            Inp_Max_Trade_Duration_Minutes,
            virtual_trade))
         {
            int idx =
               ArraySize(
                  g_virtual_trades);

            ArrayResize(
               g_virtual_trades,
               idx + 1);

            g_virtual_trades[idx] =
               virtual_trade;

            g_virtual_scenario_id =
               g_scenario.id;

            if(AIVirtualOpen(
               g_ai_virtual_engine,
               g_virtual_trades[idx],
               TimeCurrent(),
               planned_entry,
               spread / _Point))
            {
               Print(
                  "[AI VIRTUAL OPENED] | ID=",
                  g_virtual_trades[idx].id,
                  " | Direction=",
                  AIVirtualDirectionToPersian(
                     g_virtual_trades[idx].direction));
            }
         }
         else
         {
            Print(
               "[AI VIRTUAL CREATE FAILED] | Scenario=",
               g_scenario.id);
         }
      }

      AI_AdvisorCreateAllow(
         "سناریوی معتبر برای بررسی ایجاد شده است",
         MathMin(
            100.0,
            MathMax(
               0.0,
               g_scenario.quality_value)),
         0,
         g_ai_advice);
   }
   else
   {
      AI_AdvisorCreateWait(
         "سناریوی کامل و معتبر هنوز تشکیل نشده است",
         0.0,
         0,
         g_ai_advice);
   }

   if(Inp_AI_Use_Virtual_Trading &&
      ArraySize(
         g_virtual_trades) > 0)
   {
      double bid =
         SymbolInfoDouble(
            _Symbol,
            SYMBOL_BID);

      double ask =
         SymbolInfoDouble(
            _Symbol,
            SYMBOL_ASK);

      for(int i =
         ArraySize(
            g_virtual_trades) - 1;
         i >= 0;
         i--)
      {
         if(g_virtual_trades[i].status ==
               AI_VIRTUAL_OPEN ||
            g_virtual_trades[i].status ==
               AI_VIRTUAL_PARTIAL)
         {
            if(AIVirtualUpdate(
               g_virtual_trades[i],
               TimeCurrent(),
               bid,
               ask,
               0,
               g_ai_virtual_engine))
            {
               if(g_virtual_trades[i].status ==
                     AI_VIRTUAL_STOPPED ||
                  g_virtual_trades[i].status ==
                     AI_VIRTUAL_TARGETED ||
                  g_virtual_trades[i].status ==
                     AI_VIRTUAL_CLOSED ||
                  g_virtual_trades[i].status ==
                     AI_VIRTUAL_EXPIRED)
               {
                  Print(
                     "[AI] Virtual Trade Closed | ID=",
                     g_virtual_trades[i].id,
                     " | Net=",
                     DoubleToString(
                        g_virtual_trades[i].net_profit,
                        2));
               }
            }
         }
      }
   }
}

//====================================================================
// جهت نهایی پنل
//====================================================================
string GetFinalPanelDirection()
{
   if(g_scenario.id > 0 &&
      Scenario_IsValid(
         g_scenario))
   {
      if(g_scenario.direction ==
         SCENARIO_DIRECTION_BUY)
         return "خرید";

      if(g_scenario.direction ==
         SCENARIO_DIRECTION_SELL)
         return "فروش";
   }

   return "خنثی";
}

//====================================================================
// به‌روزرسانی پنل
//====================================================================
void UpdatePanel()
{
   if(!Inp_Enable_Chart_Panel)
      return;

   string location_text =
      MarketReading_LocationToPersian(
         g_market_reading.location);

   if(g_market_reading.valid)
   {
      g_panel.market_status =
         "حال: " +
         location_text;

      g_panel.direction =
         GetFinalPanelDirection();

      g_panel.structure =
         MarketStructure_StateToPersian(
            g_structure.state);

      if(g_scenario.id > 0 &&
         Scenario_IsValid(
            g_scenario))
      {
         g_panel.scenario =
            "سناریوی معتبر " +
            ScenarioDirectionToPersian(
               g_scenario.direction);
      }
      else
      {
         g_panel.scenario =
            "بدون سناریوی معتبر";
      }

      if(g_market_reading.future_bias ==
         FUTURE_BIAS_CONTINUATION)
      {
         g_panel.entry_status =
            "ادامه حرکت";
      }
      else
      if(g_market_reading.future_bias ==
         FUTURE_BIAS_REVERSAL)
      {
         g_panel.entry_status =
            "احتمال برگشت";
      }
      else
      {
         g_panel.entry_status =
            "احتمال رنج";
      }
   }
   else
   {
      g_panel.market_status =
         "در حال بررسی";

      g_panel.direction =
         "خنثی";

      g_panel.structure =
         MarketStructure_StateToPersian(
            g_structure.state);

      g_panel.scenario =
         "بدون سناریوی معتبر";

      g_panel.entry_status =
         "در انتظار تحلیل";
   }

   string bot_status_text =
      "فعال";

   if(!g_risk_result.approved)
   {
      if(g_risk_block_reason != "")
         bot_status_text =
            "🔴 بلاک (" +
            g_risk_block_reason +
            ")";
      else
         bot_status_text =
            "🔴 بلاک (ریسک)";
   }
   else
   if(g_risk_result.risk_percent >
      Inp_Max_Risk_Per_Trade_Percent)
   {
      bot_status_text =
         "⚠️ ریسک بالا (" +
         DoubleToString(
            g_risk_result.risk_percent,
            1) +
         "%)";
   }

   g_panel.bot_status =
      bot_status_text +
      " | " +
      FilterAudit_Summary(
         g_filter_audit);

   g_panel.current_risk_percent =
      g_risk_result.risk_percent;

   g_panel.open_trades =
      CountOpenPositions();

   g_panel.pending_orders =
      CountPendingOrders();

   g_panel.open_profit =
      OpenProfit();

   g_panel.today_profit =
      TodayTotalProfit();

   g_panel.overall_profit =
      ChartPanel_CalculateOverallProfit(
         _Symbol);

   g_panel.account_balance =
      ChartPanel_GetAccountBalance();

   ChartPanel_SetUpdatedTime(
      g_panel,
      TimeCurrent());

   ChartPanel_Update(
      ChartID(),
      g_panel);
}

//====================================================================
// گزارش‌ها
//====================================================================
void UpdateReports()
{
   static datetime last_report_write = 0;

   PerformanceReport_SetOpenTrades(
      g_performance,
      CountOpenPositions(),
      OpenProfit());

   int pending_count = CountPendingOrders();

   PerformanceReport_SetPendingOrders(
      g_performance,
      pending_count,
      pending_count);

   if(PerformanceReport_Update(
         g_performance,
         TimeCurrent(),
         Inp_MagicNumber) ||
      TimeCurrent() -
      last_report_write >= 300)
   {
      ReportWord_WriteDaily(
         g_performance,
         g_filter_audit,
         g_ai_virtual_engine,
         g_virtual_trades,
         ArraySize(
            g_virtual_trades));

      ReportWord_WriteOverall(
         g_performance,
         g_filter_audit,
         g_ai_virtual_engine,
         g_virtual_trades,
         ArraySize(
            g_virtual_trades));

      last_report_write =
         TimeCurrent();
   }

   BacktestReport_WriteEquity(
      g_backtest_report,
      g_performance,
      TimeCurrent());
}

//====================================================================
// Snapshot
//====================================================================
void WriteAnalysisSnapshot(
   const datetime analysis_bar_time,
   const string cycle_result)
{
   if(!g_test_logger.initialized)
      return;

   double bid = 0.0;
   double ask = 0.0;
   double mid = 0.0;

   if(!GetCurrentPrices(
      bid,
      ask,
      mid))
      return;

   UpdateReportMetrics(
      mid);

   ENUM_HTF_DIRECTION htf =
      GetHigherTimeframeDirection();

   string htf_text =
      "خنثی";

   if(htf ==
      HTF_DIRECTION_BULLISH)
      htf_text = "صعودی";
   else
   if(htf ==
      HTF_DIRECTION_BEARISH)
      htf_text = "نزولی";

   string scenario_direction =
      "نامشخص";

   if(g_scenario.direction ==
      SCENARIO_DIRECTION_BUY)
      scenario_direction =
         "خرید";
   else
   if(g_scenario.direction ==
      SCENARIO_DIRECTION_SELL)
      scenario_direction =
         "فروش";

   string m5_direction =
      "خنثی";

   if(g_move.impulse_direction > 0)
      m5_direction = "صعودی";
   else
   if(g_move.impulse_direction < 0)
      m5_direction = "نزولی";

   string m5_state =
      ImpulseCorrection_StateToPersian(
         g_move.state);

   string m5_correction_state =
      (g_move.correction_valid
       ? "معتبر"
       : "ندارد/نامعتبر");

   string scenario_state =
      (g_scenario.id > 0
       ? ScenarioStatusToPersian(
            g_scenario.status)
       : "بدون سناریو");

   string scenario_reason =
      g_last_scenario_diagnostic;

   if(scenario_reason == "")
      scenario_reason =
         (cycle_result ==
            "سناریوی معتبر تشکیل نشد"
          ?
            "شرایط کافی برای ساخت سناریو وجود ندارد"
          :
            "چرخه تحلیل و تصمیم اجرا شد");

   double m5_atr_points =
      (g_move.impulse_atr > 0.0
       ?
         g_move.impulse_atr /
         _Point
       :
         g_context.atr_points);

   double m5_impulse_size_points =
      g_move.impulse_size_points;

   int m5_impulse_bars =
      g_move.impulse_bars;

   double m5_atr_multiple =
      g_move.impulse_atr_multiple;

   double m5_correction_ratio =
      g_move.correction_ratio;

   double m5_directional_ratio = 0.0;
   double m5_continuity_ratio = 0.0;
   double m5_efficiency_ratio = 0.0;
   double m5_momentum_score = 0.0;

   if(M5MovementMetrics_IsValid(
      g_m5_metrics))
   {
      m5_directional_ratio =
         g_m5_metrics.directional_ratio;

      m5_continuity_ratio =
         g_m5_metrics.continuity_ratio;

      m5_efficiency_ratio =
         g_m5_metrics.efficiency_ratio;

      m5_momentum_score =
         g_m5_metrics.momentum_score;
   }

   double buy_zone_distance_points = 0.0;
   double sell_zone_distance_points = 0.0;

   if(Zone_IsValid(
      g_buy_zone))
   {
      double buy_mid =
         Zone_Midpoint(
            g_buy_zone);

      if(buy_mid > 0.0)
         buy_zone_distance_points =
            MathAbs(
               mid - buy_mid) /
            _Point;
   }

   if(Zone_IsValid(
      g_sell_zone))
   {
      double sell_mid =
         Zone_Midpoint(
            g_sell_zone);

      if(sell_mid > 0.0)
         sell_zone_distance_points =
            MathAbs(
               mid - sell_mid) /
            _Point;
   }

   double buy_zone_strength =
      (Zone_IsValid(
         g_buy_zone)
       ?
         g_buy_zone.strength
       :
         0.0);

   double sell_zone_strength =
      (Zone_IsValid(
         g_sell_zone)
       ?
         g_sell_zone.strength
       :
         0.0);

   string zone_position =
      "خارج از Zone";

   bool inside_buy =
      Zone_IsValid(
         g_buy_zone) &&
      Zone_ContainsPrice(
         g_buy_zone,
         mid);

   bool inside_sell =
      Zone_IsValid(
         g_sell_zone) &&
      Zone_ContainsPrice(
         g_sell_zone,
         mid);

   if(inside_buy &&
      inside_sell)
      zone_position =
         "داخل BUY و SELL Zone";
   else
   if(inside_buy)
      zone_position =
         "داخل BUY Zone";
   else
   if(inside_sell)
      zone_position =
         "داخل SELL Zone";
   else
   {
      bool buy_valid =
         Zone_IsValid(
            g_buy_zone);

      bool sell_valid =
         Zone_IsValid(
            g_sell_zone);

      if(buy_valid &&
         sell_valid)
      {
         if(buy_zone_distance_points <
            sell_zone_distance_points)
            zone_position =
               "نزدیک BUY Zone";
         else
         if(sell_zone_distance_points <
            buy_zone_distance_points)
            zone_position =
               "نزدیک SELL Zone";
         else
            zone_position =
               "فاصله برابر از Zoneها";
      }
      else
      if(buy_valid)
         zone_position =
            "نزدیک BUY Zone";
      else
      if(sell_valid)
         zone_position =
            "نزدیک SELL Zone";
   }

   string context_state =
      (g_context.valid
       ?
         MarketContext_ToPersian(
            g_context.state)
       :
         "نامشخص");

   string regime_text =
      EnumToString(
         g_regime.regime);

   string setup_state =
      "نامشخص";

   string setup_direction =
      "";

   string setup_reason =
      "داده مستقیم دلیل Setup در ساختار فعلی موجود نیست";

   if(g_scenario.id > 0)
   {
      setup_state =
         Scenario_IsValid(
            g_scenario)
         ? "سناریوی معتبر"
         : "نامعتبر";

      setup_direction =
         ScenarioDirectionToPersian(
            g_scenario.direction);

      if(cycle_result ==
         "سناریوی معتبر تشکیل نشد")
      {
         setup_state =
            "در انتظار";

         setup_direction =
            "";

         setup_reason =
            "سناریوی معتبر برای Setup تشکیل نشد";
      }
   }
   else
   {
      setup_state =
         "بدون سناریو";

      setup_direction =
         "";

      setup_reason =
         "سناریوی معتبری برای ارزیابی Setup وجود ندارد";
   }

   double movement_quality = 0.0;
   double zone_quality = 0.0;
   double proximity = 0.0;
   double alignment = 0.0;
   double combined_quality = 0.0;

   if(M5ZoneQuality_IsValid(
      g_m5_zone_quality))
   {
      movement_quality =
         g_m5_zone_quality.movement_quality_score;

      zone_quality =
         g_m5_zone_quality.zone_quality_score;

      proximity =
         g_m5_zone_quality.proximity_score;

      alignment =
         g_m5_zone_quality.movement_alignment_score;

      combined_quality =
         g_m5_zone_quality.combined_quality_score;
   }

   TestReportLogger_WriteSnapshot(
      g_test_logger,
      TimeCurrent(),
      _Symbol,
      (ENUM_TIMEFRAMES)_Period,
      analysis_bar_time,
      bid,
      ask,
      g_context.spread_points,
      htf_text,
      htf_text,
      context_state,
      regime_text,
      context_state,
      g_regime.confidence,
      0.0,
      MarketStructure_StateToPersian(
         g_structure.state),
      m5_state,
      m5_direction,
      g_move.impulse_valid,
      m5_impulse_size_points,
      m5_impulse_bars,
      m5_atr_points,
      m5_atr_multiple,
      m5_directional_ratio,
      m5_continuity_ratio,
      m5_efficiency_ratio,
      m5_momentum_score,
      m5_correction_state,
      m5_correction_ratio,
      buy_zone_distance_points,
      sell_zone_distance_points,
      buy_zone_strength,
      sell_zone_strength,
      zone_position,
      scenario_state,
      scenario_direction,
      g_scenario.quality_value,
      0.0,
      scenario_reason,
      setup_state,
      setup_direction,
      setup_reason,
      cycle_result);

   MarketDetailReport_Write(
      g_market_detail_report,
      TimeCurrent(),
      _Symbol,
      (ENUM_TIMEFRAMES)_Period,
      bid,
      ask,
      g_context.spread_points,
      htf_text,
      htf_text,
      regime_text,
      context_state,
      MarketStructure_StateToPersian(g_structure.state),
      m5_state,
      m5_direction,
      m5_atr_multiple,
      m5_correction_ratio,
      buy_zone_distance_points,
      sell_zone_distance_points,
      zone_position,
      scenario_state,
      scenario_direction,
      g_scenario.quality_value,
      g_scenario.entry_price,
      g_scenario.invalidation_price,
      g_sl_plan.stop_price,
      g_scenario.target_1,
      g_scenario.target_2,
      setup_state,
      setup_direction,
      setup_reason,
      EntryPlanTypeToPersian(g_entry_plan.type),
      EntryPlanStatusToPersian(g_entry_plan.status),
      g_entry_plan.executable,
      g_entry_plan.entry_reachable,
      g_entry_plan.reason,
      (g_opportunity_capture.valid && g_opportunity_capture.priority),
      g_opportunity_capture.quality,
      g_opportunity_capture.reason,
      PendingStateToPersian(g_pending.state),
      g_pending.ticket,
      cycle_result);
}

//====================================================================
// اجرای چرخه تحلیل
//====================================================================
void RunAnalysisCycle()
{
   datetime bar =
      iTime(
         _Symbol,
         Inp_TF_Setup_M5,
         1);

   if(bar <= 0 ||
      bar ==
      g_last_m5_closed_bar)
      return;

   TradingScenario new_scenario;
   SLPlan new_sl_plan;
   TP_Result new_tp_result;
   TargetInfo new_target;

   //===============================================================
   // تحلیل جدید شکست خورد:
   // سناریوی قبلی دیگر حفظ نمی‌شود.
   //===============================================================
   if(!AnalyzeMarket(
      new_scenario,
      new_sl_plan,
      new_tp_result,
      new_target))
   {
      g_last_m5_closed_bar =
         bar;

      g_main_state.last_analysis_bar =
         bar;

      g_main_state.last_analysis_time =
         TimeCurrent();

      // V5.116: شکست Scenario عمومی، Opportunity اولویت‌دار را متوقف نمی‌کند.
      if(g_opportunity_capture.valid &&
         g_opportunity_capture.priority)
      {
         ResetScenarioAnalysisStateKeepPending(
            "Scenario عمومی تشکیل نشد؛ Opportunity اولویت‌دار مستقیم بررسی می‌شود");

         double direct_bid = SymbolInfoDouble(_Symbol,SYMBOL_BID);
         double direct_ask = SymbolInfoDouble(_Symbol,SYMBOL_ASK);
         double direct_price =
            (direct_bid > 0.0 && direct_ask > 0.0)
            ? (direct_bid + direct_ask) * 0.5
            : g_opportunity_capture.current_price;

         string direct_failure_reason = "";
         if(PrepareDirectPriorityOpportunityMarketEntry(
            direct_price,
            TimeCurrent(),
            direct_failure_reason))
         {
            SignalAudit_Register(
               g_signal_audit,
               g_scenario,
               g_last_strategy_type,
               g_last_strategy_confidence,
               g_regime,
               g_structure,
               g_move,
               g_market_truth,
               g_higher_tf_context);

            UpdateRisk();
            ManageScenarioAndEntry();
            RegisterCurrentScenarioForVirtualTester();
            UpdateAI();
            UpdatePanel();

            LogCycle(
               "ANALYSIS",
               "Scenario عمومی تشکیل نشد اما Opportunity مستقیم مستقل بررسی شد");

            WriteAnalysisSnapshot(
               bar,
               "Opportunity مستقیم مستقل از Scenario عمومی ارزیابی شد");

            return;
         }

         LogCycle(
            "فرصت مستقیم - مسدود",
            "Opportunity معتبر بود ولی ورود مستقیم مسدود شد | " +
            direct_failure_reason);
      }

      ResetScenarioAnalysisStateKeepPending(
         (g_opportunity_capture.valid && g_opportunity_capture.priority)
         ? "سناریوی عمومی تشکیل نشد؛ Opportunity اولویت‌دار برای تلاش زنده بعدی حفظ شد"
         : "سناریوی معتبر جدید تشکیل نشد");

      g_entry_plan.type =
         ENTRY_PLAN_WAIT;

      g_entry_plan.status =
         ENTRY_PLAN_STATUS_PLANNED;

      g_entry_plan.executable =
         false;

      g_entry_plan.entry_currently_available =
         false;

      g_entry_plan.entry_reachable =
         false;

      g_entry_plan.reason =
         (g_opportunity_capture.valid && g_opportunity_capture.priority)
         ? "سناریوی عمومی تشکیل نشد؛ Opportunity معتبر حفظ شد و با داده زنده دوباره تلاش می‌شود"
         : "سناریوی معتبر جدید تشکیل نشد";

      UpdateRisk();
      UpdatePanel();

      LogCycle(
         "ANALYSIS",
         "سناریوی معتبر جدید تشکیل نشد | سناریوی قبلی نیز حفظ نشد");

      WriteAnalysisSnapshot(
         bar,
         "سناریوی معتبر تشکیل نشد | State قبلی پاک شد");

      return;
   }

   //===============================================================
   // بررسی تغییر Scenario
   //===============================================================
   if(g_scenario.id > 0 &&
      new_scenario.id > 0)
   {
      bool direction_changed =
         (g_scenario.direction !=
             SCENARIO_DIRECTION_NONE &&
          new_scenario.direction !=
             SCENARIO_DIRECTION_NONE &&
          g_scenario.direction !=
             new_scenario.direction);

      bool scenario_changed =
         !IsSameScenario(
            g_scenario,
            new_scenario);

      if(direction_changed ||
         scenario_changed)
      {
         if(direction_changed)
         {
            Print(
               "[SCENARIO] DIRECTION CHANGED | Direction=",
               ScenarioDirectionToPersian(
                  g_scenario.direction),
               "→",
               ScenarioDirectionToPersian(
                  new_scenario.direction));
         }
         else
         {
            Print(
               "[SCENARIO] CHANGED | Direction=",
               ScenarioDirectionToPersian(
                  g_scenario.direction),
               "→",
               ScenarioDirectionToPersian(
                  new_scenario.direction));
         }

         if(direction_changed)
         {
            // V5.116: تغییر جهت Scenario به‌تنهایی مجوز حذف Pending نیست.
            // Pending فقط با تأیید چندلایه برگشت واقعی بازار حذف می‌شود.
            bool cancel_old_pending = false;
            if(g_pending.active && g_pending.ticket > 0)
            {
               const bool pending_is_buy =
                  (g_pending.direction == SCENARIO_DIRECTION_BUY);
               cancel_old_pending =
                  Inp_Enable_Reversal_Pending_Cancel &&
                  ConfirmPendingReversalBeforeCancel(pending_is_buy);

               Print("[V5.116 PENDING DIRECTION CHECK] Ticket=",
                     g_pending.ticket,
                     " | Cancel=",(cancel_old_pending ? "YES" : "NO"),
                     " | تغییر جهت Scenario به‌تنهایی کافی نیست");
            }

            if(cancel_old_pending)
            {
               CancelActivePending(
                  "تغییر جهت واقعی و تأییدشده بازار");
               PendingOrder_Init(g_pending);
            }
            else
            {
               Print("[V5.116 PENDING PRESERVE] Pending به‌دلیل کافی نبودن تأیید برگشت حفظ شد | Ticket=",
                     g_pending.ticket);
            }
         }
         else
         {
            if(PreservePendingOnSameDirectionScenarioChange(g_pending))
            {
               Print(
                  "[SCENARIO] CHANGE SAME DIRECTION | Pending معتبر حفظ شد | Ticket=",
                  g_pending.ticket,
                  " | ScenarioOld=",g_pending.scenario_id,
                  " | ScenarioNew=",new_scenario.id);
            }
            else
            {
               CancelActivePending(
                  "تغییر سناریو و نبود شرایط حفظ Pending");
               PendingOrder_Init(g_pending);
            }
         }
      }
      else
      {
         new_scenario.id =
            g_scenario.id;

         Print(
            "[SCENARIO] UNCHANGED | ID=",
            g_scenario.id,
            " | Pending حفظ شد | Ticket=",
            g_pending.ticket);
      }
   }

   // ممیزی سیگنال فقط ثبت می‌کند و هیچ حقی برای جلوگیری از معامله ندارد.
   SignalAudit_Register(
      g_signal_audit,
      new_scenario,
      g_last_strategy_type,
      g_last_strategy_confidence,
      g_regime,
      g_structure,
      g_move,
      g_market_truth,
      g_higher_tf_context);

   g_scenario =
      new_scenario;

   g_sl_plan =
      new_sl_plan;

   g_tp_result =
      new_tp_result;

   g_target =
      new_target;

   g_last_m5_closed_bar =
      bar;

   g_main_state.last_analysis_bar =
      bar;

   g_main_state.last_analysis_time =
      TimeCurrent();

   UpdateRisk();

   ManageScenarioAndEntry();

   RegisterCurrentScenarioForVirtualTester();

   UpdateAI();

   UpdatePanel();

   LogCycle(
      "ANALYSIS",
      "چرخه تحلیل، Strategy و Scenario اجرا شد",
      g_scenario.quality_value,
      g_risk_result.rr);

   WriteAnalysisSnapshot(
      bar,
      "چرخه تحلیل، Strategy و Scenario اجرا شد");
}

//====================================================================
// OnInit
//====================================================================
int OnInit()
{
   ReportWord_InitializeInitialBalance();

   ZeroMemory(
      g_main_state);

   Scenario_Init(
      g_scenario);

   MarketReading_Reset(
      g_market_reading);

   FilterAudit_Reset(
      g_filter_audit);

   Setup_Init(
      g_setup);

   EntryPlan_Init(
      g_entry_plan);

   PendingPool_Init();

   Zone_Init(
      g_buy_zone);

   Zone_Init(
      g_sell_zone);

   ResetReportMetrics();

   Risk_InitLimits(
      g_risk_limits);

   g_risk_limits.risk_off_for_small_capital = Inp_Risk_Off_For_Small_Capital;

   Risk_InitAccountState(
      g_risk_account);

   Risk_InitResult(
      g_risk_result);

   g_is_transition_mode =
      false;

   AIVirtualEngine_Init(
      g_ai_virtual_engine);

   ChartPanel_InitState(
      g_panel);

   PerformanceReport_Init(
      g_performance);

   ArrayResize(
      g_virtual_trades,
      0);

   g_virtual_scenario_id =
      0;

   AI_AdvisorInit(
      g_ai_advice);

   DetailedLogger_ConfigInit(
      g_detailed_config);

   DetailedLogger_StateInit(
      g_detailed_state);

   TestReportLogger_InitState(
      g_test_logger);

   MarketTruthLogger_InitState(g_market_truth_logger);
   MarketDetailReport_InitState(g_market_detail_report);

   BacktestReport_InitState(g_backtest_report);
   SignalAudit_InitState(g_signal_audit);

   if(!ValidateInputs())
      return INIT_PARAMETERS_INCORRECT;

   if(!InitializeHigherTimeframeEngine())
      Print(
         "EA جدید | هشدار | Higher Timeframe Engine آماده نشد");

   if(!DetailedLogger_Init(
      _Symbol,
      g_detailed_config,
      g_detailed_state))
   {
      Print(
         "EA جدید | هشدار | Detailed Logger آماده نشد");
   }

   PerformanceReport_Start(
      g_performance);

   TestReportLogger_Init(
      g_test_logger,
      _Symbol);

   MarketTruthLogger_Init(g_market_truth_logger,_Symbol);
   MarketDetailReport_Init(g_market_detail_report,_Symbol);

   BacktestReport_Init(g_backtest_report);
   SignalAudit_Init(g_signal_audit);

   Print("Market Truth Logger مستقل: فعال | گزارش خام و ریز بازار همزمان");

   ScenarioVirtualTester_Init();

   if(Inp_Enable_Chart_Panel)
      ChartPanel_Create(
         ChartID());

   // در Strategy Tester، تایمر یک‌ثانیه‌ای هزینه‌ای بسیار سنگین دارد؛
   // موتور برگشت در تست از تیک‌های واقعی OnTick تغذیه می‌شود و چرخه سنگین
   // حداکثر هر 60 ثانیه اجرا می‌شود. در بازار زنده حساسیت یک‌ثانیه‌ای حفظ می‌شود.
   int timer_period_seconds = 1;
   if(MQLInfoInteger(MQL_TESTER))
      timer_period_seconds = MathMax(10,MathMin(60,Inp_Monitor_Update_Seconds));
   if(!EventSetTimer(timer_period_seconds))
      Print("هشدار: راه‌اندازی تایمر ناموفق بود | ثانیه=",timer_period_seconds);

   g_main_state.initialized =
      true;

   // نمایش BUY/SELL برای معاملات قبلی و فعلی موجود در History
   DrawHistoricalTradeSignalLabels();

   g_main_state.trading_enabled =
      Inp_EnableTrading;

   g_main_state.start_time =
      TimeCurrent();

   g_last_m5_closed_bar = iTime(_Symbol,Inp_TF_Setup_M5,1);

   g_main_state.last_monitor_time =
      g_main_state.start_time;

   g_main_state.last_tick_time =
      g_main_state.start_time;

   Print(
      "================================================");

   Print(
      "EA جدید | هسته یکپارچه راه‌اندازی شد");

   Print(
      "نماد: ",
      _Symbol);

   Print(
      "تایم‌فریم: ",
      EnumToString(
         (ENUM_TIMEFRAMES)_Period));

   Print(
      "تحلیل MTF: فعال");

   Print(
      "Strategy Engine: فعال | BUY Continuation + SELL Continuation + End-of-Correction BUY/SELL");

   Print(
      "AI Independent Analysis: ",
      (Inp_AI_Independent_Enable
       ? "فعال"
       : "غیرفعال"),
      " | تایم‌فریم=",
      EnumToString(
         Inp_AI_Independent_Timeframe));

   Print(
      "AI Suggestion Popup: ",
      (Inp_Enable_AI && Inp_AI_Advisor_Enable ? "فعال" : "غیرفعال"),
      " | پیش‌فرض خاموش");

   Print(
      "Scenario: ",
      Inp_Enable_Scenarios
      ? "فعال"
      : "غیرفعال");

   Print(
      "Pending: ",
      Inp_AllowPendingOrders
      ? "فعال"
      : "غیرفعال");

   Print(
      "M1 Monitoring: ",
      Inp_Use_M1_Monitor
      ? "فعال"
      : "غیرفعال");

   Print(
      "AI: ",
      Inp_Enable_AI
      ? "فعال"
      : "غیرفعال");

   Print(
      "AI Auto Trade: ",
      (Inp_AI_Can_Trade_Real
       ? "فعال"
       : "غیرفعال"));

   Print(
      "Take Profit Mode: ",
      (Inp_Use_Manual_TP
       ? "دستی | هدف=" + DoubleToString(Inp_Manual_TP_Profit_Money, 2) + " حساب"
       : "سیستمی"));
Print(
      "Chart Panel: ",
      Inp_Enable_Chart_Panel
      ? "فعال"
      : "غیرفعال");

   Print(
      "M5 Movement Metrics: فعال | فقط گزارش‌گیری");

   Print(
      "M5 Zone Quality Analyzer: فعال | فقط گزارش‌گیری");

   Print(
      "Scenario Virtual Tester: ",
      g_svt_state.initialized
      ? "فعال"
      : "غیرفعال");

   Print(
      "Virtual Models: FIXED + WIDE_SL + PARTIAL_TP2_TRAIL");

   Print(
      "Virtual SL = SL واقعی سناریو");

   Print(
      "Scenario Invalidation = SL Reference");

   Print(
      "================================================");

   UpdatePanel();

   return INIT_SUCCEEDED;
}

//====================================================================
// V5.116: تکمیل اتصال Trade -> Audit از History نهایی
// این تابع فقط گزارش‌گیری است و در تصمیم ورود/خروج دخالتی ندارد.
//====================================================================
void V5103_ReconcileSignalAuditHistoryTrades()
{
   if(!g_signal_audit.enabled || !g_signal_audit.initialized)
      return;

   if(!HistorySelect(0,TimeCurrent()))
      return;

   const int total=HistoryDealsTotal();
   for(int i=0;i<total;i++)
   {
      const ulong deal_ticket=HistoryDealGetTicket(i);
      if(deal_ticket==0)
         continue;

      if(HistoryDealGetString(deal_ticket,DEAL_SYMBOL)!=_Symbol)
         continue;
      if((long)HistoryDealGetInteger(deal_ticket,DEAL_MAGIC)!=(long)Inp_MagicNumber)
         continue;
      if((ENUM_DEAL_ENTRY)HistoryDealGetInteger(deal_ticket,DEAL_ENTRY)!=DEAL_ENTRY_IN)
         continue;

      const ENUM_DEAL_TYPE deal_type=(ENUM_DEAL_TYPE)HistoryDealGetInteger(deal_ticket,DEAL_TYPE);
      if(deal_type!=DEAL_TYPE_BUY && deal_type!=DEAL_TYPE_SELL)
         continue;

      const string direction=(deal_type==DEAL_TYPE_BUY
                              ? ScenarioDirectionToPersian(SCENARIO_DIRECTION_BUY)
                              : ScenarioDirectionToPersian(SCENARIO_DIRECTION_SELL));
      const double entry_price=HistoryDealGetDouble(deal_ticket,DEAL_PRICE);
      const datetime trade_time=(datetime)HistoryDealGetInteger(deal_ticket,DEAL_TIME);
      const ulong position_id=(ulong)HistoryDealGetInteger(deal_ticket,DEAL_POSITION_ID);
      const string trade_comment=HistoryDealGetString(deal_ticket,DEAL_COMMENT);

      ulong scenario_id=ExtractScenarioIdFromComment(trade_comment);
      if(scenario_id==0 && position_id>0)
         scenario_id=FindScenarioIdByPositionId(position_id);

      string execution_status="Market اجرا شد";
      const ulong order_ticket=(ulong)HistoryDealGetInteger(deal_ticket,DEAL_ORDER);
      if(order_ticket>0 && HistoryOrderSelect(order_ticket))
      {
         const ENUM_ORDER_TYPE source_order_type=(ENUM_ORDER_TYPE)HistoryOrderGetInteger(order_ticket,ORDER_TYPE);
         if(source_order_type==ORDER_TYPE_BUY_LIMIT ||
            source_order_type==ORDER_TYPE_SELL_LIMIT ||
            source_order_type==ORDER_TYPE_BUY_STOP ||
            source_order_type==ORDER_TYPE_SELL_STOP)
            execution_status="Pending اجرا شد";
      }

      SignalAudit_LinkExecutedTrade(
         g_signal_audit,
         scenario_id,
         deal_ticket,
         position_id,
         direction,
         entry_price,
         trade_time,
         execution_status);
   }
}

//====================================================================
// OnDeinit
//====================================================================
void OnDeinit(
   const int reason)
{
   EventKillTimer();

   // پایان تست/اجرای EA: یک بار گزارش نهایی و خروجی‌های Strategy Tester نوشته شود.
   if(g_main_state.initialized)
   {
      UpdateReports();
      V5103_ReconcileSignalAuditHistoryTrades();
      BacktestReport_Finalize(g_backtest_report,g_performance);
      SignalAudit_Finalize(g_signal_audit);
      MarketTruthLogger_Finalize(g_market_truth_logger);
      MarketDetailReport_Finalize(g_market_detail_report);
   }

   if(ArraySize(
      g_virtual_trades) > 0)
   {
      ArrayFree(
         g_virtual_trades);

      Print(
         "[AI] Virtual Trades Cleaned Up");
   }

   g_virtual_scenario_id =
      0;

   g_svt_state.initialized =
      false;

   DetailedLogger_Shutdown(
      g_detailed_state);

   TestReportLogger_Shutdown(
      g_test_logger);

   if(Inp_Enable_Chart_Panel)
      ChartPanel_Destroy(
         ChartID());

   AISuggestion_HidePopup();

   g_main_state.initialized =
      false;

   Print(
      "EA جدید | هسته یکپارچه متوقف شد | دلیل: ",
      reason);
}

//====================================================================
// اجرای خودکار پیشنهاد معامله AI
//====================================================================
void ProcessAutoAISuggestion()
{
   if(!Inp_Enable_AI ||
      !Inp_AI_Advisor_Enable ||
      !Inp_AI_Can_Trade_Real)
      return;

   if(!g_main_state.initialized)
      return;

   if(!g_ai_popup.visible ||
      g_ai_popup.type != AI_POPUP_TRADE)
      return;

   // هر پاپ‌آپ فقط یک بار برای اجرای خودکار بررسی می‌شود.
   static datetime last_auto_show_time = 0;

   if(g_ai_popup.show_time <= 0 ||
      g_ai_popup.show_time == last_auto_show_time)
      return;

   last_auto_show_time =
      g_ai_popup.show_time;

   Print(
      "[AI AUTO] پیشنهاد معامله شناسایی شد | Direction=",
      g_ai_popup.trade_direction,
      " | Entry=",
      DoubleToString(
         g_ai_popup.trade_entry,
         _Digits),
      " | SL=",
      DoubleToString(
         g_ai_popup.trade_sl,
         _Digits),
      " | TP=",
      DoubleToString(
         g_ai_popup.trade_tp,
         _Digits),
      " | Confidence=",
      DoubleToString(
         g_ai_popup.trade_confidence,
         1),
      "%");

   ExecuteConfirmedAISuggestion(
      g_ai_popup.trade_direction,
      g_ai_popup.trade_entry,
      g_ai_popup.trade_sl,
      g_ai_popup.trade_tp,
      g_ai_popup.trade_confidence,
      g_ai_popup.trade_reason);
}

//====================================================================
// OnChartEvent
//====================================================================
void OnChartEvent(
   const int id,
   const long &lparam,
   const double &dparam,
   const string &sparam)
{
   AISuggestion_OnChartEvent(
      id,
      lparam,
      dparam,
      sparam);

   string ai_direction = "";

   double ai_entry = 0.0;
   double ai_sl = 0.0;
   double ai_tp = 0.0;
   double ai_confidence = 0.0;

   string ai_reason = "";

   bool ai_confirmed = false;
   bool ai_rejected = false;

   if(AISuggestion_ConsumeTradeAction(
      ai_confirmed,
      ai_rejected,
      ai_direction,
      ai_entry,
      ai_sl,
      ai_tp,
      ai_confidence,
      ai_reason))
   {
      if(ai_confirmed)
      {
         ExecuteConfirmedAISuggestion(
            ai_direction,
            ai_entry,
            ai_sl,
            ai_tp,
            ai_confidence,
            ai_reason);
      }
      else
      if(ai_rejected)
      {
         Print(
            "[AI MANUAL] REJECTED | Direction=",
            ai_direction);
      }
   }
}

//====================================================================
// اجرای دستی AI
//====================================================================
void ExecuteConfirmedAISuggestion(
   const string direction,
   const double entry,
   const double sl,
   const double tp,
   const double confidence,
   const string reason)
{
   Print(
      "[AI MANUAL] CONFIRM RECEIVED | Direction=",
      direction,
      " | Entry=",
      DoubleToString(entry,_Digits),
      " | SL=",
      DoubleToString(sl,_Digits),
      " | TP=",
      DoubleToString(tp,_Digits),
      " | Conf=",
      DoubleToString(
         confidence,
         1),
      "%");

   if(!g_main_state.initialized)
   {
      Alert(
         "⛔ معامله AI اجرا نشد | EA هنوز آماده نیست");

      return;
   }

   if(!IsRealTradingAllowed())
   {
      Alert(
         "⛔ معامله AI اجرا نشد | مجوز معامله واقعی فعال نیست");

      return;
   }

   const bool is_buy =
      (direction == "BUY");

   if(direction != "BUY" &&
      direction != "SELL")
   {
      Alert(
         "⛔ معامله AI اجرا نشد | جهت پیشنهاد نامعتبر است");

      return;
   }

   //--- AI دستی حق دور زدن Scenario را ندارد
   if(g_scenario.id <= 0 ||
      !Scenario_IsValid(
         g_scenario))
   {
      Alert(
         "⛔ معامله AI اجرا نشد | سناریوی معتبر وجود ندارد");

      Print(
         "[AI MANUAL] BLOCKED | Scenario معتبر نیست");

      return;
   }

   string scenario_direction =
      (g_scenario.direction ==
         SCENARIO_DIRECTION_BUY
       ?
         "BUY"
       :
       (g_scenario.direction ==
          SCENARIO_DIRECTION_SELL
        ?
         "SELL"
        :
         "NONE"));

   if(direction !=
      scenario_direction)
   {
      Alert(
         "⛔ معامله AI اجرا نشد | جهت AI با Scenario یکی نیست");

      Print(
         "[AI MANUAL] BLOCKED | AI=",
         direction,
         " | Scenario=",
         scenario_direction);

      return;
   }

   if(entry <= 0.0 ||
      sl <= 0.0 ||
      tp <= 0.0)
   {
      Alert(
         "⛔ معامله AI اجرا نشد | Entry/SL/TP نامعتبر است");

      return;
   }

   if(g_risk_result.position_volume <= 0.0 ||
      !g_risk_result.approved)
   {
      Alert(
         "⛔ معامله AI اجرا نشد | ریسک تأیید نشده است");

      return;
   }

   if(MathAbs(
      entry -
      g_scenario.entry_price) > 2.0 ||
      MathAbs(
      sl -
      g_sl_plan.stop_price) > 2.0)
   {
      Alert(
         "⛔ معامله AI اجرا نشد | سطوح AI با Scenario منطبق نیستند");

      return;
   }

   if((is_buy &&
       !Inp_AllowBuy) ||
      (!is_buy &&
       !Inp_AllowSell))
   {
      Alert(
         "⛔ معامله AI اجرا نشد | این جهت مجاز نیست");

      return;
   }

   string market_reason = "";

   if(!IsMarketOpenForSymbol(
      market_reason))
   {
      Alert(
         "⛔ معامله AI اجرا نشد | ",
         market_reason);

      return;
   }

   string spread_reason = "";

   if(!IsSpreadAcceptable(
      spread_reason))
   {
      Alert(
         "⛔ معامله AI اجرا نشد | ",
         spread_reason);

      return;
   }

   if(!CloseOppositePositionsAndVerify(
      is_buy
      ? SCENARIO_DIRECTION_BUY
      : SCENARIO_DIRECTION_SELL))
   {
      Alert(
         "⛔ معامله AI اجرا نشد | معامله مخالف بسته نشده است");

      return;
   }

   double bid = 0.0;
   double ask = 0.0;
   double current_price = 0.0;

   if(!GetCurrentPrices(
      bid,
      ask,
      current_price))
   {
      Alert(
         "⛔ معامله AI اجرا نشد | قیمت لحظه‌ای دریافت نشد");

      return;
   }

   ExecutionRequest req;
   ExecutionResult res;

   Execution_InitRequest(
      req);

   req.symbol =
      _Symbol;

   req.magic =
      Inp_MagicNumber;

   req.scenario_id =
      g_scenario.id;

   req.signal_id =
      g_scenario.id;

   req.volume =
      g_risk_result.position_volume;

   req.price =
      NormalizeDouble(
         entry,
         _Digits);

   req.stop_loss =

      NormalizeDouble(

         sl,

         _Digits);

   double real_ai_tp = 0.0;

   if(!ResolveRealTakeProfit(

      is_buy

      ? SCENARIO_DIRECTION_BUY

      : SCENARIO_DIRECTION_SELL,

      entry,

      req.volume,

      tp,

      real_ai_tp))

   {

      Alert(

         "⛔ معامله AI اجرا نشد | حد سود نهایی قابل محاسبه نیست");

      return;

   }

   req.take_profit =

      NormalizeDouble(

         real_ai_tp,

         _Digits);

   req.expiration =
      TimeCurrent() +
      (Inp_Pending_Expiration_Minutes *
       60);

   req.comment =
      MakeScenarioComment(
         g_scenario.id,
         g_scenario.target_1,
         g_scenario.target_2);

   req.reason =
      reason;

   const double spread_price =
      MathMax(
         ask - bid,
         _Point);

   const double tolerance =
      MathMax(
         _Point * 2.0,
         spread_price * 1.5);

   if(MathAbs(
      (is_buy ? ask : bid) -
      entry) <=
      tolerance)
   {
      req.order_type =
         (is_buy
          ?
           EXECUTION_BUY_MARKET
          :
           EXECUTION_SELL_MARKET);

      req.price =
         current_price;

      if(!Execution_SendMarket(
         req,
         res))
      {
         Alert(
            "⛔ اجرای معامله AI ناموفق بود");

         return;
      }

      g_last_executed_scenario_id =
         g_scenario.id;
      SignalAudit_MarkCapture(g_signal_audit,g_scenario.id,"AI Market اجرا شد");

      Alert(
         "✅ معامله AI تأیید و اجرا شد | ",
         direction);

      return;
   }

   if(!Inp_AllowPendingOrders)
   {
      Alert(
         "⛔ معامله AI اجرا نشد | Pending غیرفعال است");

      return;
   }

   if(is_buy)
   {
      req.order_type =
         (entry < ask
          ?
           EXECUTION_BUY_LIMIT
          :
           EXECUTION_BUY_STOP);
   }
   else
   {
      req.order_type =
         (entry > bid
          ?
           EXECUTION_SELL_LIMIT
          :
           EXECUTION_SELL_STOP);
   }

   if(!Execution_PlacePending(
      req,
      res))
   {
      Alert(
         "⛔ ثبت Pending معامله AI ناموفق بود");

      return;
   }

   Alert(
      "✅ پیشنهاد AI تأیید شد | Pending ثبت شد");
}

//====================================================================
// OnTick
//====================================================================
void OnTick()
{
   if(!g_main_state.initialized)
      return;

   g_main_state.last_tick_time =
      TimeCurrent();

   MarketTruthLogger_UpdateTick(g_market_truth_logger);
   MarketTruthLogger_LogNewBars(g_market_truth_logger);

   if(MQLInfoInteger(MQL_TESTER))
      ProcessFastReversalMonitor();

   EnforceActiveScenarioFreshness();

   // کنترل Pending قبل از هر تحلیل سنگین و قبل از نزدیک‌شدن به Trigger.
   ProtectLiveSellContinuationPendings();

   RunAnalysisCycle();

   double audit_bid=0.0, audit_ask=0.0, audit_mid=0.0;
   if(GetCurrentPrices(audit_bid,audit_ask,audit_mid))
      SignalAudit_Update(g_signal_audit,TimeCurrent(),audit_bid,audit_ask);

   UpdateScenarioVirtualTester();

   MonitorPending();

   MonitorOpenTrades();

   UpdatePanel();
}

//====================================================================
// OnTimer
//====================================================================
void OnTimer()
{
   if(!g_main_state.initialized)
      return;

   datetime now =
      TimeCurrent();

   if(!MQLInfoInteger(MQL_TESTER))
      MarketTruthLogger_UpdateTick(g_market_truth_logger);
   MarketTruthLogger_LogNewBars(g_market_truth_logger);

   // در تستر، موتور سریع از OnTick تغذیه می‌شود تا تایمر ثانیه‌ای
   // باعث کندشدن چندین‌برابری بک‌تست نشود. در بازار زنده پایش تایمری فعال است.
   if(!MQLInfoInteger(MQL_TESTER))
      ProcessFastReversalMonitor();

   if((now -
       g_main_state.last_monitor_time) <
      Inp_Monitor_Update_Seconds)
      return;

   g_main_state.last_monitor_time =
      now;

   EnforceActiveScenarioFreshness();

   // کنترل Pending قبل از تحلیل‌های HTF/Scenario این چرخه.
   ProtectLiveSellContinuationPendings();

   if(Inp_Use_H4_Background ||
      Inp_Use_H1_Background)
   {
      RefreshHigherTimeframeContext();
   }

   if(g_scenario.id > 0)
   {
      double bid = 0.0;
      double ask = 0.0;
      double mid = 0.0;

      if(GetCurrentPrices(
         bid,
         ask,
         mid))
      {
         InvalidationResult inv;

         Invalidation_UpdateScenario(
            g_scenario,
            mid,
            now,
            inv);
      }
   }

   double audit_bid=0.0, audit_ask=0.0, audit_mid=0.0;
   if(GetCurrentPrices(audit_bid,audit_ask,audit_mid))
      SignalAudit_Update(g_signal_audit,now,audit_bid,audit_ask);

   UpdateScenarioVirtualTester();

   MonitorPending();

   MonitorOpenTrades();

   // مدیریت TP و موتور برگشت در چرخه رصد؛ فاصله پیش‌فرض یک ثانیه است
   ProcessMinuteTradeManagement();

   UpdateRisk();

   ManageScenarioAndEntry();

   RegisterCurrentScenarioForVirtualTester();

   //===============================================================
   // AI Independent فقط یک بار
   //===============================================================
   {
      string bot_dir =
         (g_scenario.id > 0 &&
          Scenario_IsValid(
             g_scenario) &&
          g_scenario.direction ==
             SCENARIO_DIRECTION_BUY
          ?
            "BUY"
          :
          (g_scenario.id > 0 &&
           Scenario_IsValid(
              g_scenario) &&
           g_scenario.direction ==
              SCENARIO_DIRECTION_SELL
           ?
             "SELL"
           :
             "NONE"));

      string bot_dec =
         (g_scenario.id > 0 &&
          Scenario_IsValid(
             g_scenario)
          ?
            ScenarioStatusToPersian(
               g_scenario.status)
          :
            "بدون سناریوی معتبر");

      if(Inp_Enable_AI && Inp_AI_Independent_Enable)
         AIIndependent_Update(
            bot_dir,
            bot_dec);
   }

   UpdateAI();

   UpdateReports();

   if(Inp_Enable_AI && Inp_AI_Advisor_Enable)
      AISuggestion_Update();

   ProcessAutoAISuggestion();

   UpdatePanel();

   LogCycle(
      "MONITOR",
      "رصد دوره‌ای انجام شد");
}

//====================================================================
// OnTradeTransaction
//====================================================================
void OnTradeTransaction(
   const MqlTradeTransaction &trans,
   const MqlTradeRequest &request,
   const MqlTradeResult &result)
{
   if(!g_main_state.initialized)
      return;

   if(trans.symbol != "" &&
      trans.symbol != _Symbol)
      return;

   if(trans.type ==
      TRADE_TRANSACTION_DEAL_ADD)
   {
      ulong deal_ticket =
         trans.deal;

      if(deal_ticket > 0 &&
         HistorySelect(
            0,
            TimeCurrent()) &&
         HistoryDealSelect(
            deal_ticket))
      {
         string deal_symbol =
            HistoryDealGetString(
               deal_ticket,
               DEAL_SYMBOL);

         long deal_magic =
            HistoryDealGetInteger(
               deal_ticket,
               DEAL_MAGIC);

         long deal_entry =
            HistoryDealGetInteger(
               deal_ticket,
               DEAL_ENTRY);

         if(deal_symbol ==
               _Symbol &&
            deal_magic ==
               Inp_MagicNumber &&
            deal_entry ==
               DEAL_ENTRY_IN)
         {
            const ENUM_DEAL_TYPE deal_type =
               (ENUM_DEAL_TYPE)HistoryDealGetInteger(
                  deal_ticket,
                  DEAL_TYPE);
            const string trade_direction =
               (deal_type == DEAL_TYPE_BUY
                ? ScenarioDirectionToPersian(SCENARIO_DIRECTION_BUY)
                : ScenarioDirectionToPersian(SCENARIO_DIRECTION_SELL));
            const double trade_entry_price =
               HistoryDealGetDouble(
                  deal_ticket,
                  DEAL_PRICE);
            const datetime trade_time =
               (datetime)HistoryDealGetInteger(
                  deal_ticket,
                  DEAL_TIME);
            const string trade_comment =
               HistoryDealGetString(
                  deal_ticket,
                  DEAL_COMMENT);
            const ulong deal_position_id =
               (ulong)HistoryDealGetInteger(
                  deal_ticket,
                  DEAL_POSITION_ID);
            ulong linked_scenario_id =
               ExtractScenarioIdFromComment(trade_comment);
            if(linked_scenario_id == 0)
               linked_scenario_id = FindScenarioIdByPositionId(deal_position_id);

            string execution_status = "Market اجرا شد";
            if(trans.order > 0 && HistoryOrderSelect(trans.order))
            {
               const ENUM_ORDER_TYPE source_order_type =
                  (ENUM_ORDER_TYPE)HistoryOrderGetInteger(trans.order,ORDER_TYPE);
               if(source_order_type == ORDER_TYPE_BUY_LIMIT ||
                  source_order_type == ORDER_TYPE_SELL_LIMIT ||
                  source_order_type == ORDER_TYPE_BUY_STOP ||
                  source_order_type == ORDER_TYPE_SELL_STOP)
                  execution_status = "Pending اجرا شد";
            }

            SignalAudit_LinkExecutedTrade(
               g_signal_audit,
               linked_scenario_id,
               deal_ticket,
               deal_position_id,
               trade_direction,
               trade_entry_price,
               trade_time,
               execution_status);

            int open_count =
               CountOpenPositions();

            int max_allowed =
               GetEffectiveMaxOpenTrades();

            if(open_count >
               max_allowed)
            {
               Print(
                  "[OVERFLOW] معامله اضافی شناسایی شد! باز=",
                  open_count,
                  " | سقف=",
                  max_allowed);

               for(int i =
                  PositionsTotal() - 1;
                  i >= 0;
                  i--)
               {
                  ulong pos_ticket =
                     PositionGetTicket(i);

                  if(pos_ticket == 0)
                     continue;

                  if(!PositionSelectByTicket(
                     pos_ticket))
                     continue;

                  if(PositionGetString(
                        POSITION_SYMBOL) !=
                     _Symbol)
                     continue;

                  if((ulong)
                     PositionGetInteger(
                        POSITION_MAGIC) !=
                     Inp_MagicNumber)
                     continue;

                  bool is_buy =
                     (PositionGetInteger(
                        POSITION_TYPE) ==
                      POSITION_TYPE_BUY);

                  double vol =
                     PositionGetDouble(
                        POSITION_VOLUME);

                  if(ClosePositionVolume(
                     pos_ticket,
                     _Symbol,
                     is_buy,
                     vol,
                     "TFlab سقف معاملات"))
                  {
                     Print(
                        "[OVERFLOW FIXED] معامله اضافی بسته شد | Ticket=",
                        pos_ticket);

                     break;
                  }
               }
            }
         }
      }
   }

   // برچسب BUY/SELL باید مستقل از Detailed Log باشد
   HandleTradeSignalTransaction(trans);

   if(Inp_Enable_Detailed_Log &&
      g_detailed_state.initialized)
   {
      DetailedLogger_Log(
         DLOG_LEVEL_INFO,
         DLOG_CATEGORY_TRADE,
         "TRADE_TRANSACTION",
         "EXECUTION",
         g_panel.direction,
         g_panel.scenario,
         "تغییر وضعیت معامله/سفارش دریافت شد",
         _Symbol,
         (ENUM_TIMEFRAMES)_Period,
         (double)result.retcode,
         (double)result.order,
         (double)result.deal,
         0.0,
         result.price,
         result.volume,
         request.sl,
         request.tp,
         g_scenario.id,
         result.order,
         trans.position,
         g_detailed_config,
         g_detailed_state);
   }
}

//+------------------------------------------------------------------+
//| پایان فایل                                                       |
//+------------------------------------------------------------------+
TFlab New EA V5.12 – Signal Audit

مبنای این نسخه V5.10 است. منطق اصلی ورود/خروج V5.10 عمداً حفظ شده و Signal Audit هیچ دخالتی در اجازه یا جلوگیری از معامله ندارد.

کار Signal Audit:
- ثبت هر Scenario یکتا
- ثبت Quality و Confidence واقعی Strategy به صورت جدا
- ثبت Structure / Impulse / Market Truth / Regime / H4-H1 / Zone / ATR / Entry / SL / TP
- سنجش مسیر واقعی قیمت در افق 15، 30 و 60 دقیقه
- ثبت MFE و MAE بر حسب ATR
- ثبت زمان اولین رسیدن به آستانه مطلوب و نامطلوب
- طبقه‌بندی CORRECT / WRONG / MIXED / UNDECIDED فقط برای ممیزی

خروجی‌های Strategy Tester:
TFlab_BACKTEST_Signal_Audit.csv
TFlab_BACKTEST_Signal_Audit_Summary.csv
به‌علاوه خروجی‌های بک‌تست موجود در V5.10.

تنظیم جدید:
Inp_Signal_Audit_Threshold_ATR = 0.50
این مقدار فقط معیار ممیزی است و روی معامله هیچ اثری ندارد.

تمام فایل‌های MQ5 و MQH را در همان پوشه MQL5\Experts قرار دهید.

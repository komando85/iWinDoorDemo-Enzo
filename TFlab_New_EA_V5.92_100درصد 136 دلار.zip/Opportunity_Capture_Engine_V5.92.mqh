#ifndef __TFLAB_OPPORTUNITY_CAPTURE_ENGINE_V5_92_MQH__
#define __TFLAB_OPPORTUNITY_CAPTURE_ENGINE_V5_92_MQH__

//+------------------------------------------------------------------+
//| Opportunity_Capture_Engine_V5.92.mqh                            |
//|                                                                  |
//| نقش: پیدا کردن فرصت اولویت‌دار قبل از ورود به زنجیره سناریو      |
//| اصل: فرصت بزرگ مهم‌تر از امتیاز اسمی Scenario است.              |
//| این موتور از داده‌های آینده استفاده نمی‌کند.                    |
//+------------------------------------------------------------------+
#property strict

#include "EA_Inputs_V5.92.mqh"
#include "Market_Truth_Engine_V5.92.mqh"
#include "Market_Reading_Engine_V5.92.mqh"
#include "Market_Structure_V5.92.mqh"
#include "Impulse_Correction_V5.92.mqh"
#include "Scenario_Engine_V5.92.mqh"
#include "Zone_Engine_V5.92.mqh"

struct OpportunityCaptureSnapshot
  {
   bool                         valid;
   bool                         priority;
   bool                         current_pressure_confirmed;
   bool                         reaction_confirmed;
   bool                         native_zone_relevant;
   bool                         synthetic_zone_created;
   ENUM_SCENARIO_DIRECTION      direction;
   ENUM_MARKET_TRUTH_PHASE      phase;
   double                       quality;
   double                       estimated_room_price;
   double                       estimated_room_atr;
   double                       truth_move_atr;
   double                       current_price;
   double                       reaction_anchor;
   double                       reaction_zone_width;
   string                       reason;
  };

void OpportunityCapture_Reset(OpportunityCaptureSnapshot &o)
  {
   o.valid=false;
   o.priority=false;
   o.current_pressure_confirmed=false;
   o.reaction_confirmed=false;
   o.native_zone_relevant=false;
   o.synthetic_zone_created=false;
   o.direction=SCENARIO_DIRECTION_NONE;
   o.phase=MARKET_TRUTH_PHASE_UNKNOWN;
   o.quality=0.0;
   o.estimated_room_price=0.0;
   o.estimated_room_atr=0.0;
   o.truth_move_atr=0.0;
   o.current_price=0.0;
   o.reaction_anchor=0.0;
   o.reaction_zone_width=0.0;
   o.reason="";
  }

bool OpportunityCapture_Evaluate(
   const MarketTruthSnapshot &truth,
   const MarketReadingSnapshot &reading,
   const MarketStructureSnapshot &structure,
   const ImpulseCorrectionSnapshot &move,
   const ZoneInfo &native_buy_zone,
   const ZoneInfo &native_sell_zone,
   const double current_price,
   OpportunityCaptureSnapshot &out)
  {
   OpportunityCapture_Reset(out);

   if(!Inp_OpportunityFirst_Enabled)
      return false;

   if(current_price<=0.0 || !truth.valid)
      return false;

   if(truth.direction!=MARKET_TRUTH_BUY &&
      truth.direction!=MARKET_TRUTH_SELL)
      return false;

   if(!truth.strong_market_move || !truth.continuation_ready)
      return false;

   if(truth.move_atr_multiple < Inp_Opportunity_Min_Truth_ATR)
      return false;

   if(truth.phase!=MARKET_TRUTH_PHASE_EXPANSION &&
      truth.phase!=MARKET_TRUTH_PHASE_PULLBACK)
      return false;

   const bool is_buy=(truth.direction==MARKET_TRUTH_BUY);

   //===============================================================
   // V5.92: Reaction واقعی باید قبل از Opportunity ثبت شده باشد.
   // صرفِ «Impulse + فشار جاری» دیگر به‌تنهایی Reaction محسوب نمی‌شود؛
   // چون همین مسیر در V5.92 باعث شد در 17:29 یک BUY روی ساختار متعادل
   // بدون Pullback/تأیید ساختاری ساخته شود.
   //===============================================================
   if(is_buy)
     {
      if(!structure.valid ||
         (structure.state!=STRUCTURE_STATE_BULLISH &&
          structure.state!=STRUCTURE_STATE_BALANCED))
         return false;

      if(Inp_Opportunity_Require_Current_Pressure &&
         (!reading.valid ||
          (!reading.current_up_pressure && !reading.current_down_pressure)))
         return false;

      const bool pullback_reaction =
         move.valid && move.correction_valid &&
         move.correction_direction<0;

      const bool structural_continuation =
         move.valid && move.impulse_valid &&
         move.impulse_direction>0 &&
         structure.state==STRUCTURE_STATE_BULLISH &&
         structure.bullish_sequence &&
         reading.current_up_pressure;

      const double atr_now =
         (truth.move_atr_multiple>0.0 && truth.move_size>0.0
          ? truth.move_size/truth.move_atr_multiple
          : 0.0);
      const double break_buffer =
         MathMax(SymbolInfoDouble(_Symbol,SYMBOL_POINT)*2.0,
                 atr_now>0.0 ? atr_now*0.02 : SymbolInfoDouble(_Symbol,SYMBOL_POINT)*10.0);
      const bool structural_break =
         structure.structural_high>0.0 &&
         current_price > structure.structural_high + break_buffer &&
         reading.current_up_pressure;

      if(pullback_reaction || structural_continuation || structural_break)
         out.reaction_confirmed=true;
      else
         return false;

      out.direction=SCENARIO_DIRECTION_BUY;
     }
   else
     {
      if(!structure.valid ||
         (structure.state!=STRUCTURE_STATE_BEARISH &&
          structure.state!=STRUCTURE_STATE_BALANCED))
         return false;

      if(Inp_Opportunity_Require_Current_Pressure &&
         (!reading.valid ||
          (!reading.current_up_pressure && !reading.current_down_pressure)))
         return false;

      const bool pullback_reaction =
         move.valid && move.correction_valid &&
         move.correction_direction>0;

      const bool structural_continuation =
         move.valid && move.impulse_valid &&
         move.impulse_direction<0 &&
         structure.state==STRUCTURE_STATE_BEARISH &&
         structure.bearish_sequence &&
         reading.current_down_pressure;

      const double atr_now =
         (truth.move_atr_multiple>0.0 && truth.move_size>0.0
          ? truth.move_size/truth.move_atr_multiple
          : 0.0);
      const double break_buffer =
         MathMax(SymbolInfoDouble(_Symbol,SYMBOL_POINT)*2.0,
                 atr_now>0.0 ? atr_now*0.02 : SymbolInfoDouble(_Symbol,SYMBOL_POINT)*10.0);
      const bool structural_break =
         structure.structural_low>0.0 &&
         current_price < structure.structural_low - break_buffer &&
         reading.current_down_pressure;

      if(pullback_reaction || structural_continuation || structural_break)
         out.reaction_confirmed=true;
      else
         return false;

      out.direction=SCENARIO_DIRECTION_SELL;
     }

   // فضای قابل استفاده بر اساس ساختار جاری محاسبه می‌شود؛ این «پیش‌بینی آینده» نیست.
   double atr=truth.move_atr_multiple>0.0 && truth.move_size>0.0
              ? truth.move_size/truth.move_atr_multiple
              : 0.0;
   if(atr<=0.0)
      atr=SymbolInfoDouble(_Symbol,SYMBOL_POINT)*100.0;
   if(atr<=0.0)
      return false;

   double room=0.0;
   if(is_buy && structure.structural_high>current_price)
      room=structure.structural_high-current_price;
   else if(!is_buy && structure.structural_low>0.0 && structure.structural_low<current_price)
      room=current_price-structure.structural_low;
   else
      room=atr*3.0;

   out.estimated_room_price=room;
   out.estimated_room_atr=room/atr;
   out.truth_move_atr=truth.move_atr_multiple;
   out.current_price=current_price;

   if(out.estimated_room_atr < Inp_Opportunity_Min_Room_ATR)
      return false;

   ZoneInfo native_zone;
   Zone_Init(native_zone);
   if(is_buy)
      native_zone=native_buy_zone;
   else
      native_zone=native_sell_zone;
   bool native_valid=Zone_IsValid(native_zone);
   bool native_relevant=false;

   if(native_valid)
     {
      const double midpoint=Zone_Midpoint(native_zone);
      const double distance=MathAbs(current_price-midpoint);
      native_relevant=Zone_ContainsPrice(native_zone,current_price) ||
                      distance <= atr*0.75;
     }

   out.native_zone_relevant=native_relevant;

   if(!native_relevant && Inp_Opportunity_Allow_Synthetic_Zone)
     {
      double anchor=current_price;
      if(move.valid && move.correction_end_price>0.0)
         anchor=move.correction_end_price;

      double width=MathMax(
         atr*MathMax(0.05,Inp_Opportunity_Reaction_Zone_ATR),
         SymbolInfoDouble(_Symbol,SYMBOL_POINT)*20.0);

      out.reaction_anchor=anchor;
      out.reaction_zone_width=width;

      // ناحیه مصنوعی فقط نزدیک واکنش جاری ساخته می‌شود؛ جایگزین کور Zone قدیمی نیست.
      if(MathAbs(current_price-anchor) > width*1.50)
         return false;

      double invalid=0.0;
      double buffer=MathMax(SymbolInfoDouble(_Symbol,SYMBOL_POINT)*10.0,atr*0.05);

      if(is_buy)
        {
         if(move.valid && move.correction_extreme_price>0.0 &&
            move.correction_extreme_price < anchor)
            invalid=move.correction_extreme_price-buffer;
         else
            invalid=anchor-atr;
        }
      else
        {
         if(move.valid && move.correction_extreme_price>0.0 &&
            move.correction_extreme_price > anchor)
            invalid=move.correction_extreme_price+buffer;
         else
            invalid=anchor+atr;
        }

      if(invalid<=0.0)
         return false;

      out.synthetic_zone_created=true;
      out.native_zone_relevant=false;
      out.reaction_confirmed=true;
     }
   else
     {
      if(!native_relevant)
         return false;
     }

   double score=50.0;
   score+=MathMin(25.0,truth.move_atr_multiple*5.0);
   score+=MathMin(15.0,out.estimated_room_atr*5.0);
   score+=out.reaction_confirmed ? 10.0 : 0.0;
   out.quality=MathMin(100.0,score);
   out.priority=(out.quality>=75.0);
   out.current_pressure_confirmed=(!Inp_Opportunity_Require_Current_Pressure ||
                                   (is_buy ? reading.current_up_pressure : reading.current_down_pressure));
   out.valid=true;

   out.reason=
      "فرصت اولویت‌دار شناسایی شد"+
      " | TruthMoveATR="+DoubleToString(out.truth_move_atr,2)+
      " | RoomATR="+DoubleToString(out.estimated_room_atr,2)+
      " | Reaction="+(out.reaction_confirmed ? "YES" : "NO")+
      " | NativeZone="+(out.native_zone_relevant ? "YES" : "NO")+
      " | SyntheticZone="+(out.synthetic_zone_created ? "YES" : "NO");

   Print(
      "[OPPORTUNITY FIRST] ",
      is_buy ? "BUY" : "SELL",
      " | Priority=",out.priority ? "HIGH" : "NORMAL",
      " | Quality=",DoubleToString(out.quality,1),
      " | TruthMoveATR=",DoubleToString(out.truth_move_atr,2),
      " | RoomATR=",DoubleToString(out.estimated_room_atr,2),
      " | Reaction=",out.reaction_confirmed ? "YES" : "NO",
      " | NativeZone=",out.native_zone_relevant ? "YES" : "NO",
      " | SyntheticZone=",out.synthetic_zone_created ? "YES" : "NO");

   return true;
  }

bool OpportunityCapture_CreateSyntheticZone(
   const OpportunityCaptureSnapshot &opportunity,
   const ImpulseCorrectionSnapshot &move,
   const double atr,
   ZoneInfo &zone)
  {
   Zone_Init(zone);
   if(!opportunity.valid || !opportunity.synthetic_zone_created || atr<=0.0)
      return false;

   double anchor=opportunity.reaction_anchor;
   double width=opportunity.reaction_zone_width;
   if(anchor<=0.0 || width<=0.0)
      return false;

   bool is_buy=(opportunity.direction==SCENARIO_DIRECTION_BUY);
   double invalid=0.0;
   double buffer=MathMax(SymbolInfoDouble(_Symbol,SYMBOL_POINT)*10.0,atr*0.05);

   if(is_buy)
     {
      if(move.correction_extreme_price>0.0 && move.correction_extreme_price<anchor)
         invalid=move.correction_extreme_price-buffer;
      else
         invalid=anchor-atr;

      return Zone_Create(
         980000+(ulong)TimeCurrent(),
         ZONE_TYPE_STRUCTURE,
         ZONE_DIRECTION_BUY,
         anchor-width,
         anchor+width,
         invalid,
         TimeCurrent(),
         0,
         Inp_TF_Setup_M5,
         MathMax(75.0,opportunity.quality),
         "OpportunityFirst",
         "ناحیه واکنش موقت برای فرصت اولویت‌دار BUY",
         zone);
     }

   if(move.correction_extreme_price>0.0 && move.correction_extreme_price>anchor)
      invalid=move.correction_extreme_price+buffer;
   else
      invalid=anchor+atr;

   return Zone_Create(
      980000+(ulong)TimeCurrent(),
      ZONE_TYPE_STRUCTURE,
      ZONE_DIRECTION_SELL,
      anchor-width,
      anchor+width,
      invalid,
      TimeCurrent(),
      0,
      Inp_TF_Setup_M5,
      MathMax(75.0,opportunity.quality),
      "OpportunityFirst",
      "ناحیه واکنش موقت برای فرصت اولویت‌دار SELL",
      zone);
  }

#endif // __TFLAB_OPPORTUNITY_CAPTURE_ENGINE_V5_92_MQH__
